<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('guides', function (Blueprint $table) {
            $table->string('iqama_number')->nullable()->after('phone');
            $table->string('nationality')->nullable()->after('iqama_number');
            $table->string('driving_license')->nullable()->after('nationality');
            $table->longText('description')->nullable()->after('driving_license');
        });
    }

    public function down(): void
    {
        Schema::table('guides', function (Blueprint $table) {
            $table->dropColumn(['iqama_number', 'nationality', 'driving_license', 'description']);
        });
    }
};
