<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('media_galleries', function (Blueprint $table) {
            $table->id();
            $table->string('galleryable_type');
            $table->unsignedBigInteger('galleryable_id');
            $table->string('media_url');
            $table->enum('media_type', ['image', 'video'])->default('image');
            $table->string('title')->nullable();
            $table->longText('description')->nullable();
            $table->integer('order')->default(0);
            $table->timestamps();
            
            $table->index(['galleryable_type', 'galleryable_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('media_galleries');
    }
};
