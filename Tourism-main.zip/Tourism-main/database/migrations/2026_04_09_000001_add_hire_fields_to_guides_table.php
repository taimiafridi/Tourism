<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('guides', function (Blueprint $table) {
            $table->decimal('hourly_rate', 8, 2)->default(0)->after('phone');
            $table->decimal('hourly_rate_with_car', 8, 2)->default(0)->after('hourly_rate');
            $table->string('specialization')->nullable()->after('hourly_rate_with_car');
            $table->string('city')->nullable()->after('specialization');
            $table->string('profile_photo')->nullable()->after('city');
            $table->boolean('has_car')->default(false)->after('profile_photo');
            $table->integer('total_tours_completed')->default(0)->after('has_car');
        });
    }

    public function down(): void
    {
        Schema::table('guides', function (Blueprint $table) {
            $table->dropColumn([
                'hourly_rate',
                'hourly_rate_with_car',
                'specialization',
                'city',
                'profile_photo',
                'has_car',
                'total_tours_completed',
            ]);
        });
    }
};
