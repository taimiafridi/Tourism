<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create admin user
        User::updateOrCreate(
            ['email' => 'admin@sauditourism.sa'],
            [
                'name' => 'Admin - Wanderly',
                'password' => Hash::make('password123'),
                'role' => 'admin',
                'status' => 'active',
                'email_verified_at' => now(),
            ]
        );

        // Create sample regular user
        User::updateOrCreate(
            ['email' => 'user@sauditourism.sa'],
            [
                'name' => 'Abdullah Al-Mutairi',
                'password' => Hash::make('password123'),
                'role' => 'user',
                'status' => 'active',
                'email_verified_at' => now(),
            ]
        );

        // Create second sample user
        User::updateOrCreate(
            ['email' => 'sara@sauditourism.sa'],
            [
                'name' => 'Sara Al-Ahmad',
                'password' => Hash::make('password123'),
                'role' => 'user',
                'status' => 'active',
                'email_verified_at' => now(),
            ]
        );

        $this->command->info('Wanderly admin & users created successfully!');
    }
}
