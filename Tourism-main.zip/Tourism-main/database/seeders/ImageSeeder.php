<?php

namespace Database\Seeders;

use App\Models\Destination;
use App\Models\Tour;
use App\Models\Event;
use App\Models\Restaurant;
use Illuminate\Database\Seeder;

class ImageSeeder extends Seeder
{
    public function run(): void
    {
        // --- Destination Images ---
        $destinationImages = [
            'AlUla Heritage Site' => 'https://images.unsplash.com/photo-1578681041175-9717c638d237?w=800',
            'Al-Balad Historical District' => 'https://images.unsplash.com/photo-1586724237569-f3d0c1dee8c6?w=800',
            'Diriyah - At-Turaif District' => 'https://images.unsplash.com/photo-1586724237569-f3d0c1dee8c6?w=800',
            'The Red Sea Coast' => 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800',
            'Edge of the World (Jebel Fihrayn)' => 'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=800',
            'Al-Soudah Mountain Park' => 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800',
            "Masjid an-Nabawi (Prophet's Mosque)" => 'https://images.unsplash.com/photo-1591604129939-f1efa4d99f7e?w=800',
            'Farasan Islands' => 'https://images.unsplash.com/photo-1559128010-7c1ad6e1b6a5?w=800',
            'NEOM - The Line' => 'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=800',
            'Rijal Almaa Heritage Village' => 'https://images.unsplash.com/photo-1553856622-d1b352e24a21?w=800',
        ];

        foreach ($destinationImages as $name => $url) {
            Destination::where('name', $name)->update(['image_url' => $url]);
        }

        // --- Tour Images ---
        $tourImages = [
            'AlUla Hegra & Elephant Rock Full Day Tour' => 'https://images.unsplash.com/photo-1578681041175-9717c638d237?w=800',
            'Riyadh Heritage Walk — Diriyah & Bujairi Terrace' => 'https://images.unsplash.com/photo-1586724237569-f3d0c1dee8c6?w=800',
            'Edge of the World Sunset Adventure' => 'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=800',
            'Jeddah Al-Balad Heritage & Food Tour' => 'https://images.unsplash.com/photo-1586724237569-f3d0c1dee8c6?w=800',
            'Asir Mountains Hiking & Rijal Almaa Day Trip' => 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800',
            'Red Sea Snorkeling & Island Hopping' => 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800',
            'NEOM Vision Tour — Future of Saudi Arabia' => 'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=800',
            'Madinah Islamic Heritage Walking Tour' => 'https://images.unsplash.com/photo-1591604129939-f1efa4d99f7e?w=800',
            'Farasan Islands 3-Day Escape' => 'https://images.unsplash.com/photo-1559128010-7c1ad6e1b6a5?w=800',
        ];

        foreach ($tourImages as $name => $url) {
            Tour::where('name', $name)->update(['image_url' => $url]);
        }

        // --- Event Images ---
        $eventImages = [
            'Riyadh Season 2026' => 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=800',
            'Jeddah Season — Red Sea Nights' => 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=800',
            'AlUla Moments Festival 2026' => 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800',
            "Saudi Cup — World's Richest Horse Race" => 'https://images.unsplash.com/photo-1529753253655-470be9a42781?w=800',
            'MDLBeast Soundstorm 2026' => 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=800',
            'Abha Summer Festival' => 'https://images.unsplash.com/photo-1523301343968-6a6ebf63c672?w=800',
        ];

        foreach ($eventImages as $name => $url) {
            Event::where('name', $name)->update(['image_url' => $url]);
        }

        // --- Restaurant Images ---
        $restaurantImages = [
            'Takya — Bujairi Terrace' => 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800',
            'Al Baik' => 'https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?w=800',
            'Najd Village Restaurant' => 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800',
            'Suhail Restaurant — AlUla' => 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800',
            'Mama Noura' => 'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800',
            'SALT — Jeddah Corniche' => 'https://images.unsplash.com/photo-1565299507177-b0ac66763828?w=800',
            'The Globe Restaurant' => 'https://images.unsplash.com/photo-1544148103-0773bf10d330?w=800',
            'Nozomi — Riyadh' => 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=800',
        ];

        foreach ($restaurantImages as $name => $url) {
            Restaurant::where('name', $name)->update(['image_url' => $url]);
        }

        $this->command->info('Images seeded for all destinations, tours, events & restaurants!');
    }
}
