<?php

namespace Database\Seeders;

use App\Models\Guide;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class GuideSeeder extends Seeder
{
    public function run(): void
    {
        $guides = [
            [
                'name' => 'Fahad Al-Otaibi',
                'email' => 'fahad@sauditourism.sa',
                'bio' => 'Born and raised in Riyadh. I specialize in historical tours through Diriyah, Saudi National Museum, and the vibrant Riyadh Season events. I love showing visitors the Kingdom\'s blend of heritage and modernity.',
                'experience_years' => 8,
                'languages' => ['Arabic', 'English', 'French'],
                'phone' => '+966-50-111-2233',
                'hourly_rate' => 100,
                'hourly_rate_with_car' => 180,
                'specialization' => 'Heritage & City Tours',
                'city' => 'Riyadh',
                'has_car' => true,
                'total_tours_completed' => 320,
                'rating' => 4.9,
            ],
            [
                'name' => 'Noura Al-Harbi',
                'email' => 'noura@sauditourism.sa',
                'bio' => 'Jeddah local with deep knowledge of Al-Balad historical district, the Corniche, and Red Sea diving spots. I create personalized walking tours through the old town\'s colorful alleys and heritage buildings.',
                'experience_years' => 5,
                'languages' => ['Arabic', 'English'],
                'phone' => '+966-55-222-3344',
                'hourly_rate' => 80,
                'hourly_rate_with_car' => 150,
                'specialization' => 'Historical & Coastal Tours',
                'city' => 'Jeddah',
                'has_car' => true,
                'total_tours_completed' => 210,
                'rating' => 4.8,
            ],
            [
                'name' => 'Sultan Al-Qahtani',
                'email' => 'sultan@sauditourism.sa',
                'bio' => 'AlUla expert and certified heritage guide. I take visitors through Hegra (Madain Salih), the Elephant Rock, Maraya Concert Hall, and the ancient Nabatean tombs. Desert camping under the stars is my specialty.',
                'experience_years' => 10,
                'languages' => ['Arabic', 'English', 'German'],
                'phone' => '+966-50-333-4455',
                'hourly_rate' => 150,
                'hourly_rate_with_car' => 250,
                'specialization' => 'Heritage & Desert Adventure',
                'city' => 'AlUla',
                'has_car' => true,
                'total_tours_completed' => 450,
                'rating' => 4.95,
            ],
            [
                'name' => 'Reem Al-Dosari',
                'email' => 'reem@sauditourism.sa',
                'bio' => 'Food enthusiast and culinary tour guide in the Eastern Province. I showcase Saudi cuisine — from traditional Kabsa and Jareesh to modern fusion dining. Walking food tours through Dammam and Al-Khobar souqs.',
                'experience_years' => 4,
                'languages' => ['Arabic', 'English', 'Urdu'],
                'phone' => '+966-55-444-5566',
                'hourly_rate' => 75,
                'hourly_rate_with_car' => 140,
                'specialization' => 'Food & Culinary Tours',
                'city' => 'Dammam',
                'has_car' => false,
                'total_tours_completed' => 130,
                'rating' => 4.85,
            ],
            [
                'name' => 'Khalid Al-Shehri',
                'email' => 'khalid@sauditourism.sa',
                'bio' => 'Adventure guide specializing in Asir Mountains, Al-Soudah peaks, and Rijal Almaa heritage village. I offer hiking, trekking, and photography tours through the most beautiful mountainous landscapes in Saudi Arabia.',
                'experience_years' => 12,
                'languages' => ['Arabic', 'English'],
                'phone' => '+966-50-555-6677',
                'hourly_rate' => 90,
                'hourly_rate_with_car' => 170,
                'specialization' => 'Mountain & Adventure Tours',
                'city' => 'Abha',
                'has_car' => true,
                'total_tours_completed' => 380,
                'rating' => 4.7,
            ],
            [
                'name' => 'Aisha Al-Zahrani',
                'email' => 'aisha@sauditourism.sa',
                'bio' => 'Madinah-based guide with expertise in Islamic heritage, cultural sites, and the Prophet\'s Mosque surroundings. I provide respectful, informative tours for pilgrims and cultural travelers alike.',
                'experience_years' => 7,
                'languages' => ['Arabic', 'English', 'Turkish', 'Malay'],
                'phone' => '+966-55-666-7788',
                'hourly_rate' => 85,
                'hourly_rate_with_car' => 160,
                'specialization' => 'Islamic Heritage Tours',
                'city' => 'Madinah',
                'has_car' => true,
                'total_tours_completed' => 290,
                'rating' => 4.92,
            ],
            [
                'name' => 'Mohammed Al-Ghamdi',
                'email' => 'mohammed@sauditourism.sa',
                'bio' => 'NEOM and Tabuk region specialist. I guide visitors to the futuristic NEOM project area, Wadi Rum-like landscapes, Tabuk Castle, and the stunning beaches of Sharma and Gayal. Perfect for those who want to see Saudi\'s future.',
                'experience_years' => 6,
                'languages' => ['Arabic', 'English', 'Spanish'],
                'phone' => '+966-50-777-8899',
                'hourly_rate' => 120,
                'hourly_rate_with_car' => 220,
                'specialization' => 'Future Projects & Coastal Tours',
                'city' => 'Tabuk',
                'has_car' => true,
                'total_tours_completed' => 175,
                'rating' => 4.88,
            ],
            [
                'name' => 'Huda Al-Rashidi',
                'email' => 'huda@sauditourism.sa',
                'bio' => 'Ha\'il and northern Saudi Arabia guide specializing in desert safari, camel treks, sand dune adventures, and traditional Bedouin camping experiences. I bring the authentic Arabian desert to life.',
                'experience_years' => 9,
                'languages' => ['Arabic', 'English'],
                'phone' => '+966-55-888-9900',
                'hourly_rate' => 70,
                'hourly_rate_with_car' => 130,
                'specialization' => 'Desert Safari & Bedouin Experience',
                'city' => 'Ha\'il',
                'has_car' => true,
                'total_tours_completed' => 260,
                'rating' => 4.75,
            ],
        ];

        foreach ($guides as $data) {
            $user = User::firstOrCreate(
                ['email' => $data['email']],
                [
                    'name' => $data['name'],
                    'password' => Hash::make('password123'),
                    'role' => 'guide',
                    'status' => 'active',
                    'email_verified_at' => now(),
                ]
            );

            Guide::firstOrCreate(
                ['user_id' => $user->id],
                [
                    'bio' => $data['bio'],
                    'experience_years' => $data['experience_years'],
                    'languages' => $data['languages'],
                    'phone' => $data['phone'],
                    'hourly_rate' => $data['hourly_rate'],
                    'hourly_rate_with_car' => $data['hourly_rate_with_car'],
                    'specialization' => $data['specialization'],
                    'city' => $data['city'],
                    'has_car' => $data['has_car'],
                    'total_tours_completed' => $data['total_tours_completed'],
                    'rating' => $data['rating'],
                    'status' => 'active',
                    'verification_status' => 'verified',
                ]
            );
        }

        $this->command->info('8 Saudi guides created successfully!');
    }
}
