<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Event;
use Illuminate\Database\Seeder;

class SampleEventSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create a category first
        $category = Category::firstOrCreate(
            ['slug' => 'cultural-events'],
            [
                'name' => 'Cultural Events',
                'type' => 'event',
            ]
        );

        // Create sample events
        Event::firstOrCreate(
            ['name' => 'Riyadh Season Festival'],
            [
                'description' => 'Annual cultural festival in Riyadh with entertainment, food, and shopping',
                'category_id' => $category->id,
                'city' => 'Riyadh',
                'location_address' => 'Downtown Riyadh',
                'latitude' => 24.7136,
                'longitude' => 46.6753,
                'start_date' => now()->addDays(5)->toDateString(),
                'end_date' => now()->addDays(30)->toDateString(),
                'start_time' => '09:00',
                'end_time' => '22:00',
                'capacity' => 5000,
                'ticket_price' => 50,
                'featured' => 1,
                'status' => 'active',
            ]
        );

        Event::firstOrCreate(
            ['name' => 'Jeddah Summer Festival'],
            [
                'description' => 'Summer festival with concerts, art exhibitions, and beach activities',
                'category_id' => $category->id,
                'city' => 'Jeddah',
                'location_address' => 'Jeddah Waterfront',
                'latitude' => 21.5433,
                'longitude' => 39.1728,
                'start_date' => now()->addDays(10)->toDateString(),
                'end_date' => now()->addDays(45)->toDateString(),
                'start_time' => '10:00',
                'end_time' => '23:00',
                'capacity' => 3000,
                'ticket_price' => 35,
                'featured' => 1,
                'status' => 'active',
            ]
        );

        Event::firstOrCreate(
            ['name' => 'Al Khobar Beach Festival'],
            [
                'description' => 'Beach festival with water sports, music, and cultural performances',
                'category_id' => $category->id,
                'city' => 'Al Khobar',
                'location_address' => 'Al Khobar Beach',
                'latitude' => 26.1667,
                'longitude' => 50.2333,
                'start_date' => now()->addDays(15)->toDateString(),
                'end_date' => now()->addDays(25)->toDateString(),
                'start_time' => '08:00',
                'end_time' => '21:00',
                'capacity' => 2000,
                'ticket_price' => 25,
                'featured' => 0,
                'status' => 'active',
            ]
        );

        $this->command->info('✅ Sample events created successfully!');
    }
}
