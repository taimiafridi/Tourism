<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\DestinationController;
use App\Http\Controllers\Api\TourController;
use App\Http\Controllers\Api\BookingController;
use App\Http\Controllers\Api\ReviewController;
use App\Http\Controllers\Api\GuideController;
use App\Http\Controllers\Api\EventController;
use App\Http\Controllers\Api\EventBookingController;
use App\Http\Controllers\Api\RestaurantController;
use App\Http\Controllers\Api\FavoriteController;
use App\Http\Controllers\Api\LocationController;
use App\Http\Controllers\Admin\DestinationController as AdminDestinationController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\GuideController as AdminGuideController;
use App\Http\Controllers\Admin\BookingController as AdminBookingController;
use App\Http\Controllers\Admin\ReviewController as AdminReviewController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\EventController as AdminEventController;
use App\Http\Controllers\Admin\RestaurantController as AdminRestaurantController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\MediaController;
use App\Http\Controllers\Web\AiAssistantController;

// Public API Routes (Mobile App)
Route::prefix('v1')->group(function () {
    // Authentication
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);

    // Public Destination Routes
    Route::prefix('destinations')->group(function () {
        Route::get('/', [DestinationController::class, 'index']);
        Route::get('/{id}', [DestinationController::class, 'show']);
        Route::get('/featured/list', [DestinationController::class, 'featured']);
        Route::get('/{id}/reviews', [ReviewController::class, 'getDestinationReviews']);
    });

    // Public Tour Routes
    Route::prefix('tours')->group(function () {
        Route::get('/', [TourController::class, 'index']);
        Route::get('/{id}', [TourController::class, 'show']);
    });

    // Public Guide Routes
    Route::prefix('guides')->group(function () {
        Route::get('/', [GuideController::class, 'index']);
        Route::get('/{id}', [GuideController::class, 'show']);
        Route::get('/{id}/reviews', [GuideController::class, 'reviews']);
    });

    // Public Events Routes
    Route::prefix('events')->group(function () {
        Route::get('/', [EventController::class, 'index']);
        Route::get('/{id}', [EventController::class, 'show']);
        Route::get('/featured/list', [EventController::class, 'featured']);
        Route::get('/upcoming/list', [EventController::class, 'upcomingEvents']);
        Route::post('/nearby', [EventController::class, 'nearby']);
    });

    // Public Restaurants Routes
    Route::prefix('restaurants')->group(function () {
        Route::get('/', [RestaurantController::class, 'index']);
        Route::get('/{id}', [RestaurantController::class, 'show']);
        Route::get('/featured/list', [RestaurantController::class, 'featured']);
        Route::post('/nearby', [RestaurantController::class, 'nearby']);
        Route::get('/cuisine/{cuisine_type}', [RestaurantController::class, 'getByCuitineType']);
    });

    // Location-based Search Routes
    Route::prefix('location')->group(function () {
        Route::post('/nearby', [LocationController::class, 'nearby']);
        Route::get('/search-city', [LocationController::class, 'searchByCity']);
        Route::get('/filter-destinations', [LocationController::class, 'filterDestinations']);
        Route::post('/route', [LocationController::class, 'getRoute']);
        Route::get('/top-rated', [LocationController::class, 'getTopRated']);
    });

    // AI Tourism Chatbot
    Route::post('/ai-assistant/chat', [AiAssistantController::class, 'chat']);

    // Protected Routes (Requires Authentication)
    Route::middleware('auth:sanctum')->group(function () {
        // Auth Routes
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get('/profile', [AuthController::class, 'profile']);
        Route::put('/profile', [AuthController::class, 'updateProfile']);

        // Booking Routes
        Route::prefix('bookings')->group(function () {
            Route::post('/', [BookingController::class, 'store']);
            Route::get('/', [BookingController::class, 'index']);
            Route::get('/{id}', [BookingController::class, 'show']);
            Route::post('/{id}/cancel', [BookingController::class, 'cancel']);
        });

        // Review Routes
        Route::prefix('reviews')->group(function () {
            Route::post('/', [ReviewController::class, 'store']);
        });

        // Guide Application
        Route::post('/guides/apply', [GuideController::class, 'apply']);

        // Create Tour (Only for guides)
        Route::post('/tours', [TourController::class, 'store']);

        // Event Booking Routes
        Route::prefix('event-bookings')->group(function () {
            Route::post('/', [EventBookingController::class, 'store']);
            Route::get('/', [EventBookingController::class, 'index']);
            Route::get('/{id}', [EventBookingController::class, 'show']);
            Route::post('/{id}/cancel', [EventBookingController::class, 'cancel']);
        });

        // Event Reviews
        Route::post('/events/{id}/review', [EventController::class, 'leaveReview']);

        // Restaurant Reviews
        Route::post('/restaurants/{id}/review', [RestaurantController::class, 'leaveReview']);

        // Favorites/Wishlist Routes
        Route::prefix('favorites')->group(function () {
            Route::get('/', [FavoriteController::class, 'index']);
            Route::post('/add', [FavoriteController::class, 'add']);
            Route::post('/remove', [FavoriteController::class, 'remove']);
            Route::post('/toggle', [FavoriteController::class, 'toggle']);
            Route::post('/check', [FavoriteController::class, 'isFavorited']);
            Route::get('/wishlist', [FavoriteController::class, 'getWishlist']);
            Route::delete('/clear', [FavoriteController::class, 'clearFavorites']);
        });
    });
});

// Admin API Routes
Route::prefix('admin')->middleware(['auth:sanctum', 'admin'])->group(function () {
    // Dashboard
    Route::get('/dashboard/statistics', [DashboardController::class, 'statistics']);
    Route::get('/dashboard/revenue', [DashboardController::class, 'revenueAnalytics']);
    Route::get('/dashboard/top-destinations', [DashboardController::class, 'topDestinations']);
    Route::get('/dashboard/recent-bookings', [DashboardController::class, 'recentBookings']);
    Route::get('/dashboard/top-guides', [DashboardController::class, 'topGuides']);

    // Destinations
    Route::prefix('destinations')->group(function () {
        Route::get('/', [AdminDestinationController::class, 'index']);
        Route::post('/', [AdminDestinationController::class, 'store']);
        Route::put('/{id}', [AdminDestinationController::class, 'update']);
        Route::delete('/{id}', [AdminDestinationController::class, 'destroy']);
    });

    // Users
    Route::prefix('users')->group(function () {
        Route::get('/', [UserController::class, 'index']);
        Route::get('/{id}', [UserController::class, 'show']);
        Route::put('/{id}/status', [UserController::class, 'updateStatus']);
        Route::put('/{id}/role', [UserController::class, 'updateRole']);
        Route::delete('/{id}', [UserController::class, 'destroy']);
    });

    // Guides
    Route::prefix('guides')->group(function () {
        Route::get('/', [AdminGuideController::class, 'index']);
        Route::get('/{id}', [AdminGuideController::class, 'show']);
        Route::post('/{id}/verify', [AdminGuideController::class, 'verify']);
        Route::post('/{id}/reject', [AdminGuideController::class, 'reject']);
        Route::put('/{id}/status', [AdminGuideController::class, 'updateStatus']);
    });

    // Bookings
    Route::prefix('bookings')->group(function () {
        Route::get('/', [AdminBookingController::class, 'index']);
        Route::get('/{id}', [AdminBookingController::class, 'show']);
        Route::put('/{id}/status', [AdminBookingController::class, 'updateStatus']);
        Route::put('/{id}/payment-status', [AdminBookingController::class, 'updatePaymentStatus']);
    });

    // Reviews
    Route::prefix('reviews')->group(function () {
        Route::get('/destinations', [AdminReviewController::class, 'destinationReviews']);
        Route::get('/guides', [AdminReviewController::class, 'guideReviews']);
        Route::post('/destinations/{id}/approve', [AdminReviewController::class, 'approveDestinationReview']);
        Route::post('/destinations/{id}/reject', [AdminReviewController::class, 'rejectDestinationReview']);
        Route::post('/guides/{id}/approve', [AdminReviewController::class, 'approveGuideReview']);
        Route::post('/guides/{id}/reject', [AdminReviewController::class, 'rejectGuideReview']);
    });

    // Events Management
    Route::prefix('events')->group(function () {
        Route::get('/', [AdminEventController::class, 'index']);
        Route::post('/', [AdminEventController::class, 'store']);
        Route::get('/{id}', [AdminEventController::class, 'show']);
        Route::put('/{id}', [AdminEventController::class, 'update']);
        Route::delete('/{id}', [AdminEventController::class, 'destroy']);
        Route::get('/stats/overview', [AdminEventController::class, 'getEventStats']);
    });

    // Restaurants Management
    Route::prefix('restaurants')->group(function () {
        Route::get('/', [AdminRestaurantController::class, 'index']);
        Route::post('/', [AdminRestaurantController::class, 'store']);
        Route::get('/{id}', [AdminRestaurantController::class, 'show']);
        Route::put('/{id}', [AdminRestaurantController::class, 'update']);
        Route::delete('/{id}', [AdminRestaurantController::class, 'destroy']);
    });

    // Categories Management
    Route::prefix('categories')->group(function () {
        Route::get('/', [CategoryController::class, 'index']);
        Route::post('/', [CategoryController::class, 'store']);
        Route::get('/{id}', [CategoryController::class, 'show']);
        Route::put('/{id}', [CategoryController::class, 'update']);
        Route::delete('/{id}', [CategoryController::class, 'destroy']);
        Route::get('/type/{type}', [CategoryController::class, 'getByType']);
    });

    // Media Management
    Route::prefix('media')->group(function () {
        Route::post('/add', [MediaController::class, 'addMedia']);
        Route::get('/gallery', [MediaController::class, 'getGallery']);
        Route::put('/{id}', [MediaController::class, 'updateMedia']);
        Route::delete('/{id}', [MediaController::class, 'deleteMedia']);
        Route::post('/bulk-upload', [MediaController::class, 'bulkUpload']);
        Route::post('/reorder', [MediaController::class, 'reorderMedia']);
    });

    // Event Booking Management
    Route::prefix('event-bookings')->group(function () {
        Route::get('/', [AdminBookingController::class, 'index']);
        Route::get('/{id}', [AdminBookingController::class, 'show']);
        Route::put('/{id}/status', [AdminBookingController::class, 'updateStatus']);
        Route::put('/{id}/payment-status', [AdminBookingController::class, 'updatePaymentStatus']);
    });
});
