<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Web\HomeController;
use App\Http\Controllers\Web\AuthController;
use App\Http\Controllers\Web\AdminAuthController;
use App\Http\Controllers\Web\AdminDashboardController;
use App\Http\Controllers\Web\GuideController;
use App\Http\Controllers\Web\PageController;
use App\Http\Controllers\Web\AiAssistantController;
use App\Http\Controllers\Web\BookingController;

/*
|--------------------------------------------------------------------------
| Public Routes (No login required)
|--------------------------------------------------------------------------
*/
Route::get('/', [HomeController::class, 'index'])->name('home');

// AI Travel Assistant
Route::get('/ai-assistant', [AiAssistantController::class, 'index'])->name('ai-assistant');
Route::post('/ai-assistant/chat', [AiAssistantController::class, 'chat'])->name('ai-assistant.chat');

// Public browsing pages with real data
Route::get('/destinations', [PageController::class, 'destinations'])->name('destinations');
Route::get('/destinations/{destination}', [PageController::class, 'destinationDetail'])->name('destinations.show');
Route::get('/tours', [PageController::class, 'tours'])->name('tours');
Route::get('/events', [PageController::class, 'events'])->name('events');
Route::get('/restaurants', [PageController::class, 'restaurants'])->name('restaurants');

// Guides - public browsing with full hire functionality
Route::get('/guides', [GuideController::class, 'index'])->name('guides');
Route::get('/guides/{id}', [GuideController::class, 'show'])->name('guides.show');

/*
|--------------------------------------------------------------------------
| Authentication Routes (Guest only)
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
});

Route::match(['get', 'post'], '/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

/*
|--------------------------------------------------------------------------
| Protected Routes (Login required - redirects to /login if not logged in)
|--------------------------------------------------------------------------
*/
Route::middleware('auth')->group(function () {
    Route::get('/my-bookings', [BookingController::class, 'myBookings'])->name('my-bookings');
    Route::get('/favorites', function () {
        $favorites = auth()->user()->favorites()->with('favoritable')->latest()->get();
        return view('pages.favorites', compact('favorites'));
    })->name('favorites');
    Route::post('/favorites/toggle', function (\Illuminate\Http\Request $request) {
        $validated = $request->validate([
            'type' => 'required|in:destination,event,restaurant,tour',
            'item_id' => 'required|integer',
        ]);
        $modelMap = [
            'destination' => 'App\\Models\\Destination',
            'event' => 'App\\Models\\Event',
            'restaurant' => 'App\\Models\\Restaurant',
            'tour' => 'App\\Models\\Tour',
        ];
        $modelClass = $modelMap[$validated['type']];
        $existing = \App\Models\UserFavorite::where('user_id', auth()->id())
            ->where('favoritable_type', $modelClass)
            ->where('favoritable_id', $validated['item_id'])
            ->first();
        if ($existing) {
            $existing->delete();
            return response()->json(['is_favorited' => false]);
        }
        $modelClass::findOrFail($validated['item_id']);
        \App\Models\UserFavorite::create([
            'user_id' => auth()->id(),
            'favoritable_type' => $modelClass,
            'favoritable_id' => $validated['item_id'],
        ]);
        return response()->json(['is_favorited' => true]);
    })->name('favorites.toggle');

    // Book Tour
    Route::get('/tours/{tour}/book', [BookingController::class, 'showTourBooking'])->name('tours.book');
    Route::post('/tours/{tour}/book', [BookingController::class, 'submitTourBooking'])->name('tours.book.submit');

    // Book Event
    Route::get('/events/{event}/book', [BookingController::class, 'showEventBooking'])->name('events.book');
    Route::post('/events/{event}/book', [BookingController::class, 'submitEventBooking'])->name('events.book.submit');

    // Hire Guide (requires login)
    Route::get('/guides/{id}/hire', [GuideController::class, 'hire'])->name('guides.hire');
    Route::post('/guides/{id}/hire', [GuideController::class, 'submitHire'])->name('guides.hire.submit');
});

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
*/
// Admin Login (separate login page)
Route::get('/admin-login', [AdminAuthController::class, 'showLogin'])->name('admin.login');
Route::post('/admin-login', [AdminAuthController::class, 'login'])->name('admin.login.submit');

// Admin Dashboard (requires auth + admin role)
Route::prefix('dashboard')->middleware(['auth', 'admin.web'])->group(function () {
    Route::get('/', [AdminDashboardController::class, 'index'])->name('admin.dashboard');
    Route::get('/users', [AdminDashboardController::class, 'users'])->name('admin.users');
    Route::get('/destinations', [AdminDashboardController::class, 'destinations'])->name('admin.destinations');
    Route::get('/tours', [AdminDashboardController::class, 'tours'])->name('admin.tours');
    Route::get('/bookings', [AdminDashboardController::class, 'bookings'])->name('admin.bookings');
    Route::get('/guides', [AdminDashboardController::class, 'guides'])->name('admin.guides');
    Route::get('/events', [AdminDashboardController::class, 'events'])->name('admin.events');
    Route::get('/restaurants', [AdminDashboardController::class, 'restaurants'])->name('admin.restaurants');
    Route::get('/reviews', [AdminDashboardController::class, 'reviews'])->name('admin.reviews');
});
