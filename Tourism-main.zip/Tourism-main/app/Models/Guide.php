<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Guide extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'bio',
        'experience_years',
        'languages',
        'phone',
        'iqama_number',
        'nationality',
        'driving_license',
        'description',
        'hourly_rate',
        'hourly_rate_with_car',
        'specialization',
        'city',
        'profile_photo',
        'has_car',
        'total_tours_completed',
        'rating',
        'status',
        'verification_status',
    ];

    protected $casts = [
        'languages' => 'array',
        'rating' => 'float',
        'hourly_rate' => 'decimal:2',
        'hourly_rate_with_car' => 'decimal:2',
        'has_car' => 'boolean',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function tours()
    {
        return $this->hasMany(Tour::class);
    }

    public function bookings()
    {
        return $this->hasMany(Booking::class);
    }

    public function reviews()
    {
        return $this->hasMany(GuideReview::class);
    }

    public function guideBookings()
    {
        return $this->hasMany(GuideBooking::class);
    }
}
