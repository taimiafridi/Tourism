<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Restaurant extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'category_id',
        'cuisine_type',
        'city',
        'location_address',
        'latitude',
        'longitude',
        'phone',
        'email',
        'website',
        'opening_time',
        'closing_time',
        'average_cost',
        'image_url',
        'rating',
        'status',
        'featured',
    ];

    protected $casts = [
        'latitude' => 'float',
        'longitude' => 'float',
        'average_cost' => 'decimal:2',
        'rating' => 'float',
        'featured' => 'boolean',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function reviews()
    {
        return $this->hasMany(RestaurantReview::class);
    }

    public function galleryItems()
    {
        return $this->morphMany(MediaGallery::class, 'galleryable');
    }

    public function averageRating()
    {
        return $this->reviews()->where('status', 'approved')->avg('rating') ?? 0;
    }
}
