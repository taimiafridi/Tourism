<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ItineraryItem extends Model
{
    use HasFactory;

    protected $fillable = [
        'tour_id',
        'day',
        'title',
        'description',
        'location',
        'duration_hours',
        'activities',
    ];

    protected $casts = [
        'activities' => 'array',
    ];

    public function tour()
    {
        return $this->belongsTo(Tour::class);
    }
}
