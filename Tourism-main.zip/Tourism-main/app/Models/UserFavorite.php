<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserFavorite extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'favoritable_type',
        'favoritable_id',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function favoritable()
    {
        return $this->morphTo();
    }

    // Quick accessors for common types
    public function destination()
    {
        if ($this->favoritable_type === 'App\\Models\\Destination') {
            return $this->favoritable;
        }
        return null;
    }

    public function event()
    {
        if ($this->favoritable_type === 'App\\Models\\Event') {
            return $this->favoritable;
        }
        return null;
    }

    public function restaurant()
    {
        if ($this->favoritable_type === 'App\\Models\\Restaurant') {
            return $this->favoritable;
        }
        return null;
    }
}
