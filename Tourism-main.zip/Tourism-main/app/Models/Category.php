<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'slug',
        'description',
        'icon_url',
        'type', // 'destination', 'event', 'restaurant'
        'status',
    ];

    protected $casts = [
        'status' => 'string',
    ];

    public function destinations()
    {
        return $this->hasMany(Destination::class);
    }

    public function events()
    {
        return $this->hasMany(Event::class);
    }

    public function restaurants()
    {
        return $this->hasMany(Restaurant::class);
    }
}
