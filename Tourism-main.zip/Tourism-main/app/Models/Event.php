<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'category_id',
        'city',
        'location_address',
        'latitude',
        'longitude',
        'start_date',
        'end_date',
        'start_time',
        'end_time',
        'ticket_price',
        'capacity',
        'image_url',
        'status',
        'featured',
    ];

    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date',
        'latitude' => 'float',
        'longitude' => 'float',
        'ticket_price' => 'decimal:2',
        'featured' => 'boolean',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function bookings()
    {
        return $this->hasMany(EventBooking::class);
    }

    public function reviews()
    {
        return $this->hasMany(EventReview::class);
    }

    public function galleryItems()
    {
        return $this->morphMany(MediaGallery::class, 'galleryable');
    }

    public function getAttendeesCountAttribute()
    {
        return $this->bookings()->where('status', 'confirmed')->sum('number_of_tickets');
    }
}
