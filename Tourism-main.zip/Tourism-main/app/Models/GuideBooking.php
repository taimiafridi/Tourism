<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GuideBooking extends Model
{
    use HasFactory;

    protected $fillable = [
        'guide_id',
        'user_id',
        'booking_date',
        'start_time',
        'duration_hours',
        'service_type',
        'group_size',
        'total_price',
        'special_requests',
        'meeting_point',
        'status',
        'payment_status',
    ];

    protected $casts = [
        'booking_date' => 'date',
        'total_price' => 'decimal:2',
    ];

    public function guide()
    {
        return $this->belongsTo(Guide::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
