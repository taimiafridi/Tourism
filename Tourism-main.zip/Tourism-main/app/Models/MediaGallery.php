<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MediaGallery extends Model
{
    use HasFactory;

    protected $table = 'media_galleries';

    protected $fillable = [
        'galleryable_type',
        'galleryable_id',
        'media_url',
        'media_type', // 'image', 'video'
        'title',
        'description',
        'order',
    ];

    protected $casts = [
        'order' => 'integer',
    ];

    public function galleryable()
    {
        return $this->morphTo();
    }
}
