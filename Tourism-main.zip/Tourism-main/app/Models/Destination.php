<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Destination extends Model
{
    use HasFactory;

    protected $fillable = [
        'category_id',
        'name',
        'description',
        'city',
        'country',
        'latitude',
        'longitude',
        'image_url',
        'best_time_to_visit',
        'entry_fee',
        'status',
        'featured',
    ];

    protected $casts = [
        'latitude' => 'float',
        'longitude' => 'float',
        'entry_fee' => 'decimal:2',
        'featured' => 'boolean',
    ];

    public function tours()
    {
        return $this->hasMany(Tour::class);
    }

    public function reviews()
    {
        return $this->hasMany(Review::class);
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function galleryItems()
    {
        return $this->morphMany(MediaGallery::class, 'galleryable');
    }

    public function favoritedBy()
    {
        return $this->morphMany(UserFavorite::class, 'favoritable');
    }

    public function ratings()
    {
        return $this->reviews()->avg('rating');
    }
}
