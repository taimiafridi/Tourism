<?php

namespace App\Http\Controllers\Admin;

use App\Models\Review;
use App\Models\GuideReview;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class ReviewController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('admin');
    }

    public function destinationReviews(Request $request)
    {
        $query = Review::with(['user', 'destination']);

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $reviews = $query->latest()->paginate($request->get('per_page', 15));
        return response()->json($reviews);
    }

    public function guideReviews(Request $request)
    {
        $query = GuideReview::with(['user', 'guide']);

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $reviews = $query->latest()->paginate($request->get('per_page', 15));
        return response()->json($reviews);
    }

    public function approveDestinationReview($id)
    {
        $review = Review::findOrFail($id);
        $review->update(['status' => 'approved']);

        return response()->json(['message' => 'Review approved', 'review' => $review]);
    }

    public function rejectDestinationReview($id)
    {
        $review = Review::findOrFail($id);
        $review->update(['status' => 'rejected']);

        return response()->json(['message' => 'Review rejected', 'review' => $review]);
    }

    public function approveGuideReview($id)
    {
        $review = GuideReview::findOrFail($id);
        $review->update(['status' => 'approved']);

        return response()->json(['message' => 'Review approved', 'review' => $review]);
    }

    public function rejectGuideReview($id)
    {
        $review = GuideReview::findOrFail($id);
        $review->update(['status' => 'rejected']);

        return response()->json(['message' => 'Review rejected', 'review' => $review]);
    }
}
