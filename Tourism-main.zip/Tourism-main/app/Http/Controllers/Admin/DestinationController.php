<?php

namespace App\Http\Controllers\Admin;

use App\Models\Destination;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class DestinationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('admin');
    }

    public function index(Request $request)
    {
        $destinations = Destination::paginate($request->get('per_page', 15));
        return response()->json($destinations);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string',
            'description' => 'required|string',
            'city' => 'required|string',
            'country' => 'required|string',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
            'image_url' => 'nullable|url',
            'best_time_to_visit' => 'nullable|string',
            'entry_fee' => 'nullable|numeric',
            'featured' => 'boolean',
        ]);

        $destination = Destination::create($validated);
        return response()->json($destination, 201);
    }

    public function update(Request $request, $id)
    {
        $destination = Destination::findOrFail($id);

        $validated = $request->validate([
            'name' => 'string',
            'description' => 'string',
            'city' => 'string',
            'country' => 'string',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
            'image_url' => 'nullable|url',
            'best_time_to_visit' => 'nullable|string',
            'entry_fee' => 'nullable|numeric',
            'status' => 'in:active,inactive,archived',
            'featured' => 'boolean',
        ]);

        $destination->update($validated);
        return response()->json($destination);
    }

    public function destroy($id)
    {
        $destination = Destination::findOrFail($id);
        $destination->delete();
        return response()->json(['message' => 'Destination deleted']);
    }
}
