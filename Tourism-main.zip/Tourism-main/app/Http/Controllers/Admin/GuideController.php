<?php

namespace App\Http\Controllers\Admin;

use App\Models\Guide;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class GuideController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('admin');
    }

    public function index(Request $request)
    {
        $query = Guide::with('user');

        if ($request->has('verification_status')) {
            $query->where('verification_status', $request->verification_status);
        }

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $guides = $query->paginate($request->get('per_page', 15));
        return response()->json($guides);
    }

    public function show($id)
    {
        $guide = Guide::with(['user', 'tours', 'bookings', 'reviews'])->findOrFail($id);
        return response()->json($guide);
    }

    public function verify($id)
    {
        $guide = Guide::findOrFail($id);
        $guide->update(['verification_status' => 'verified']);

        return response()->json(['message' => 'Guide verified', 'guide' => $guide]);
    }

    public function reject(Request $request, $id)
    {
        $validated = $request->validate([
            'reason' => 'nullable|string',
        ]);

        $guide = Guide::findOrFail($id);
        $guide->update(['verification_status' => 'rejected']);

        return response()->json(['message' => 'Guide application rejected', 'guide' => $guide]);
    }

    public function updateStatus(Request $request, $id)
    {
        $validated = $request->validate([
            'status' => 'required|in:active,inactive,suspended',
        ]);

        $guide = Guide::findOrFail($id);
        $guide->update(['status' => $validated['status']]);

        return response()->json(['message' => 'Guide status updated', 'guide' => $guide]);
    }
}
