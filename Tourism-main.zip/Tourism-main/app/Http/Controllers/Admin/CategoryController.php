<?php

namespace App\Http\Controllers\Admin;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Str;

class CategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('admin');
    }

    public function index(Request $request)
    {
        $query = Category::query();

        if ($request->has('type')) {
            $query->where('type', $request->type);
        }

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $categories = $query->paginate($request->get('per_page', 15));
        return response()->json($categories);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|unique:categories',
            'description' => 'nullable|string',
            'icon_url' => 'nullable|url',
            'type' => 'required|in:destination,event,restaurant',
        ]);

        $category = Category::create([
            ...$validated,
            'slug' => Str::slug($validated['name']),
            'status' => 'active',
        ]);

        return response()->json($category, 201);
    }

    public function show($id)
    {
        $category = Category::findOrFail($id);
        return response()->json($category);
    }

    public function update(Request $request, $id)
    {
        $category = Category::findOrFail($id);

        $validated = $request->validate([
            'name' => 'string|unique:categories,name,' . $id,
            'description' => 'nullable|string',
            'icon_url' => 'nullable|url',
            'type' => 'in:destination,event,restaurant',
            'status' => 'in:active,inactive',
        ]);

        if ($request->has('name')) {
            $validated['slug'] = Str::slug($validated['name']);
        }

        $category->update($validated);
        return response()->json($category);
    }

    public function destroy($id)
    {
        $category = Category::findOrFail($id);
        
        // Check if category has items
        if ($category->destinations()->exists() || 
            $category->events()->exists() || 
            $category->restaurants()->exists()) {
            return response()->json(['message' => 'Cannot delete category with existing items'], 400);
        }

        $category->delete();
        return response()->json(['message' => 'Category deleted']);
    }

    public function getByType($type)
    {
        if (!in_array($type, ['destination', 'event', 'restaurant'])) {
            return response()->json(['message' => 'Invalid category type'], 400);
        }

        $categories = Category::where('type', $type)
            ->where('status', 'active')
            ->get();

        return response()->json($categories);
    }
}
