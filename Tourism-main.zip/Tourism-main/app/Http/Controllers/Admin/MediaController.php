<?php

namespace App\Http\Controllers\Admin;

use App\Models\MediaGallery;
use App\Models\Destination;
use App\Models\Event;
use App\Models\Restaurant;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class MediaController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('admin');
    }

    public function addMedia(Request $request)
    {
        $validated = $request->validate([
            'type' => 'required|in:destination,event,restaurant',
            'item_id' => 'required|integer',
            'media_url' => 'required|url',
            'media_type' => 'required|in:image,video',
            'title' => 'nullable|string',
            'description' => 'nullable|string',
            'order' => 'nullable|integer',
        ]);

        $modelMap = [
            'destination' => 'App\\Models\\Destination',
            'event' => 'App\\Models\\Event',
            'restaurant' => 'App\\Models\\Restaurant',
        ];

        $modelClass = $modelMap[$validated['type']];

        // Verify item exists
        $modelClass::findOrFail($validated['item_id']);

        $media = MediaGallery::create([
            'galleryable_type' => $modelClass,
            'galleryable_id' => $validated['item_id'],
            'media_url' => $validated['media_url'],
            'media_type' => $validated['media_type'],
            'title' => $validated['title'],
            'description' => $validated['description'],
            'order' => $validated['order'] ?? 0,
        ]);

        return response()->json($media, 201);
    }

    public function getGallery(Request $request)
    {
        $validated = $request->validate([
            'type' => 'required|in:destination,event,restaurant',
            'item_id' => 'required|integer',
        ]);

        $modelMap = [
            'destination' => 'App\\Models\\Destination',
            'event' => 'App\\Models\\Event',
            'restaurant' => 'App\\Models\\Restaurant',
        ];

        $modelClass = $modelMap[$validated['type']];

        $media = MediaGallery::where('galleryable_type', $modelClass)
            ->where('galleryable_id', $validated['item_id'])
            ->orderBy('order')
            ->get();

        return response()->json($media);
    }

    public function updateMedia(Request $request, $mediaId)
    {
        $media = MediaGallery::findOrFail($mediaId);

        $validated = $request->validate([
            'title' => 'nullable|string',
            'description' => 'nullable|string',
            'order' => 'nullable|integer',
        ]);

        $media->update($validated);
        return response()->json($media);
    }

    public function deleteMedia($mediaId)
    {
        $media = MediaGallery::findOrFail($mediaId);
        $media->delete();

        return response()->json(['message' => 'Media deleted']);
    }

    public function bulkUpload(Request $request)
    {
        $validated = $request->validate([
            'type' => 'required|in:destination,event,restaurant',
            'item_id' => 'required|integer',
            'media_urls' => 'required|array',
            'media_urls.*' => 'url',
        ]);

        $modelMap = [
            'destination' => 'App\\Models\\Destination',
            'event' => 'App\\Models\\Event',
            'restaurant' => 'App\\Models\\Restaurant',
        ];

        $modelClass = $modelMap[$validated['type']];
        
        // Verify item exists
        $modelClass::findOrFail($validated['item_id']);

        $mediaItems = [];
        $order = 0;

        foreach ($validated['media_urls'] as $url) {
            $media = MediaGallery::create([
                'galleryable_type' => $modelClass,
                'galleryable_id' => $validated['item_id'],
                'media_url' => $url,
                'media_type' => 'image',
                'order' => $order++,
            ]);

            $mediaItems[] = $media;
        }

        return response()->json(['message' => 'Media uploaded successfully', 'media' => $mediaItems], 201);
    }

    public function reorderMedia(Request $request)
    {
        $validated = $request->validate([
            'media_ids' => 'required|array',
        ]);

        foreach ($validated['media_ids'] as $index => $mediaId) {
            MediaGallery::where('id', $mediaId)->update(['order' => $index]);
        }

        return response()->json(['message' => 'Media reordered successfully']);
    }
}
