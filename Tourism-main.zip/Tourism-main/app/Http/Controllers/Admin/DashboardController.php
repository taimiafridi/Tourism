<?php

namespace App\Http\Controllers\Admin;

use App\Models\Booking;
use App\Models\Destination;
use App\Models\Guide;
use App\Models\Tour;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('admin');
    }

    public function statistics()
    {
        $stats = [
            'total_users' => User::count(),
            'total_guides' => Guide::count(),
            'total_destinations' => Destination::count(),
            'total_tours' => Tour::count(),
            'total_bookings' => Booking::count(),
            'pending_reviews' => \App\Models\Review::where('status', 'pending')->count(),
            'active_users' => User::where('status', 'active')->count(),
            'verified_guides' => Guide::where('verification_status', 'verified')->count(),
        ];

        return response()->json($stats);
    }

    public function revenueAnalytics(Request $request)
    {
        $period = $request->get('period', 'month'); // day, week, month, year

        $query = Booking::where('payment_status', 'completed');

        $groupBy = match ($period) {
            'day' => 'DATE(created_at)',
            'week' => 'WEEK(created_at)',
            'year' => 'YEAR(created_at)',
            default => 'DATE_FORMAT(created_at, "%Y-%m")',
        };

        $revenue = $query->selectRaw("$groupBy as period, SUM(total_price) as revenue, COUNT(*) as bookings")
            ->groupByRaw($groupBy)
            ->get();

        return response()->json($revenue);
    }

    public function topDestinations()
    {
        $topDestinations = Destination::withCount('tours')
            ->withCount(['bookings' => function ($query) {
                $query->via('tours');
            }])
            ->orderByDesc('bookings_count')
            ->limit(10)
            ->get();

        return response()->json($topDestinations);
    }

    public function recentBookings($limit = 10)
    {
        $bookings = Booking::with(['user', 'tour'])
            ->latest()
            ->limit($limit)
            ->get();

        return response()->json($bookings);
    }

    public function topGuides()
    {
        $guides = Guide::withAvg('reviews', 'rating')
            ->withCount('bookings')
            ->orderByDesc('reviews_avg_rating')
            ->limit(10)
            ->get();

        return response()->json($guides);
    }
}
