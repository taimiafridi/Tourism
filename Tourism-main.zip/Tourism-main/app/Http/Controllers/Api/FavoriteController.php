<?php

namespace App\Http\Controllers\Api;

use App\Models\UserFavorite;
use App\Models\Destination;
use App\Models\Event;
use App\Models\Restaurant;
use App\Models\Tour;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class FavoriteController extends Controller
{
    private const MODEL_MAP = [
        'destination' => 'App\\Models\\Destination',
        'event' => 'App\\Models\\Event',
        'restaurant' => 'App\\Models\\Restaurant',
        'tour' => 'App\\Models\\Tour',
    ];

    public function index(Request $request)
    {
        $type = $request->get('type');

        $query = auth()->user()->favorites();

        if ($type && $type !== 'all' && isset(self::MODEL_MAP[$type])) {
            $query->where('favoritable_type', self::MODEL_MAP[$type]);
        }

        $favorites = $query->with('favoritable')
            ->latest()
            ->paginate($request->get('per_page', 15));

        return response()->json($favorites);
    }

    public function add(Request $request)
    {
        $validated = $request->validate([
            'type' => 'required|in:destination,event,restaurant,tour',
            'item_id' => 'required|integer',
        ]);

        $modelClass = self::MODEL_MAP[$validated['type']];
        $modelClass::findOrFail($validated['item_id']);

        $exists = UserFavorite::where('user_id', auth()->id())
            ->where('favoritable_type', $modelClass)
            ->where('favoritable_id', $validated['item_id'])
            ->exists();

        if ($exists) {
            return response()->json(['message' => 'Already in favorites'], 400);
        }

        $favorite = UserFavorite::create([
            'user_id' => auth()->id(),
            'favoritable_type' => $modelClass,
            'favoritable_id' => $validated['item_id'],
        ]);

        return response()->json(['message' => 'Added to favorites', 'favorite' => $favorite], 201);
    }

    public function remove(Request $request)
    {
        $validated = $request->validate([
            'type' => 'required|in:destination,event,restaurant,tour',
            'item_id' => 'required|integer',
        ]);

        $modelClass = self::MODEL_MAP[$validated['type']];

        UserFavorite::where('user_id', auth()->id())
            ->where('favoritable_type', $modelClass)
            ->where('favoritable_id', $validated['item_id'])
            ->delete();

        return response()->json(['message' => 'Removed from favorites']);
    }

    public function toggle(Request $request)
    {
        $validated = $request->validate([
            'type' => 'required|in:destination,event,restaurant,tour',
            'item_id' => 'required|integer',
        ]);

        $modelClass = self::MODEL_MAP[$validated['type']];
        $modelClass::findOrFail($validated['item_id']);

        $existing = UserFavorite::where('user_id', auth()->id())
            ->where('favoritable_type', $modelClass)
            ->where('favoritable_id', $validated['item_id'])
            ->first();

        if ($existing) {
            $existing->delete();
            return response()->json(['message' => 'Removed from favorites', 'is_favorited' => false]);
        }

        UserFavorite::create([
            'user_id' => auth()->id(),
            'favoritable_type' => $modelClass,
            'favoritable_id' => $validated['item_id'],
        ]);

        return response()->json(['message' => 'Added to favorites', 'is_favorited' => true], 201);
    }

    public function isFavorited(Request $request)
    {
        $validated = $request->validate([
            'type' => 'required|in:destination,event,restaurant,tour',
            'item_id' => 'required|integer',
        ]);

        $modelClass = self::MODEL_MAP[$validated['type']];

        $isFavorited = UserFavorite::where('user_id', auth()->id())
            ->where('favoritable_type', $modelClass)
            ->where('favoritable_id', $validated['item_id'])
            ->exists();

        return response()->json(['is_favorited' => $isFavorited]);
    }

    public function getWishlist(Request $request)
    {
        $favorites = auth()->user()->favorites()
            ->with('favoritable')
            ->latest()
            ->get();

        $grouped = [
            'destinations' => [],
            'tours' => [],
            'events' => [],
            'restaurants' => [],
        ];

        foreach ($favorites as $fav) {
            if (!$fav->favoritable) continue;
            match ($fav->favoritable_type) {
                'App\\Models\\Destination' => $grouped['destinations'][] = $fav,
                'App\\Models\\Tour' => $grouped['tours'][] = $fav,
                'App\\Models\\Event' => $grouped['events'][] = $fav,
                'App\\Models\\Restaurant' => $grouped['restaurants'][] = $fav,
                default => null,
            };
        }

        return response()->json([
            'data' => $grouped,
            'counts' => [
                'destinations' => count($grouped['destinations']),
                'tours' => count($grouped['tours']),
                'events' => count($grouped['events']),
                'restaurants' => count($grouped['restaurants']),
                'total' => $favorites->count(),
            ],
        ]);
    }

    public function clearFavorites()
    {
        auth()->user()->favorites()->delete();
        return response()->json(['message' => 'All favorites cleared']);
    }
}
