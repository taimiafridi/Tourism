<?php

namespace App\Http\Controllers\Api;

use App\Models\Booking;
use App\Models\Tour;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class BookingController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'tour_id' => 'required|exists:tours,id',
            'number_of_participants' => 'required|integer|min:1',
            'payment_method' => 'required|in:card,wallet,cod',
        ]);

        $tour = Tour::findOrFail($validated['tour_id']);

        // Check available spots
        $bookedParticipants = Booking::where('tour_id', $tour->id)
            ->whereIn('status', ['confirmed', 'pending'])
            ->sum('number_of_participants');

        if ($bookedParticipants + $validated['number_of_participants'] > $tour->max_participants) {
            return response()->json(['message' => 'Not enough spots available'], 400);
        }

        $booking = Booking::create([
            'tour_id' => $validated['tour_id'],
            'user_id' => auth()->id(),
            'guide_id' => $tour->guide_id,
            'number_of_participants' => $validated['number_of_participants'],
            'total_price' => $tour->price * $validated['number_of_participants'],
            'booking_date' => now(),
            'payment_method' => $validated['payment_method'],
            'status' => 'pending',
            'payment_status' => 'pending',
        ]);

        return response()->json($booking, 201);
    }

    public function index(Request $request)
    {
        $bookings = Booking::where('user_id', auth()->id())
            ->with(['tour.destination', 'guide'])
            ->latest()
            ->paginate($request->get('per_page', 15));

        return response()->json($bookings);
    }

    public function show($id)
    {
        $booking = Booking::findOrFail($id);

        if ($booking->user_id !== auth()->id()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        return response()->json($booking->load(['tour', 'guide']));
    }

    public function cancel($id)
    {
        $booking = Booking::findOrFail($id);

        if ($booking->user_id !== auth()->id()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        if (!in_array($booking->status, ['pending', 'confirmed'])) {
            return response()->json(['message' => 'Cannot cancel this booking'], 400);
        }

        $booking->update(['status' => 'cancelled']);
        return response()->json($booking);
    }
}
