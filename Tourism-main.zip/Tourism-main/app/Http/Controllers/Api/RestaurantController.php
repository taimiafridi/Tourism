<?php

namespace App\Http\Controllers\Api;

use App\Models\Restaurant;
use App\Models\RestaurantReview;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class RestaurantController extends Controller
{
    public function index(Request $request)
    {
        $query = Restaurant::where('status', 'active');

        if ($request->has('search')) {
            $query->where('name', 'like', '%' . $request->search . '%')
                ->orWhere('cuisine_type', 'like', '%' . $request->search . '%');
        }

        if ($request->has('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        if ($request->has('city')) {
            $query->where('city', $request->city);
        }

        if ($request->has('cuisine_type')) {
            $query->where('cuisine_type', $request->cuisine_type);
        }

        if ($request->has('min_price')) {
            $query->where('average_cost', '>=', $request->min_price);
        }

        if ($request->has('max_price')) {
            $query->where('average_cost', '<=', $request->max_price);
        }

        if ($request->has('min_rating')) {
            $query->where('rating', '>=', $request->min_rating);
        }

        $restaurants = $query->with('category')
            ->paginate($request->get('per_page', 15));

        return response()->json($restaurants);
    }

    public function show($id)
    {
        $restaurant = Restaurant::with(['category', 'reviews' => function ($query) {
            $query->where('status', 'approved')->latest();
        }, 'galleryItems'])->findOrFail($id);

        return response()->json($restaurant);
    }

    public function featured(Request $request)
    {
        $restaurants = Restaurant::where('featured', true)
            ->where('status', 'active')
            ->with('category')
            ->limit($request->get('limit', 10))
            ->get();

        return response()->json($restaurants);
    }

    public function nearby(Request $request)
    {
        $latitude = $request->get('latitude');
        $longitude = $request->get('longitude');
        $radius = $request->get('radius', 10); // kilometers

        if (!$latitude || !$longitude) {
            return response()->json(['message' => 'Latitude and longitude are required'], 400);
        }

        $restaurants = Restaurant::where('status', 'active')
            ->whereRaw("(3959 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude)))) < ?", 
                [$latitude, $longitude, $latitude, $radius])
            ->with('category')
            ->get();

        return response()->json($restaurants);
    }

    public function getByCuitineType(Request $request)
    {
        $cuisine = $request->get('cuisine_type');
        $restaurants = Restaurant::where('status', 'active')
            ->where('cuisine_type', 'like', '%' . $cuisine . '%')
            ->with('category')
            ->paginate($request->get('per_page', 15));

        return response()->json($restaurants);
    }

    public function leaveReview(Request $request, $restaurantId)
    {
        $validated = $request->validate([
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string',
        ]);

        $restaurant = Restaurant::findOrFail($restaurantId);

        $review = RestaurantReview::updateOrCreate(
            [
                'restaurant_id' => $restaurantId,
                'user_id' => auth()->id(),
            ],
            [
                'rating' => $validated['rating'],
                'comment' => $validated['comment'],
                'status' => 'pending',
            ]
        );

        return response()->json($review, 201);
    }
}
