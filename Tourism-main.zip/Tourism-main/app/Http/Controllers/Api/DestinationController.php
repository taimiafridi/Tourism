<?php

namespace App\Http\Controllers\Api;

use App\Models\Destination;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class DestinationController extends Controller
{
    public function index(Request $request)
    {
        $query = Destination::where('status', 'active');

        if ($request->has('search')) {
            $query->where('name', 'like', '%' . $request->search . '%')
                ->orWhere('city', 'like', '%' . $request->search . '%')
                ->orWhere('country', 'like', '%' . $request->search . '%');
        }

        if ($request->has('country')) {
            $query->where('country', $request->country);
        }

        $destinations = $query->with(['reviews', 'galleryItems'])
            ->paginate($request->get('per_page', 15));

        return response()->json($destinations);
    }

    public function show($id)
    {
        $destination = Destination::with(['tours' => function ($query) {
            $query->where('status', 'active');
        }, 'reviews' => function ($query) {
            $query->where('status', 'approved')->latest();
        }, 'galleryItems'])->findOrFail($id);

        return response()->json($destination);
    }

    public function featured(Request $request)
    {
        $destinations = Destination::where('featured', true)
            ->where('status', 'active')
            ->limit($request->get('limit', 10))
            ->get();

        return response()->json($destinations);
    }
}
