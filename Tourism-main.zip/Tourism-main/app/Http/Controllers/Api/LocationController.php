<?php

namespace App\Http\Controllers\Api;

use App\Models\Destination;
use App\Models\Event;
use App\Models\Restaurant;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class LocationController extends Controller
{
    /**
     * Get nearby attractions, events, and restaurants based on user's location
     */
    public function nearby(Request $request)
    {
        $validated = $request->validate([
            'latitude' => 'required|numeric',
            'longitude' => 'required|numeric',
            'radius' => 'nullable|numeric|min:1|max:100',
        ]);

        $latitude = $validated['latitude'];
        $longitude = $validated['longitude'];
        $radius = $validated['radius'] ?? 50; // Default 50km

        // Get nearby destinations
        $destinations = $this->getNearbyItems(
            Destination::where('status', 'active'),
            $latitude,
            $longitude,
            $radius
        )->with('category')->get();

        // Get nearby events
        $events = $this->getNearbyItems(
            Event::where('status', 'active')->where('start_date', '>=', now()->toDateString()),
            $latitude,
            $longitude,
            $radius
        )->with('category')->get();

        // Get nearby restaurants
        $restaurants = $this->getNearbyItems(
            Restaurant::where('status', 'active'),
            $latitude,
            $longitude,
            min($radius, 15) // Smaller radius for restaurants (15km default)
        )->with('category')->get();

        return response()->json([
            'destinations' => $destinations,
            'events' => $events,
            'restaurants' => $restaurants,
            'search_radius_km' => $radius,
            'user_location' => [
                'latitude' => $latitude,
                'longitude' => $longitude,
            ],
        ]);
    }

    /**
     * Search items by city
     */
    public function searchByCity(Request $request)
    {
        $validated = $request->validate([
            'city' => 'required|string',
            'type' => 'nullable|in:destination,event,restaurant,all',
        ]);

        $city = $validated['city'];
        $type = $validated['type'] ?? 'all';

        $results = [];

        if (in_array($type, ['destination', 'all'])) {
            $results['destinations'] = Destination::where('status', 'active')
                ->where('city', 'ilike', '%' . $city . '%')
                ->with('category')
                ->get();
        }

        if (in_array($type, ['event', 'all'])) {
            $results['events'] = Event::where('status', 'active')
                ->where('city', 'ilike', '%' . $city . '%')
                ->where('start_date', '>=', now())
                ->with('category')
                ->get();
        }

        if (in_array($type, ['restaurant', 'all'])) {
            $results['restaurants'] = Restaurant::where('status', 'active')
                ->where('city', 'ilike', '%' . $city . '%')
                ->with('category')
                ->get();
        }

        return response()->json($results);
    }

    /**
     * Get destinations with advanced filtering
     */
    public function filterDestinations(Request $request)
    {
        $query = Destination::where('status', 'active');

        if ($request->has('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        if ($request->has('city')) {
            $query->where('city', $request->city);
        }

        if ($request->has('country')) {
            $query->where('country', $request->country);
        }

        if ($request->has('rating')) {
            // Filter by minimum rating
            $minRating = $request->rating;
            $query->whereRaw("(SELECT AVG(rating) FROM reviews WHERE destination_id = destinations.id AND status = 'approved') >= ?", [$minRating]);
        }

        if ($request->has('featured')) {
            $query->where('featured', $request->boolean('featured'));
        }

        // Location-based filtering
        if ($request->has('latitude') && $request->has('longitude')) {
            $latitude = $request->latitude;
            $longitude = $request->longitude;
            $radius = $request->get('radius', 50);

            $query = $this->getNearbyItems($query, $latitude, $longitude, $radius);
        }

        $destinations = $query->with(['category', 'reviews'])
            ->paginate($request->get('per_page', 15));

        return response()->json($destinations);
    }

    /**
     * Get routes/directions between two locations
     * (Integration point for mapping service)
     */
    public function getRoute(Request $request)
    {
        $validated = $request->validate([
            'start_lat' => 'required|numeric',
            'start_lng' => 'required|numeric',
            'end_lat' => 'required|numeric',
            'end_lng' => 'required|numeric',
            'mode' => 'nullable|in:driving,walking,transit,bicycling',
        ]);

        // This is a placeholder for integration with Google Maps or similar service
        // You would call the mapping API here
        
        $response = [
            'status' => 'OK',
            'start' => [
                'latitude' => $validated['start_lat'],
                'longitude' => $validated['start_lng'],
            ],
            'end' => [
                'latitude' => $validated['end_lat'],
                'longitude' => $validated['end_lng'],
            ],
            'mode' => $validated['mode'] ?? 'driving',
            'distance' => 'Integrate with mapping API',
            'duration' => 'Integrate with mapping API',
            'polyline' => 'Integrate with mapping API',
        ];

        return response()->json($response);
    }

    /**
     * Get top-rated destinations in a specific area
     */
    public function getTopRated(Request $request)
    {
        $city = $request->get('city');
        $limit = $request->get('limit', 10);

        $query = Destination::where('status', 'active');

        if ($city) {
            $query->where('city', $city);
        }

        $destinations = $query->withAvg('reviews', 'rating')
            ->orderByDesc('reviews_avg_rating')
            ->limit($limit)
            ->with('category')
            ->get();

        return response()->json($destinations);
    }

    /**
     * Helper function to apply distance filter to query
     */
    private function getNearbyItems($query, $latitude, $longitude, $radius)
    {
        return $query->whereRaw(
            "(3959 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude)))) < ?",
            [$latitude, $longitude, $latitude, $radius]
        );
    }
}
