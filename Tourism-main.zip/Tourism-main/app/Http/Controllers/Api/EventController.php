<?php

namespace App\Http\Controllers\Api;

use App\Models\Event;
use App\Models\EventReview;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class EventController extends Controller
{
    public function index(Request $request)
    {
        $query = Event::where('status', 'active');

        if ($request->has('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        if ($request->has('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        if ($request->has('city')) {
            $query->where('city', $request->city);
        }

        if ($request->has('start_date')) {
            $query->whereDate('start_date', '>=', $request->start_date);
        }

        $events = $query->with(['category', 'reviews'])
            ->latest('start_date')
            ->paginate($request->get('per_page', 15));

        return response()->json($events);
    }

    public function show($id)
    {
        $event = Event::with(['category', 'reviews' => function ($query) {
            $query->where('status', 'approved')->latest();
        }, 'galleryItems'])->findOrFail($id);

        return response()->json($event);
    }

    public function featured(Request $request)
    {
        $events = Event::where('featured', true)
            ->where('status', 'active')
            ->with('category')
            ->limit($request->get('limit', 10))
            ->latest('start_date')
            ->get();

        return response()->json($events);
    }

    public function upcomingEvents(Request $request)
    {
        $events = Event::where('status', 'active')
            ->where('start_date', '>=', now())
            ->with('category')
            ->orderBy('start_date')
            ->limit($request->get('limit', 10))
            ->get();

        return response()->json($events);
    }

    public function nearby(Request $request)
    {
        $latitude = $request->get('latitude');
        $longitude = $request->get('longitude');
        $radius = $request->get('radius', 50); // kilometers

        if (!$latitude || !$longitude) {
            return response()->json(['message' => 'Latitude and longitude are required'], 400);
        }

        $events = Event::where('status', 'active')
            ->whereRaw("(3959 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude)))) < ?", 
                [$latitude, $longitude, $latitude, $radius])
            ->with('category')
            ->get();

        return response()->json($events);
    }

    public function leaveReview(Request $request, $eventId)
    {
        $validated = $request->validate([
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string',
        ]);

        $event = Event::findOrFail($eventId);

        // Check if user has a confirmed booking for this event
        $hasBooking = auth()->user()->eventBookings()
            ->where('event_id', $eventId)
            ->where('status', 'confirmed')
            ->exists();

        if (!$hasBooking) {
            return response()->json(['message' => 'Only users with confirmed bookings can review'], 403);
        }

        $review = EventReview::updateOrCreate(
            [
                'event_id' => $eventId,
                'user_id' => auth()->id(),
            ],
            [
                'rating' => $validated['rating'],
                'comment' => $validated['comment'],
                'status' => 'pending',
            ]
        );

        return response()->json($review, 201);
    }
}
