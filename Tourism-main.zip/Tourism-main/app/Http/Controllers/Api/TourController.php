<?php

namespace App\Http\Controllers\Api;

use App\Models\Tour;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class TourController extends Controller
{
    public function index(Request $request)
    {
        $query = Tour::where('status', 'active');

        if ($request->has('destination_id')) {
            $query->where('destination_id', $request->destination_id);
        }

        if ($request->has('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        $tours = $query->with(['destination', 'guide', 'itineraryItems'])
            ->paginate($request->get('per_page', 15));

        return response()->json($tours);
    }

    public function show($id)
    {
        $tour = Tour::with(['destination', 'guide', 'itineraryItems'])->findOrFail($id);
        return response()->json($tour);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'destination_id' => 'required|exists:destinations,id',
            'guide_id' => 'nullable|exists:guides,id',
            'name' => 'required|string',
            'description' => 'required|string',
            'duration_days' => 'required|integer|min:1',
            'price' => 'required|numeric|min:0',
            'max_participants' => 'required|integer|min:1',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
        ]);

        $tour = Tour::create($validated);
        return response()->json($tour, 201);
    }
}
