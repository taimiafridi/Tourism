<?php

namespace App\Http\Controllers\Api;

use App\Models\User;
use App\Models\Guide;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $rules = [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users',
            'password' => ['required', Password::min(8)],
            'phone' => 'required|string|max:20',
            'role' => 'nullable|in:user,guide',
        ];

        $role = $request->input('role', 'user');

        if ($role === 'guide') {
            $rules['iqama_number'] = 'required|string|max:20';
            $rules['nationality'] = 'required|string|max:100';
            $rules['driving_license'] = 'required|string|max:50';
            $rules['has_car'] = 'required|boolean';
            $rules['description'] = 'required|string|max:2000';
            $rules['languages'] = 'required|string|max:500';
            $rules['city'] = 'required|string|max:100';
            $rules['experience_years'] = 'required|integer|min:0';
        }

        $validated = $request->validate($rules);

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
            'phone' => $validated['phone'],
            'role' => $role,
            'status' => $role === 'guide' ? 'inactive' : 'active',
        ]);

        if ($role === 'guide') {
            Guide::create([
                'user_id' => $user->id,
                'phone' => $validated['phone'],
                'iqama_number' => $validated['iqama_number'],
                'nationality' => $validated['nationality'],
                'driving_license' => $validated['driving_license'],
                'has_car' => (bool) $validated['has_car'],
                'description' => $validated['description'],
                'languages' => array_map('trim', explode(',', $validated['languages'])),
                'city' => $validated['city'],
                'experience_years' => $validated['experience_years'],
                'status' => 'inactive',
                'verification_status' => 'pending',
            ]);

            return response()->json([
                'message' => 'Guide registration submitted. Awaiting admin approval.',
                'user' => $user,
            ], 201);
        }

        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'message' => 'User registered successfully',
            'user' => $user,
            'access_token' => $token,
            'token_type' => 'Bearer',
        ], 201);
    }

    public function login(Request $request)
    {
        $validated = $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $user = User::where('email', $validated['email'])->first();

        if (!$user || !Hash::check($validated['password'], $user->password)) {
            return response()->json(['message' => 'Invalid credentials'], 401);
        }

        if ($user->status !== 'active') {
            if ($user->role === 'guide') {
                return response()->json(['message' => 'Your guide account is pending admin approval.'], 403);
            }
            return response()->json(['message' => 'Your account is inactive'], 403);
        }

        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'message' => 'Login successful',
            'user' => $user,
            'access_token' => $token,
            'token_type' => 'Bearer',
        ]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'Logout successful']);
    }

    public function profile(Request $request)
    {
        return response()->json($request->user()->load(['bookings', 'guide']));
    }

    public function updateProfile(Request $request)
    {
        $validated = $request->validate([
            'name' => 'string|max:255',
            'phone' => 'nullable|string',
        ]);

        $request->user()->update($validated);
        return response()->json(['message' => 'Profile updated', 'user' => $request->user()]);
    }
}
