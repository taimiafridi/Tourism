<?php

namespace App\Http\Controllers\Api;

use App\Models\Guide;
use App\Models\GuideReview;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class GuideController extends Controller
{
    public function index(Request $request)
    {
        $query = Guide::where('status', 'active')
            ->where('verification_status', 'verified');

        if ($request->has('search')) {
            $query->whereHas('user', function ($q) use ($request) {
                $q->where('name', 'like', '%' . $request->search . '%');
            });
        }

        $guides = $query->with('user')
            ->withCount('tours')
            ->withAvg('reviews', 'rating')
            ->paginate($request->get('per_page', 15));

        return response()->json($guides);
    }

    public function show($id)
    {
        $guide = Guide::with(['user', 'tours', 'reviews' => function ($q) {
            $q->where('status', 'approved')->latest();
        }])->findOrFail($id);

        return response()->json($guide);
    }

    public function reviews($guideId)
    {
        $reviews = GuideReview::where('guide_id', $guideId)
            ->where('status', 'approved')
            ->with('user:id,name')
            ->latest()
            ->paginate(10);

        return response()->json($reviews);
    }

    public function apply(Request $request)
    {
        $user = $request->user();

        if ($user->role !== 'guide') {
            return response()->json(['message' => 'Only users with guide role can apply'], 403);
        }

        if ($user->guide()->exists()) {
            return response()->json(['message' => 'You have already applied as a guide'], 400);
        }

        $validated = $request->validate([
            'bio' => 'required|string',
            'experience_years' => 'required|integer|min:0',
            'languages' => 'required|array',
            'phone' => 'required|string',
        ]);

        $guide = Guide::create([
            'user_id' => $user->id,
            'bio' => $validated['bio'],
            'experience_years' => $validated['experience_years'],
            'languages' => $validated['languages'],
            'phone' => $validated['phone'],
            'verification_status' => 'pending',
        ]);

        return response()->json(['message' => 'Guide application submitted', 'guide' => $guide], 201);
    }
}
