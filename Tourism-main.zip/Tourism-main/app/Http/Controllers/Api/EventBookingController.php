<?php

namespace App\Http\Controllers\Api;

use App\Models\Event;
use App\Models\EventBooking;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Str;

class EventBookingController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'event_id' => 'required|exists:events,id',
            'number_of_tickets' => 'required|integer|min:1',
            'payment_method' => 'required|in:card,wallet,cod',
        ]);

        $event = Event::findOrFail($validated['event_id']);

        // Check event has not started
        if ($event->start_date->isPast()) {
            return response()->json(['message' => 'Event has already started'], 400);
        }

        // Check available capacity
        $bookedTickets = EventBooking::where('event_id', $event->id)
            ->whereIn('status', ['confirmed', 'pending'])
            ->sum('number_of_tickets');

        if ($bookedTickets + $validated['number_of_tickets'] > $event->capacity) {
            return response()->json(['message' => 'Not enough tickets available'], 400);
        }

        $booking = EventBooking::create([
            'event_id' => $validated['event_id'],
            'user_id' => auth()->id(),
            'number_of_tickets' => $validated['number_of_tickets'],
            'total_price' => $event->ticket_price * $validated['number_of_tickets'],
            'booking_date' => now(),
            'payment_method' => $validated['payment_method'],
            'booking_reference' => 'EB-' . Str::random(12),
            'status' => 'pending',
            'payment_status' => 'pending',
        ]);

        return response()->json($booking, 201);
    }

    public function index(Request $request)
    {
        $bookings = EventBooking::where('user_id', auth()->id())
            ->with(['event.category'])
            ->latest()
            ->paginate($request->get('per_page', 15));

        return response()->json($bookings);
    }

    public function show($id)
    {
        $booking = EventBooking::findOrFail($id);

        if ($booking->user_id !== auth()->id()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        return response()->json($booking->load('event'));
    }

    public function cancel($id)
    {
        $booking = EventBooking::findOrFail($id);

        if ($booking->user_id !== auth()->id()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        if (!in_array($booking->status, ['pending', 'confirmed'])) {
            return response()->json(['message' => 'Cannot cancel this booking'], 400);
        }

        $booking->update(['status' => 'cancelled']);
        return response()->json($booking);
    }
}
