<?php

namespace App\Http\Controllers\Web;

use App\Models\Booking;
use App\Models\Destination;
use App\Models\Guide;
use App\Models\Review;
use App\Models\Tour;
use App\Models\User;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;

class AdminDashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_users' => User::count(),
            'total_guides' => Guide::count(),
            'total_destinations' => Destination::count(),
            'total_tours' => Tour::count(),
            'total_bookings' => Booking::count(),
            'pending_reviews' => Review::where('status', 'pending')->count(),
            'active_users' => User::where('status', 'active')->count(),
            'verified_guides' => Guide::where('verification_status', 'verified')->count(),
        ];

        $recentBookings = Booking::with(['user', 'tour'])
            ->latest()
            ->limit(5)
            ->get();

        return view('admin.dashboard', compact('stats', 'recentBookings'));
    }

    // Placeholder pages for admin sections
    public function users() { return view('admin.placeholder', ['title' => 'Users Management', 'icon' => 'fas fa-users']); }
    public function destinations() { return view('admin.placeholder', ['title' => 'Destinations Management', 'icon' => 'fas fa-map-pin']); }
    public function tours() { return view('admin.placeholder', ['title' => 'Tours Management', 'icon' => 'fas fa-route']); }
    public function bookings() { return view('admin.placeholder', ['title' => 'Bookings Management', 'icon' => 'fas fa-ticket-alt']); }
    public function guides() { return view('admin.placeholder', ['title' => 'Guides Management', 'icon' => 'fas fa-user-tie']); }
    public function events() { return view('admin.placeholder', ['title' => 'Events Management', 'icon' => 'fas fa-calendar-alt']); }
    public function restaurants() { return view('admin.placeholder', ['title' => 'Restaurants Management', 'icon' => 'fas fa-utensils']); }
    public function reviews() { return view('admin.placeholder', ['title' => 'Reviews Management', 'icon' => 'fas fa-star']); }
}
