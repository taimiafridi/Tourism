<?php

namespace App\Http\Controllers\Web;

use App\Models\Booking;
use App\Models\EventBooking;
use App\Models\Tour;
use App\Models\Event;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class BookingController extends Controller
{
    // ─── Tour Booking ───

    public function showTourBooking(Tour $tour)
    {
        $tour->load(['destination', 'guide.user']);
        return view('pages.book-tour', compact('tour'));
    }

    public function submitTourBooking(Request $request, Tour $tour)
    {
        $request->validate([
            'number_of_participants' => 'required|integer|min:1|max:' . $tour->max_participants,
            'payment_method' => 'required|in:cash,credit_card,bank_transfer,apple_pay',
        ]);

        $participants = $request->input('number_of_participants');
        $totalPrice = $tour->price * $participants;

        $booking = Booking::create([
            'tour_id' => $tour->id,
            'user_id' => Auth::id(),
            'guide_id' => $tour->guide_id,
            'number_of_participants' => $participants,
            'total_price' => $totalPrice,
            'status' => 'confirmed',
            'booking_date' => now(),
            'payment_status' => 'paid',
            'payment_method' => $request->input('payment_method'),
        ]);

        return redirect()->route('my-bookings')->with('success', 'Tour booked successfully! Booking #' . $booking->id . ' confirmed.');
    }

    // ─── Event Booking ───

    public function showEventBooking(Event $event)
    {
        return view('pages.book-event', compact('event'));
    }

    public function submitEventBooking(Request $request, Event $event)
    {
        $request->validate([
            'number_of_tickets' => 'required|integer|min:1|max:10',
            'payment_method' => 'required|in:cash,credit_card,bank_transfer,apple_pay',
        ]);

        $tickets = $request->input('number_of_tickets');
        $totalPrice = $event->ticket_price * $tickets;
        $reference = 'EVT-' . strtoupper(Str::random(8));

        $booking = EventBooking::create([
            'event_id' => $event->id,
            'user_id' => Auth::id(),
            'number_of_tickets' => $tickets,
            'total_price' => $totalPrice,
            'booking_date' => now(),
            'status' => 'confirmed',
            'payment_status' => 'paid',
            'payment_method' => $request->input('payment_method'),
            'booking_reference' => $reference,
        ]);

        return redirect()->route('my-bookings')->with('success', 'Event tickets booked! Reference: ' . $reference);
    }

    // ─── My Bookings ───

    public function myBookings()
    {
        $user = Auth::user();

        $tourBookings = Booking::with(['tour.destination'])
            ->where('user_id', $user->id)
            ->orderByDesc('created_at')
            ->get();

        $eventBookings = EventBooking::with(['event'])
            ->where('user_id', $user->id)
            ->orderByDesc('created_at')
            ->get();

        $guideBookings = \App\Models\GuideBooking::with(['guide.user'])
            ->where('user_id', $user->id)
            ->orderByDesc('created_at')
            ->get();

        return view('pages.my-bookings', compact('tourBookings', 'eventBookings', 'guideBookings'));
    }
}
