<?php

namespace App\Http\Controllers\Web;

use App\Models\Guide;
use App\Models\GuideBooking;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;

class GuideController extends Controller
{
    public function index(Request $request)
    {
        $query = Guide::with(['user', 'reviews'])
            ->where('status', 'active')
            ->where('verification_status', 'verified');

        // Search by name or city
        if ($search = $request->get('search')) {
            $query->where(function ($q) use ($search) {
                $q->whereHas('user', fn($u) => $u->where('name', 'like', "%{$search}%"))
                  ->orWhere('city', 'like', "%{$search}%")
                  ->orWhere('specialization', 'like', "%{$search}%");
            });
        }

        // Filter by car availability
        if ($request->get('has_car')) {
            $query->where('has_car', true);
        }

        // Filter by price range
        if ($minPrice = $request->get('min_price')) {
            $query->where('hourly_rate', '>=', $minPrice);
        }
        if ($maxPrice = $request->get('max_price')) {
            $query->where('hourly_rate', '<=', $maxPrice);
        }

        // Filter by language
        if ($language = $request->get('language')) {
            $query->whereJsonContains('languages', $language);
        }

        // Sort
        $sort = $request->get('sort', 'rating');
        $query = match ($sort) {
            'price_low' => $query->orderBy('hourly_rate', 'asc'),
            'price_high' => $query->orderBy('hourly_rate', 'desc'),
            'experience' => $query->orderBy('experience_years', 'desc'),
            'tours' => $query->orderBy('total_tours_completed', 'desc'),
            default => $query->orderBy('rating', 'desc'),
        };

        $guides = $query->withCount('reviews')->withAvg('reviews', 'rating')->paginate(12);

        return view('pages.guides', compact('guides'));
    }

    public function show($id)
    {
        $guide = Guide::with(['user', 'reviews.user', 'tours.destination'])
            ->withCount('reviews')
            ->withAvg('reviews', 'rating')
            ->findOrFail($id);

        return view('pages.guide-detail', compact('guide'));
    }

    public function hire($id)
    {
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'Please login to hire a guide.');
        }

        $guide = Guide::with('user')->findOrFail($id);

        return view('pages.hire-guide', compact('guide'));
    }

    public function submitHire(Request $request, $id)
    {
        $guide = Guide::findOrFail($id);

        $validated = $request->validate([
            'booking_date' => 'required|date|after:today',
            'start_time' => 'required',
            'duration_hours' => 'required|integer|min:1|max:12',
            'service_type' => 'required|in:walking,with_car',
            'group_size' => 'required|integer|min:1|max:20',
            'meeting_point' => 'nullable|string|max:500',
            'special_requests' => 'nullable|string|max:1000',
        ]);

        $hourlyRate = $validated['service_type'] === 'with_car'
            ? $guide->hourly_rate_with_car
            : $guide->hourly_rate;

        $totalPrice = $hourlyRate * $validated['duration_hours'];

        $booking = GuideBooking::create([
            'guide_id' => $guide->id,
            'user_id' => Auth::id(),
            'booking_date' => $validated['booking_date'],
            'start_time' => $validated['start_time'],
            'duration_hours' => $validated['duration_hours'],
            'service_type' => $validated['service_type'],
            'group_size' => $validated['group_size'],
            'total_price' => $totalPrice,
            'meeting_point' => $validated['meeting_point'] ?? null,
            'special_requests' => $validated['special_requests'] ?? null,
            'status' => 'pending',
            'payment_status' => 'pending',
        ]);

        return redirect()->route('guides.show', $guide->id)
            ->with('success', 'Your guide booking request has been submitted! Booking #' . $booking->id);
    }
}
