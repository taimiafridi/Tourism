<?php

namespace App\Http\Controllers\Web;

use App\Models\Destination;
use App\Models\Tour;
use App\Models\Event;
use App\Models\Restaurant;
use App\Models\UserFavorite;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;

class PageController extends Controller
{
    private function getUserFavoriteIds(string $type): array
    {
        if (!Auth::check()) return [];
        return UserFavorite::where('user_id', Auth::id())
            ->where('favoritable_type', $type)
            ->pluck('favoritable_id')
            ->toArray();
    }

    public function destinations(Request $request)
    {
        $query = Destination::where('status', 'active');

        if ($search = $request->get('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('city', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        if ($city = $request->get('city')) {
            $query->where('city', $city);
        }

        $sort = $request->get('sort', 'featured');
        $query = match ($sort) {
            'name' => $query->orderBy('name'),
            'price_low' => $query->orderBy('entry_fee', 'asc'),
            'price_high' => $query->orderBy('entry_fee', 'desc'),
            default => $query->orderByDesc('featured')->orderBy('name'),
        };

        $destinations = $query->paginate(12);
        $cities = Destination::where('status', 'active')->distinct()->pluck('city')->sort()->values();

        $favIds = $this->getUserFavoriteIds(Destination::class);
        return view('pages.destinations', compact('destinations', 'cities', 'favIds'));
    }

    public function destinationDetail(Destination $destination)
    {
        $tours = Tour::with(['guide.user'])
            ->where('destination_id', $destination->id)
            ->where('status', 'active')
            ->orderBy('start_date')
            ->get();

        return view('pages.destination-detail', compact('destination', 'tours'));
    }

    public function tours(Request $request)
    {
        $query = Tour::with(['destination', 'guide.user'])->where('status', 'active');

        if ($search = $request->get('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%")
                  ->orWhereHas('destination', fn($d) => $d->where('name', 'like', "%{$search}%"));
            });
        }

        if ($maxPrice = $request->get('max_price')) {
            $query->where('price', '<=', $maxPrice);
        }

        if ($duration = $request->get('duration')) {
            $query->where('duration_days', '<=', $duration);
        }

        $sort = $request->get('sort', 'date');
        $query = match ($sort) {
            'price_low' => $query->orderBy('price', 'asc'),
            'price_high' => $query->orderBy('price', 'desc'),
            'name' => $query->orderBy('name'),
            default => $query->orderBy('start_date', 'asc'),
        };

        $tours = $query->paginate(12);

        $favIds = $this->getUserFavoriteIds(Tour::class);
        return view('pages.tours', compact('tours', 'favIds'));
    }

    public function events(Request $request)
    {
        $query = Event::where('status', 'active');

        if ($search = $request->get('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('city', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        if ($city = $request->get('city')) {
            $query->where('city', $city);
        }

        $sort = $request->get('sort', 'date');
        $query = match ($sort) {
            'price_low' => $query->orderBy('ticket_price', 'asc'),
            'price_high' => $query->orderBy('ticket_price', 'desc'),
            'name' => $query->orderBy('name'),
            default => $query->orderBy('start_date', 'asc'),
        };

        $events = $query->paginate(12);
        $cities = Event::where('status', 'active')->distinct()->pluck('city')->sort()->values();

        $favIds = $this->getUserFavoriteIds(Event::class);
        return view('pages.events', compact('events', 'cities', 'favIds'));
    }

    public function restaurants(Request $request)
    {
        $query = Restaurant::where('status', 'active');

        if ($search = $request->get('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('cuisine_type', 'like', "%{$search}%")
                  ->orWhere('city', 'like', "%{$search}%");
            });
        }

        if ($city = $request->get('city')) {
            $query->where('city', $city);
        }

        if ($cuisine = $request->get('cuisine')) {
            $query->where('cuisine_type', $cuisine);
        }

        $sort = $request->get('sort', 'rating');
        $query = match ($sort) {
            'price_low' => $query->orderBy('average_cost', 'asc'),
            'price_high' => $query->orderBy('average_cost', 'desc'),
            'name' => $query->orderBy('name'),
            default => $query->orderByDesc('rating'),
        };

        $restaurants = $query->paginate(12);
        $cities = Restaurant::where('status', 'active')->distinct()->pluck('city')->sort()->values();
        $cuisines = Restaurant::where('status', 'active')->whereNotNull('cuisine_type')->distinct()->pluck('cuisine_type')->sort()->values();

        $favIds = $this->getUserFavoriteIds(Restaurant::class);
        return view('pages.restaurants', compact('restaurants', 'cities', 'cuisines', 'favIds'));
    }
}
