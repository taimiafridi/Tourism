<?php

namespace App\Http\Controllers\Web;

use App\Models\User;
use App\Models\Guide;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class AuthController extends Controller
{
    public function showLogin()
    {
        if (Auth::check()) {
            return redirect('/');
        }

        return view('auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if (Auth::attempt($credentials, $request->boolean('remember'))) {
            $request->session()->regenerate();

            $user = Auth::user();

            if ($user->status !== 'active') {
                Auth::logout();
                if ($user->role === 'guide') {
                    return back()->withErrors(['email' => 'Your guide account is pending admin approval.']);
                }
                return back()->withErrors(['email' => 'Your account is inactive.']);
            }

            // If admin, redirect to admin dashboard
            if ($user->isAdmin()) {
                return redirect()->route('admin.dashboard');
            }

            // Redirect to intended page or home
            return redirect()->intended('/');
        }

        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ])->onlyInput('email');
    }

    public function showRegister()
    {
        if (Auth::check()) {
            return redirect('/');
        }

        return view('auth.register');
    }

    public function register(Request $request)
    {
        $rules = [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users',
            'phone' => 'required|string|max:20',
            'password' => ['required', 'confirmed', Password::min(8)],
            'role' => 'required|in:user,guide',
        ];

        // Extra validation for guide registration
        if ($request->input('role') === 'guide') {
            $rules['iqama_number'] = 'required|string|max:20';
            $rules['nationality'] = 'required|string|max:100';
            $rules['driving_license'] = 'required|string|max:50';
            $rules['has_car'] = 'required|in:0,1';
            $rules['description'] = 'required|string|max:2000';
            $rules['languages'] = 'required|string|max:500';
            $rules['city'] = 'required|string|max:100';
            $rules['experience_years'] = 'required|integer|min:0';
        }

        $validated = $request->validate($rules);

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'phone' => $validated['phone'],
            'password' => Hash::make($validated['password']),
            'role' => $validated['role'],
            'status' => $validated['role'] === 'guide' ? 'inactive' : 'active',
        ]);

        if ($validated['role'] === 'guide') {
            Guide::create([
                'user_id' => $user->id,
                'phone' => $validated['phone'],
                'iqama_number' => $validated['iqama_number'],
                'nationality' => $validated['nationality'],
                'driving_license' => $validated['driving_license'],
                'has_car' => (bool) $validated['has_car'],
                'description' => $validated['description'],
                'languages' => array_map('trim', explode(',', $validated['languages'])),
                'city' => $validated['city'],
                'experience_years' => $validated['experience_years'],
                'status' => 'inactive',
                'verification_status' => 'pending',
            ]);

            return redirect('/login')->with('success', 'Your guide account has been submitted for admin approval. You will be notified once approved.');
        }

        Auth::login($user);

        return redirect('/')->with('success', 'Welcome! Your account has been created.');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/');
    }
}
