<?php

namespace App\Http\Controllers\Web;

use App\Models\Destination;
use App\Models\Guide;
use App\Models\Tour;
use App\Models\User;
use Illuminate\Routing\Controller;

class HomeController extends Controller
{
    public function index()
    {
        $stats = [
            'destinations' => Destination::count(),
            'tours' => Tour::count(),
            'guides' => Guide::count(),
            'users' => User::count(),
        ];

        return view('home', compact('stats'));
    }
}
