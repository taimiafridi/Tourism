<?php

namespace App\Filament\Widgets;

use App\Models\Booking;
use App\Models\Destination;
use App\Models\Event;
use App\Models\Guide;
use App\Models\Restaurant;
use App\Models\Tour;
use App\Models\User;
use Filament\Widgets\StatsOverviewWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class StatsOverview extends StatsOverviewWidget
{
    protected function getStats(): array
    {
        return [
            Stat::make('Total Users', User::count())
                ->description('Registered users')
                ->color('success')
                ->icon('heroicon-o-users'),
            Stat::make('Destinations', Destination::where('status', 'active')->count())
                ->description('Active places')
                ->color('info')
                ->icon('heroicon-o-map-pin'),
            Stat::make('Tours', Tour::where('status', 'active')->count())
                ->description('Active tours')
                ->color('warning')
                ->icon('heroicon-o-globe-alt'),
            Stat::make('Guides', Guide::where('status', 'active')->count())
                ->description('Active guides')
                ->color('primary')
                ->icon('heroicon-o-user-group'),
            Stat::make('Restaurants', Restaurant::where('status', 'active')->count())
                ->description('Active restaurants')
                ->color('danger')
                ->icon('heroicon-o-building-storefront'),
            Stat::make('Events', Event::where('status', 'active')->count())
                ->description('Active events')
                ->color('info')
                ->icon('heroicon-o-calendar-days'),
            Stat::make('Bookings', Booking::count())
                ->description('Total bookings')
                ->color('success')
                ->icon('heroicon-o-ticket'),
            Stat::make('New Users (30d)', User::where('created_at', '>=', now()->subDays(30))->count())
                ->description('Last 30 days')
                ->color('warning')
                ->icon('heroicon-o-user-plus'),
        ];
    }
}
