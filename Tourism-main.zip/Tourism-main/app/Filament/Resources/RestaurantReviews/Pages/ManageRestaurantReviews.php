<?php

namespace App\Filament\Resources\RestaurantReviews\Pages;

use App\Filament\Resources\RestaurantReviews\RestaurantReviewResource;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ManageRecords;

class ManageRestaurantReviews extends ManageRecords
{
    protected static string $resource = RestaurantReviewResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make(),
        ];
    }
}
