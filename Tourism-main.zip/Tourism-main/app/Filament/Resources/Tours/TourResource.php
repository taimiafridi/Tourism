<?php

namespace App\Filament\Resources\Tours;

use App\Filament\Resources\Tours\Pages\ManageTours;
use App\Models\Tour;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Actions\ViewAction;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use UnitEnum;

class TourResource extends Resource
{
    protected static ?string $model = Tour::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedGlobeAlt;

    protected static string|UnitEnum|null $navigationGroup = 'Tourism';

    protected static ?int $navigationSort = 2;

    protected static ?string $recordTitleAttribute = 'name';

    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('name')->required()->maxLength(255),
                Textarea::make('description')->required()->rows(4),
                Select::make('destination_id')
                    ->relationship('destination', 'name')
                    ->searchable()
                    ->preload()
                    ->required(),
                Select::make('guide_id')
                    ->relationship('guide', 'id')
                    ->searchable()
                    ->preload(),
                TextInput::make('duration_days')
                    ->numeric()
                    ->required()
                    ->minValue(1),
                TextInput::make('price')
                    ->numeric()
                    ->required()
                    ->prefix('SAR'),
                TextInput::make('max_participants')
                    ->numeric()
                    ->required()
                    ->minValue(1),
                DateTimePicker::make('start_date')->required(),
                DateTimePicker::make('end_date')->required(),
                TextInput::make('image_url')->url()->maxLength(500),
                Select::make('status')
                    ->options([
                        'active' => 'Active',
                        'inactive' => 'Inactive',
                        'completed' => 'Completed',
                        'cancelled' => 'Cancelled',
                    ])
                    ->required()
                    ->default('active'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('name')
            ->columns([
                TextColumn::make('id')->sortable(),
                ImageColumn::make('image_url')->label('Image')->circular(),
                TextColumn::make('name')->searchable()->sortable(),
                TextColumn::make('destination.name')->label('Destination')->sortable(),
                TextColumn::make('duration_days')->label('Days')->sortable(),
                TextColumn::make('price')->money('SAR')->sortable(),
                TextColumn::make('max_participants')->label('Max Pax')->sortable(),
                TextColumn::make('start_date')->dateTime()->sortable(),
                TextColumn::make('status')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'active' => 'success',
                        'inactive' => 'gray',
                        'completed' => 'info',
                        'cancelled' => 'danger',
                        default => 'gray',
                    })
                    ->sortable(),
            ])
            ->filters([
                SelectFilter::make('status')->options([
                    'active' => 'Active',
                    'inactive' => 'Inactive',
                    'completed' => 'Completed',
                    'cancelled' => 'Cancelled',
                ]),
                SelectFilter::make('destination_id')
                    ->relationship('destination', 'name'),
            ])
            ->recordActions([
                ViewAction::make(),
                EditAction::make(),
                DeleteAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ManageTours::route('/'),
        ];
    }
}
