<?php

namespace App\Filament\Resources\Guides;

use App\Filament\Resources\Guides\Pages\ManageGuides;
use App\Models\Guide;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Actions\ViewAction;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TernaryFilter;
use Filament\Tables\Table;
use UnitEnum;

class GuideResource extends Resource
{
    protected static ?string $model = Guide::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedUserGroup;

    protected static string|UnitEnum|null $navigationGroup = 'Tourism';

    protected static ?int $navigationSort = 5;

    protected static ?string $recordTitleAttribute = 'user.name';

    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Select::make('user_id')
                    ->relationship('user', 'name')
                    ->searchable()
                    ->preload()
                    ->required(),
                TextInput::make('phone')->tel()->maxLength(20)->required(),
                TextInput::make('iqama_number')->label('Iqama Number')->required()->maxLength(20),
                TextInput::make('nationality')->required()->maxLength(100),
                TextInput::make('driving_license')->label('Driving License')->required()->maxLength(50),
                Toggle::make('has_car')->label('Car Available')->default(false),
                TextInput::make('city')->required()->maxLength(100),
                TextInput::make('languages')
                    ->placeholder('e.g. Arabic, English, French')
                    ->required(),
                TextInput::make('experience_years')
                    ->numeric()
                    ->minValue(0)
                    ->required(),
                Textarea::make('description')->label('Guiding Description')->rows(4)->required(),
                Textarea::make('bio')->rows(3),
                TextInput::make('specialization')->maxLength(255),
                TextInput::make('hourly_rate')
                    ->numeric()
                    ->prefix('SAR'),
                TextInput::make('hourly_rate_with_car')
                    ->numeric()
                    ->prefix('SAR'),
                TextInput::make('profile_photo')->url()->maxLength(500),
                TextInput::make('rating')
                    ->numeric()
                    ->minValue(0)
                    ->maxValue(5)
                    ->step(0.1),
                Select::make('status')
                    ->options([
                        'active' => 'Active',
                        'inactive' => 'Inactive',
                        'suspended' => 'Suspended',
                    ])
                    ->required()
                    ->default('inactive'),
                Select::make('verification_status')
                    ->options([
                        'pending' => 'Pending',
                        'verified' => 'Verified',
                        'rejected' => 'Rejected',
                    ])
                    ->required()
                    ->default('pending'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')->sortable(),
                TextColumn::make('user.name')->label('Name')->searchable()->sortable(),
                TextColumn::make('phone')->searchable(),
                TextColumn::make('iqama_number')->label('Iqama')->searchable(),
                TextColumn::make('nationality')->searchable(),
                TextColumn::make('driving_license')->label('License'),
                TextColumn::make('city')->searchable()->sortable(),
                IconColumn::make('has_car')->boolean()->label('Car'),
                TextColumn::make('experience_years')->label('Exp (yrs)')->sortable(),
                TextColumn::make('rating')->sortable(),
                TextColumn::make('status')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'active' => 'success',
                        'inactive' => 'gray',
                        'suspended' => 'danger',
                        default => 'gray',
                    })
                    ->sortable(),
                TextColumn::make('verification_status')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'verified' => 'success',
                        'pending' => 'warning',
                        'rejected' => 'danger',
                        default => 'gray',
                    })
                    ->sortable(),
            ])
            ->filters([
                SelectFilter::make('status')->options([
                    'active' => 'Active',
                    'inactive' => 'Inactive',
                    'suspended' => 'Suspended',
                ]),
                SelectFilter::make('verification_status')->options([
                    'pending' => 'Pending',
                    'verified' => 'Verified',
                    'rejected' => 'Rejected',
                ]),
                TernaryFilter::make('has_car'),
            ])
            ->recordActions([
                Action::make('approve')
                    ->label('Approve')
                    ->icon(Heroicon::OutlinedCheckCircle)
                    ->color('success')
                    ->requiresConfirmation()
                    ->visible(fn (Guide $record): bool => $record->verification_status === 'pending')
                    ->action(function (Guide $record) {
                        $record->update(['verification_status' => 'verified', 'status' => 'active']);
                        $record->user->update(['status' => 'active']);
                    }),
                Action::make('reject')
                    ->label('Reject')
                    ->icon(Heroicon::OutlinedXCircle)
                    ->color('danger')
                    ->requiresConfirmation()
                    ->visible(fn (Guide $record): bool => $record->verification_status === 'pending')
                    ->action(function (Guide $record) {
                        $record->update(['verification_status' => 'rejected', 'status' => 'inactive']);
                        $record->user->update(['status' => 'inactive']);
                    }),
                ViewAction::make(),
                EditAction::make(),
                DeleteAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ManageGuides::route('/'),
        ];
    }
}
