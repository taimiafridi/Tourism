@extends('layouts.app')
@section('title', 'Wanderly - Discover Amazing Places')

@push('styles')
<style>
    /* Hero Section */
    .hero {
        background: linear-gradient(135deg, rgba(22,163,74,0.92), rgba(21,128,61,0.88)), url('https://images.unsplash.com/photo-1586724237569-f3d0c1dee8c6?w=1920') center/cover;
        min-height: 85vh;
        display: flex;
        align-items: center;
        color: #fff;
    }
    .hero h1 { font-size: 3.5rem; font-weight: 800; line-height: 1.1; }
    .hero .lead { font-size: 1.25rem; opacity: 0.95; max-width: 600px; line-height: 1.6; }
    .hero .btn-explore {
        background: #d4af37;
        color: #1a1a2e;
        border: none;
        padding: 0.95rem 2.8rem;
        font-size: 1.1rem;
        font-weight: 700;
        border-radius: 30px;
        transition: all 0.3s;
        box-shadow: 0 5px 20px rgba(212,175,55,0.3);
    }
    .hero .btn-explore:hover { 
        background: #f5d547;
        color: #1a1a2e;
        transform: translateY(-3px);
        box-shadow: 0 8px 30px rgba(212,175,55,0.4);
    }
    .hero .vision-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        background: rgba(212,175,55,0.15);
        border: 1.5px solid rgba(212,175,55,0.6);
        padding: 0.65rem 1.8rem;
        border-radius: 30px;
        font-weight: 600;
        color: #d4af37;
        margin-bottom: 1.5rem;
        font-size: 0.95rem;
    }

    /* Section styling */
    .section-title {
        font-weight: 700;
        font-size: 2rem;
        color: #1e293b;
        margin-bottom: 0.5rem;
    }
    .section-subtitle {
        color: #64748b;
        font-size: 1.1rem;
        margin-bottom: 2.5rem;
    }

    /* Service Cards */
    .service-card {
        background: #e5e7eb;
        border-radius: 16px;
        padding: 2rem;
        text-align: center;
        box-shadow: 0 4px 15px rgba(107,114,128,0.15);
        transition: all 0.3s;
        height: 100%;
        cursor: pointer;
        text-decoration: none;
        color: inherit;
        display: block;
        border: 2px solid transparent;
    }
    .service-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 40px rgba(107,114,128,0.25);
        border-color: #16a34a;
        color: inherit;
    }
    .service-card .icon-box {
        width: 70px;
        height: 70px;
        border-radius: 16px;
        margin: 0 auto 1.2rem;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.8rem;
    }
    .service-card h5 { font-weight: 700; color: #1e293b; }
    .service-card p { color: #64748b; font-size: 0.95rem; }
    .service-card .badge-login {
        display: inline-block;
        background: #fef3c7;
        color: #92400e;
        padding: 0.2rem 0.8rem;
        border-radius: 12px;
        font-size: 0.75rem;
        font-weight: 600;
        margin-top: 0.5rem;
    }

    /* Featured destinations */
    .dest-card {
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(107,114,128,0.2);
        transition: all 0.3s;
        background: #e5e7eb;
        border: 2px solid transparent;
    }
    .dest-card:hover { transform: translateY(-5px); box-shadow: 0 15px 40px rgba(107,114,128,0.3); border-color: #16a34a; }
    .dest-card .dest-img {
        height: 220px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 3rem;
    }
    .dest-card .dest-body { padding: 1.2rem; }
    .dest-card .dest-body h5 { font-weight: 700; color: #1e293b; }
    .dest-card .dest-body p { color: #64748b; font-size: 0.9rem; }

    /* Stats */
    .stat-box { text-align: center; padding: 2rem; }
    .stat-box .stat-num { font-size: 2.5rem; font-weight: 800; color: #16a34a; }
    .stat-box .stat-text { color: #64748b; font-weight: 500; }

    /* CTA */
    .cta-section {
        background: linear-gradient(135deg, #16a34a, #15803d);
        color: #fff;
        padding: 5rem 0;
        border-radius: 0;
    }

    @media (max-width: 768px) {
        .hero h1 { font-size: 2.2rem; }
    }
</style>
@endpush

@section('content')
    <!-- Hero -->
    <section class="hero">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-7">
                    <div class="vision-badge">
                        <i class="fas fa-star"></i>Saudi Vision 2030 • Tourism Initiative
                    </div>
                    <h1 class="mb-4">Discover the Beauty of<br><span style="color:#d4af37">Saudi Arabia</span></h1>
                    <p class="lead mb-4">From the ancient Nabatean tombs of AlUla to the futuristic NEOM, experience the Kingdom's rich heritage, stunning landscapes, and world-class hospitality.</p>
                    <a href="{{ url('/destinations') }}" class="btn btn-explore me-3">
                        <i class="fas fa-compass me-2"></i>Explore Saudi
                    </a>
                    <a href="{{ url('/guides') }}" class="btn btn-outline-light btn-lg rounded-pill px-4">
                        <i class="fas fa-user-tie me-2"></i>Hire a Guide
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Services - These require login when clicked -->
    <section class="py-5" style="background: #f8fafc;">
        <div class="container py-4">
            <div class="text-center">
                <h2 class="section-title">Explore Saudi Arabia</h2>
                <p class="section-subtitle">Everything you need for the ultimate Saudi experience</p>
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6">
                    <a href="{{ url('/destinations') }}" class="service-card">
                        <div class="icon-box" style="background: #dcfce7; color: #16a34a;"><i class="fas fa-mosque"></i></div>
                        <h5>Destinations</h5>
                        <p>Discover Saudi's iconic landmarks — from Makkah & Madinah to AlUla and the Red Sea coast.</p>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="{{ url('/tours') }}" class="service-card">
                        <div class="icon-box" style="background: #dcfce7; color: #16a34a;"><i class="fas fa-route"></i></div>
                        <h5>Book Tours</h5>
                        <p>Desert safaris, city tours, heritage walks — guided by locals who know every secret.</p>
                        <span class="badge-login"><i class="fas fa-lock me-1"></i>Login Required</span>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="{{ url('/events') }}" class="service-card">
                        <div class="icon-box" style="background: #fef3c7; color: #d97706;"><i class="fas fa-calendar-alt"></i></div>
                        <h5>Events & Seasons</h5>
                        <p>Riyadh Season, Jeddah Season, MDLBeast — Saudi's world-class entertainment events.</p>
                        <span class="badge-login"><i class="fas fa-lock me-1"></i>Login Required</span>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="{{ url('/restaurants') }}" class="service-card">
                        <div class="icon-box" style="background: #fef2f2; color: #dc2626;"><i class="fas fa-utensils"></i></div>
                        <h5>Saudi Cuisine</h5>
                        <p>Taste authentic Kabsa, Jareesh, and fine dining at the Kingdom's top restaurants.</p>
                    </a>
                </div>
            </div>
            <div class="row g-4 mt-2">
                <div class="col-lg-4 col-md-6">
                    <a href="{{ url('/guides') }}" class="service-card">
                        <div class="icon-box" style="background: #f5f3ff; color: #7c3aed;"><i class="fas fa-user-tie"></i></div>
                        <h5>Hire a Guide</h5>
                        <p>Book verified Saudi guides with car — hourly rates, perfect for families and groups.</p>
                    </a>
                </div>
                <div class="col-lg-4 col-md-6">
                    <a href="{{ auth()->check() ? url('/my-bookings') : route('login') }}" class="service-card">
                        <div class="icon-box" style="background: #dcfce7; color: #16a34a;"><i class="fas fa-ticket-alt"></i></div>
                        <h5>My Bookings</h5>
                        <p>View and manage all your tour and event bookings in one place.</p>
                        <span class="badge-login"><i class="fas fa-lock me-1"></i>Login Required</span>
                    </a>
                </div>
                <div class="col-lg-4 col-md-6">
                    <a href="{{ auth()->check() ? url('/favorites') : route('login') }}" class="service-card">
                        <div class="icon-box" style="background: #fff1f2; color: #e11d48;"><i class="fas fa-heart"></i></div>
                        <h5>Favorites</h5>
                        <p>Save your favorite destinations and tours to visit later.</p>
                        <span class="badge-login"><i class="fas fa-lock me-1"></i>Login Required</span>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats -->
    <section class="py-5 bg-white">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-6">
                    <div class="stat-box">
                        <div class="stat-num">{{ $stats['destinations'] ?? '50+' }}</div>
                        <div class="stat-text">Destinations</div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-box">
                        <div class="stat-num">{{ $stats['tours'] ?? '100+' }}</div>
                        <div class="stat-text">Tours Available</div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-box">
                        <div class="stat-num">{{ $stats['guides'] ?? '25+' }}</div>
                        <div class="stat-text">Expert Guides</div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-box">
                        <div class="stat-num">{{ $stats['users'] ?? '500+' }}</div>
                        <div class="stat-text">Happy Travelers</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="cta-section">
        <div class="container text-center">
            <h2 class="fw-bold mb-3" style="font-size: 2.2rem;">Ready to Explore Saudi Arabia?</h2>
            <p class="lead mb-4 opacity-75">Join millions discovering the Kingdom's wonders — as part of Saudi Vision 2030.</p>
            @guest
                <a href="{{ route('register') }}" class="btn btn-warning btn-lg rounded-pill px-5 fw-bold">
                    <i class="fas fa-user-plus me-2"></i>Sign Up Free
                </a>
            @else
                <a href="{{ url('/destinations') }}" class="btn btn-warning btn-lg rounded-pill px-5 fw-bold">
                    <i class="fas fa-compass me-2"></i>Explore Destinations
                </a>
            @endguest
        </div>
    </section>
@endsection
