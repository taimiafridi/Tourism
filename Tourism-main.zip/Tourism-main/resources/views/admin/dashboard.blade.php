@extends('layouts.admin')
@section('title', 'Dashboard')
@section('page-title', 'Dashboard Overview')

@section('content')
    <!-- Stats Cards -->
    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="stat-label">Total Users</div>
                        <div class="stat-value">{{ number_format($stats['total_users']) }}</div>
                    </div>
                    <div class="stat-icon" style="background: #eff6ff; color: #2563eb;"><i class="fas fa-users"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="stat-label">Destinations</div>
                        <div class="stat-value">{{ number_format($stats['total_destinations']) }}</div>
                    </div>
                    <div class="stat-icon" style="background: #f0fdf4; color: #16a34a;"><i class="fas fa-map-pin"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="stat-label">Total Bookings</div>
                        <div class="stat-value">{{ number_format($stats['total_bookings']) }}</div>
                    </div>
                    <div class="stat-icon" style="background: #fef3c7; color: #d97706;"><i class="fas fa-ticket-alt"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="stat-label">Verified Guides</div>
                        <div class="stat-value">{{ number_format($stats['verified_guides']) }}</div>
                    </div>
                    <div class="stat-icon" style="background: #f5f3ff; color: #7c3aed;"><i class="fas fa-user-check"></i></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="stat-label">Active Tours</div>
                        <div class="stat-value">{{ number_format($stats['total_tours']) }}</div>
                    </div>
                    <div class="stat-icon" style="background: #ecfdf5; color: #059669;"><i class="fas fa-route"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="stat-label">Active Users</div>
                        <div class="stat-value">{{ number_format($stats['active_users']) }}</div>
                    </div>
                    <div class="stat-icon" style="background: #eff6ff; color: #2563eb;"><i class="fas fa-user-check"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="stat-label">Pending Reviews</div>
                        <div class="stat-value">{{ number_format($stats['pending_reviews']) }}</div>
                    </div>
                    <div class="stat-icon" style="background: #fff1f2; color: #e11d48;"><i class="fas fa-clock"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="stat-label">Total Guides</div>
                        <div class="stat-value">{{ number_format($stats['total_guides']) }}</div>
                    </div>
                    <div class="stat-icon" style="background: #fef3c7; color: #d97706;"><i class="fas fa-user-tie"></i></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Bookings & Quick Actions -->
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0"><i class="fas fa-history me-2 text-primary"></i>Recent Bookings</h5>
                    <a href="{{ route('admin.bookings') }}" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>User</th>
                                <th>Tour</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($recentBookings as $booking)
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="rounded-circle bg-primary bg-opacity-10 text-primary d-flex align-items-center justify-content-center me-2" style="width:32px;height:32px;font-size:0.8rem;">
                                                {{ strtoupper(substr($booking->user->name ?? 'U', 0, 1)) }}
                                            </div>
                                            {{ $booking->user->name ?? 'N/A' }}
                                        </div>
                                    </td>
                                    <td>{{ Str::limit($booking->tour->name ?? 'N/A', 25) }}</td>
                                    <td>{{ $booking->created_at->format('M d, Y') }}</td>
                                    <td>
                                        @php
                                            $statusColors = ['confirmed' => 'success', 'pending' => 'warning', 'cancelled' => 'danger', 'completed' => 'info'];
                                        @endphp
                                        <span class="badge bg-{{ $statusColors[$booking->status] ?? 'secondary' }}">{{ ucfirst($booking->status) }}</span>
                                    </td>
                                    <td class="fw-bold">${{ number_format($booking->total_price, 2) }}</td>
                                </tr>
                            @empty
                                <tr><td colspan="5" class="text-center text-muted py-4">No bookings yet</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="stat-card mb-4">
                <h5 class="fw-bold mb-3"><i class="fas fa-bolt me-2 text-warning"></i>Quick Actions</h5>
                <div class="d-grid gap-2">
                    <a href="{{ route('admin.destinations') }}" class="btn btn-outline-primary text-start">
                        <i class="fas fa-plus me-2"></i>Manage Destinations
                    </a>
                    <a href="{{ route('admin.tours') }}" class="btn btn-outline-success text-start">
                        <i class="fas fa-plus me-2"></i>Manage Tours
                    </a>
                    <a href="{{ route('admin.users') }}" class="btn btn-outline-info text-start">
                        <i class="fas fa-users me-2"></i>Manage Users
                    </a>
                    <a href="{{ route('admin.reviews') }}" class="btn btn-outline-warning text-start">
                        <i class="fas fa-star me-2"></i>Review Management
                    </a>
                    <a href="{{ route('admin.guides') }}" class="btn btn-outline-secondary text-start">
                        <i class="fas fa-user-tie me-2"></i>Guide Verification
                    </a>
                </div>
            </div>

            <div class="stat-card">
                <h5 class="fw-bold mb-3"><i class="fas fa-info-circle me-2 text-info"></i>System Info</h5>
                <ul class="list-unstyled mb-0">
                    <li class="d-flex justify-content-between py-2 border-bottom"><span class="text-muted">Laravel</span><span class="fw-bold">v{{ app()->version() }}</span></li>
                    <li class="d-flex justify-content-between py-2 border-bottom"><span class="text-muted">PHP</span><span class="fw-bold">v{{ PHP_VERSION }}</span></li>
                    <li class="d-flex justify-content-between py-2"><span class="text-muted">Admin</span><span class="fw-bold">{{ Auth::user()->email }}</span></li>
                </ul>
            </div>
        </div>
    </div>
@endsection
