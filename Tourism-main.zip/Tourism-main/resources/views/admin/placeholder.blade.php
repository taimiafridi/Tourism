@extends('layouts.admin')
@section('title', $title)
@section('page-title', $title)

@section('content')
    <div class="stat-card text-center py-5">
        <i class="{{ $icon }} fa-3x text-muted mb-3"></i>
        <h3 class="fw-bold text-muted">{{ $title }}</h3>
        <p class="text-muted">This section is coming soon. Use the API endpoints for full management capabilities.</p>
        <a href="{{ route('admin.dashboard') }}" class="btn btn-primary mt-3">
            <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
        </a>
    </div>
@endsection
