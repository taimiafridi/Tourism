@extends('layouts.app')
@section('title', 'Book Tour: ' . $tour->name)

@push('styles')
<style>
    .booking-hero {
        background: linear-gradient(135deg, rgba(0,108,53,0.95), rgba(0,77,37,0.9));
        padding: 2.5rem 0;
        color: #fff;
    }
    .booking-card {
        background: #e5e7eb;
        border-radius: 20px;
        box-shadow: 0 8px 40px rgba(107,114,128,0.2);
        overflow: hidden;
        margin-top: -2rem;
        position: relative;
        z-index: 10;
    }
    .tour-summary {
        background: #f8fafc;
        padding: 1.5rem;
        border-bottom: 1px solid #e2e8f0;
    }
    .tour-summary h4 { font-weight: 700; color: #1e293b; }
    .tour-meta span { font-size: 0.88rem; color: #64748b; }
    .tour-meta span i { color: #16a34a; width: 18px; }
    .booking-form { padding: 1.5rem; }
    .form-label { font-weight: 600; color: #374151; }
    .form-control, .form-select {
        border: 2px solid #e2e8f0;
        border-radius: 10px;
        padding: 0.7rem 1rem;
    }
    .form-control:focus, .form-select:focus { border-color: #16a34a; box-shadow: 0 0 0 3px rgba(22,163,74,0.1); }
    .price-summary {
        background: linear-gradient(135deg, #f0fdf4, #ecfdf5);
        border: 2px solid #bbf7d0;
        border-radius: 14px;
        padding: 1.2rem;
    }
    .price-row { display: flex; justify-content: space-between; padding: 0.3rem 0; color: #374151; }
    .price-row.total { font-weight: 800; font-size: 1.2rem; color: #16a34a; border-top: 2px solid #86efac; padding-top: 0.6rem; margin-top: 0.4rem; }
    .btn-confirm {
        background: #16a34a;
        color: #fff;
        border: none;
        border-radius: 12px;
        padding: 0.8rem;
        font-weight: 700;
        font-size: 1.05rem;
        width: 100%;
        transition: all 0.3s;
    }
    .btn-confirm:hover { background: #15803d; color: #fff; transform: translateY(-1px); }
    .payment-option { cursor: pointer; }
    .payment-option input:checked + .payment-label { border-color: #16a34a; background: #f0fdf4; }
    .payment-label {
        display: flex; align-items: center; gap: 0.7rem;
        border: 2px solid #e2e8f0; border-radius: 10px; padding: 0.8rem 1rem;
        transition: all 0.2s; cursor: pointer;
    }
    .payment-label:hover { border-color: #16a34a; }
    .payment-label i { font-size: 1.3rem; color: #16a34a; width: 24px; text-align: center; }
</style>
@endpush

@section('content')
    <section class="booking-hero">
        <div class="container text-center">
            <h1 class="fw-bold"><i class="fas fa-ticket-alt me-2" style="color:#d4af37"></i>Book Tour</h1>
            <p class="opacity-75">Complete your booking for this amazing experience</p>
        </div>
    </section>

    <div class="container pb-5" style="max-width:750px">
        <div class="booking-card">
            {{-- Tour Summary --}}
            <div class="tour-summary">
                <h4>{{ $tour->name }}</h4>
                <p class="text-muted mb-2">{{ Str::limit($tour->description, 150) }}</p>
                <div class="d-flex flex-wrap gap-3 tour-meta">
                    @if($tour->destination)
                        <span><i class="fas fa-map-marker-alt me-1"></i>{{ $tour->destination->name }}</span>
                    @endif
                    <span><i class="fas fa-clock me-1"></i>{{ $tour->duration_days }} {{ $tour->duration_days == 1 ? 'Day' : 'Days' }}</span>
                    <span><i class="fas fa-calendar me-1"></i>{{ $tour->start_date->format('M d, Y') }}</span>
                    <span><i class="fas fa-users me-1"></i>Max {{ $tour->max_participants }} people</span>
                    @if($tour->guide && $tour->guide->user)
                        <span><i class="fas fa-user-tie me-1"></i>Guide: {{ $tour->guide->user->name }}</span>
                    @endif
                </div>
            </div>

            {{-- Booking Form --}}
            <form action="{{ route('tours.book.submit', $tour->id) }}" method="POST" class="booking-form">
                @csrf

                @if($errors->any())
                    <div class="alert alert-danger rounded-3 mb-3">
                        @foreach($errors->all() as $error)
                            <div><i class="fas fa-exclamation-circle me-1"></i>{{ $error }}</div>
                        @endforeach
                    </div>
                @endif

                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-users me-1 text-success"></i>Number of Participants</label>
                    <select name="number_of_participants" id="participants" class="form-select" onchange="updatePrice()">
                        @for($i = 1; $i <= min($tour->max_participants, 20); $i++)
                            <option value="{{ $i }}" {{ old('number_of_participants', 1) == $i ? 'selected' : '' }}>{{ $i }} {{ $i == 1 ? 'person' : 'people' }}</option>
                        @endfor
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-credit-card me-1 text-success"></i>Payment Method</label>
                    <div class="d-flex flex-column gap-2">
                        @foreach(['credit_card' => ['fa-credit-card', 'Credit / Debit Card'], 'apple_pay' => ['fa-apple', 'Apple Pay'], 'bank_transfer' => ['fa-university', 'Bank Transfer'], 'cash' => ['fa-money-bill-wave', 'Cash on Arrival']] as $value => [$icon, $label])
                            <label class="payment-option">
                                <input type="radio" name="payment_method" value="{{ $value }}" class="d-none" {{ old('payment_method', 'credit_card') == $value ? 'checked' : '' }}>
                                <div class="payment-label">
                                    <i class="fas {{ $icon }}"></i>
                                    <span class="fw-500">{{ $label }}</span>
                                </div>
                            </label>
                        @endforeach
                    </div>
                </div>

                <div class="price-summary mb-3">
                    <div class="price-row">
                        <span>Price per person</span>
                        <span>{{ number_format($tour->price) }} SAR</span>
                    </div>
                    <div class="price-row">
                        <span>Participants</span>
                        <span id="participantCount">1</span>
                    </div>
                    <div class="price-row total">
                        <span>Total</span>
                        <span id="totalPrice">{{ number_format($tour->price) }} SAR</span>
                    </div>
                </div>

                <button type="submit" class="btn-confirm">
                    <i class="fas fa-check-circle me-2"></i>Confirm Booking
                </button>
            </form>
        </div>
    </div>
@endsection

@push('scripts')
<script>
    const pricePerPerson = {{ $tour->price }};
    function updatePrice() {
        const n = parseInt(document.getElementById('participants').value);
        document.getElementById('participantCount').textContent = n;
        document.getElementById('totalPrice').textContent = (pricePerPerson * n).toLocaleString() + ' SAR';
    }
</script>
@endpush
