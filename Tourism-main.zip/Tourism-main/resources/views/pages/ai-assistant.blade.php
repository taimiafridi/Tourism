@extends('layouts.app')
@section('title', 'AI Travel Assistant - Wanderly')

@push('styles')
<style>
    .chat-hero {
        background: linear-gradient(135deg, rgba(0,108,53,0.95), rgba(0,77,37,0.9));
        padding: 2rem 0;
        color: #fff;
        text-align: center;
    }
    .chat-container {
        max-width: 800px;
        margin: -1.5rem auto 2rem;
        position: relative;
        z-index: 10;
    }
    .chat-box {
        background: #e5e7eb;
        border-radius: 20px;
        box-shadow: 0 8px 40px rgba(107,114,128,0.2);
        overflow: hidden;
    }
    .chat-messages {
        height: 450px;
        overflow-y: auto;
        padding: 1.5rem;
        display: flex;
        flex-direction: column;
        gap: 1rem;
        background: #f8fafc;
    }
    .message {
        max-width: 80%;
        padding: 0.9rem 1.2rem;
        border-radius: 16px;
        font-size: 0.92rem;
        line-height: 1.6;
        animation: fadeIn 0.3s ease-in;
    }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
    .message.user {
        align-self: flex-end;
        background: linear-gradient(135deg, #16a34a, #15803d);
        color: #fff;
        border-bottom-right-radius: 4px;
    }
    .message.ai {
        align-self: flex-start;
        background: #fff;
        color: #1e293b;
        border: 1px solid #e2e8f0;
        border-bottom-left-radius: 4px;
        box-shadow: 0 2px 8px rgba(107,114,128,0.08);
    }
    .message.ai .ai-label {
        font-size: 0.72rem;
        font-weight: 700;
        color: #d4af37;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.3rem;
    }
    .chat-input-area {
        padding: 1rem 1.5rem;
        background: #e5e7eb;
        border-top: 1px solid #e2e8f0;
    }
    .chat-input-area .input-group {
        border: 2px solid #e2e8f0;
        border-radius: 14px;
        overflow: hidden;
        transition: border-color 0.3s;
    }
    .chat-input-area .input-group:focus-within {
        border-color: #16a34a;
    }
    .chat-input-area input {
        border: none;
        padding: 0.8rem 1rem;
        font-size: 0.95rem;
        outline: none;
        box-shadow: none !important;
    }
    .chat-input-area .btn-send {
        background: #16a34a;
        color: #fff;
        border: none;
        padding: 0.8rem 1.4rem;
        font-weight: 600;
        transition: background 0.3s;
    }
    .chat-input-area .btn-send:hover { background: #15803d; }
    .chat-input-area .btn-send:disabled { background: #94a3b8; cursor: not-allowed; }
    .typing-indicator { display: none; align-self: flex-start; }
    .typing-indicator .dots {
        display: flex; gap: 4px; padding: 0.8rem 1.2rem;
        background: #fff; border-radius: 16px; border: 1px solid #e2e8f0;
    }
    .typing-indicator .dots span {
        width: 8px; height: 8px; background: #16a34a; border-radius: 50%;
        animation: bounce 1.4s infinite ease-in-out;
    }
    .typing-indicator .dots span:nth-child(2) { animation-delay: 0.2s; }
    .typing-indicator .dots span:nth-child(3) { animation-delay: 0.4s; }
    @keyframes bounce { 0%,80%,100% { transform: scale(0); } 40% { transform: scale(1); } }
    .suggestion-chips {
        display: flex; flex-wrap: wrap; gap: 0.5rem;
        padding: 0.8rem 1.5rem; background: #fff; border-top: 1px solid #f1f5f9;
    }
    .suggestion-chip {
        background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0;
        padding: 0.4rem 0.9rem; border-radius: 20px; font-size: 0.82rem;
        cursor: pointer; transition: all 0.2s; font-weight: 500;
    }
    .suggestion-chip:hover { background: #16a34a; color: #fff; border-color: #16a34a; }
</style>
@endpush

@section('content')
    <section class="chat-hero">
        <h1 class="fw-bold mb-1"><i class="fas fa-robot me-2" style="color:#d4af37"></i>Wanderly AI</h1>
        <p class="opacity-75 mb-0">Ask about destinations, history, best times to visit & travel tips</p>
    </section>

    <div class="container chat-container">
        <div class="chat-box">
            <div class="chat-messages" id="chatMessages">
                <div class="message ai">
                    <div class="ai-label"><i class="fas fa-robot me-1"></i>Wanderly AI</div>
                    Welcome to the Wanderly AI Assistant! I can help you with:
                    <br><br>
                    ✅ <strong>Best & safest times to visit</strong> Saudi destinations<br>
                    ✅ <strong>History & heritage</strong> of cities, landmarks & archaeological sites<br>
                    ✅ <strong>Travel tips</strong> — customs, weather, dress code, safety<br>
                    ✅ <strong>Recommendations</strong> for tours, events & dining<br>
                    <br>
                    Ask me anything about exploring Saudi Arabia! 🇸🇦
                </div>
            </div>

            <div class="suggestion-chips" id="suggestions">
                <span class="suggestion-chip" onclick="askSuggestion(this)">Best time to visit AlUla?</span>
                <span class="suggestion-chip" onclick="askSuggestion(this)">History of Diriyah</span>
                <span class="suggestion-chip" onclick="askSuggestion(this)">Top things to do in Riyadh</span>
                <span class="suggestion-chip" onclick="askSuggestion(this)">What is NEOM project?</span>
                <span class="suggestion-chip" onclick="askSuggestion(this)">Top things to do in Jeddah</span>
                <span class="suggestion-chip" onclick="askSuggestion(this)">Saudi dress code for visitors</span>
            </div>

            <div class="chat-input-area">
                <form id="chatForm" onsubmit="sendMessage(event)">
                    <div class="input-group">
                        <input type="text" id="chatInput" placeholder="Ask about Saudi destinations, history, travel tips..." autocomplete="off" maxlength="1000">
                        <button type="submit" class="btn-send" id="sendBtn">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
<script>
    const chatMessages = document.getElementById('chatMessages');
    const chatInput = document.getElementById('chatInput');
    const sendBtn = document.getElementById('sendBtn');
    const suggestions = document.getElementById('suggestions');
    const csrfToken = document.querySelector('meta[name="csrf-token"]').content;

    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function addMessage(text, type) {
        const div = document.createElement('div');
        div.className = 'message ' + type;
        if (type === 'ai') {
            div.innerHTML = '<div class="ai-label"><i class="fas fa-robot me-1"></i>Wanderly AI</div>' + formatText(text);
        } else {
            div.textContent = text;
        }
        chatMessages.appendChild(div);
        scrollToBottom();
    }

    function formatText(text) {
        return text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/\n/g, '<br>');
    }

    function showTyping() {
        let el = document.getElementById('typingIndicator');
        if (!el) {
            el = document.createElement('div');
            el.id = 'typingIndicator';
            el.className = 'typing-indicator';
            el.innerHTML = '<div class="dots"><span></span><span></span><span></span></div>';
            chatMessages.appendChild(el);
        }
        el.style.display = 'block';
        scrollToBottom();
    }

    function hideTyping() {
        const el = document.getElementById('typingIndicator');
        if (el) el.remove();
    }

    function askSuggestion(el) {
        chatInput.value = el.textContent;
        sendMessage(new Event('submit'));
    }

    async function sendMessage(e) {
        e.preventDefault();
        const msg = chatInput.value.trim();
        if (!msg) return;

        addMessage(msg, 'user');
        chatInput.value = '';
        sendBtn.disabled = true;
        suggestions.style.display = 'none';
        showTyping();

        try {
            const resp = await fetch('/ai-assistant/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                    'Accept': 'application/json',
                },
                body: JSON.stringify({ message: msg }),
            });

            hideTyping();
            const data = await resp.json();

            if (resp.ok && data.reply) {
                addMessage(data.reply, 'ai');
            } else {
                addMessage(data.error || 'Something went wrong. Please try again.', 'ai');
            }
        } catch (err) {
            hideTyping();
            addMessage('Could not reach the AI service. Please check your connection and try again.', 'ai');
        }

        sendBtn.disabled = false;
        chatInput.focus();
    }

    chatInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            sendMessage(e);
        }
    });
</script>
@endpush
