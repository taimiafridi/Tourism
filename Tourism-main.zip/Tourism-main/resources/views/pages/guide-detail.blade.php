@extends('layouts.app')
@section('title', ($guide->user->name ?? 'Guide') . ' - Tourist Guide')

@push('styles')
<style>
    .profile-hero {
        background: linear-gradient(135deg, #1e293b, #334155);
        padding: 3rem 0;
        color: #fff;
    }
    .profile-avatar {
        width: 140px;
        height: 140px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 3.5rem;
        color: #fff;
        border: 4px solid #fff;
        box-shadow: 0 5px 20px rgba(107,114,128,0.4);
    }
    .badge-verified {
        background: #16a34a;
        color: #fff;
        padding: 0.3rem 1rem;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
    }
    .badge-car {
        background: #2563eb;
        color: #fff;
        padding: 0.3rem 1rem;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
    }

    .info-card {
        background: #e5e7eb;
        border-radius: 16px;
        padding: 1.5rem;
        box-shadow: 0 2px 15px rgba(107,114,128,0.12);
        height: 100%;
    }
    .info-card h5 { font-weight: 700; color: #1e293b; }

    /* Pricing Cards */
    .pricing-card {
        background: #e5e7eb;
        border-radius: 16px;
        padding: 2rem;
        box-shadow: 0 4px 20px rgba(107,114,128,0.15);
        border: 2px solid #e2e8f0;
        transition: all 0.3s;
        text-align: center;
    }
    .pricing-card:hover { border-color: #16a34a; transform: translateY(-3px); }
    .pricing-card.featured { border-color: #f59e0b; background: #fffbeb; }
    .pricing-card .price { font-size: 2.5rem; font-weight: 800; color: #1e293b; }
    .pricing-card .price small { font-size: 1rem; font-weight: 500; color: #64748b; }
    .pricing-card .plan-icon { font-size: 2.5rem; margin-bottom: 1rem; }
    .pricing-card .feature-list { text-align: left; }
    .pricing-card .feature-list li { padding: 0.4rem 0; color: #475569; }
    .pricing-card .feature-list li i { color: #16a34a; width: 20px; }

    .btn-hire-lg {
        background: #f59e0b;
        color: #fff;
        border: none;
        border-radius: 12px;
        padding: 0.85rem 2rem;
        font-weight: 700;
        font-size: 1.1rem;
        width: 100%;
        transition: all 0.3s;
    }
    .btn-hire-lg:hover { background: #d97706; color: #fff; transform: translateY(-2px); }

    .review-card {
        background: #f8fafc;
        border-radius: 12px;
        padding: 1.2rem;
        margin-bottom: 1rem;
    }
    .review-card .stars { color: #f59e0b; }
    .review-card .reviewer { font-weight: 600; color: #1e293b; }
    .review-card .review-date { color: #94a3b8; font-size: 0.85rem; }
    .review-card .review-text { color: #475569; }

    .stat-pill {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        background: rgba(255,255,255,0.15);
        padding: 0.5rem 1rem;
        border-radius: 25px;
        font-weight: 500;
    }
</style>
@endpush

@section('content')
    @php
        $bgColors = ['#6366f1', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316', '#06b6d4', '#84cc16'];
        $bgColor = $bgColors[$guide->id % count($bgColors)];
        $avgRating = $guide->reviews_avg_rating ?? $guide->rating;
    @endphp

    <!-- Profile Hero -->
    <section class="profile-hero">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-auto text-center mb-3 mb-md-0">
                    <div class="profile-avatar mx-auto" style="background: {{ $bgColor }};">
                        <i class="fas fa-user"></i>
                    </div>
                </div>
                <div class="col-md">
                    <div class="d-flex flex-wrap gap-2 mb-2">
                        <span class="badge-verified"><i class="fas fa-check-circle me-1"></i>Verified Guide</span>
                        @if($guide->has_car)
                            <span class="badge-car"><i class="fas fa-car me-1"></i>Has Car Available</span>
                        @endif
                    </div>
                    <h1 class="fw-bold mb-1">{{ $guide->user->name ?? 'Guide' }}</h1>
                    @if($guide->specialization)
                        <p class="mb-2 opacity-75"><i class="fas fa-star me-1 text-warning"></i>{{ $guide->specialization }}</p>
                    @endif
                    @if($guide->city)
                        <p class="mb-3 opacity-75"><i class="fas fa-map-marker-alt me-1"></i>{{ $guide->city }}</p>
                    @endif

                    <div class="d-flex flex-wrap gap-3">
                        <span class="stat-pill">
                            <span class="text-warning">
                                @for($i = 1; $i <= 5; $i++)
                                    @if($i <= round($avgRating))
                                        <i class="fas fa-star"></i>
                                    @else
                                        <i class="far fa-star"></i>
                                    @endif
                                @endfor
                            </span>
                            {{ number_format($avgRating, 1) }} ({{ $guide->reviews_count ?? 0 }} reviews)
                        </span>
                        <span class="stat-pill"><i class="fas fa-briefcase"></i>{{ $guide->experience_years ?? 0 }} years exp</span>
                        <span class="stat-pill"><i class="fas fa-route"></i>{{ $guide->total_tours_completed ?? 0 }} tours done</span>
                    </div>
                </div>
                <div class="col-md-auto text-center text-md-end mt-3 mt-md-0">
                    <a href="{{ route('guides.hire', $guide->id) }}" class="btn btn-hire-lg">
                        <i class="fas fa-handshake me-2"></i>Hire This Guide
                    </a>
                </div>
            </div>
        </div>
    </section>

    <div class="container py-5">
        <div class="row g-4">
            <!-- Left Column -->
            <div class="col-lg-8">
                <!-- About -->
                <div class="info-card mb-4">
                    <h5><i class="fas fa-user me-2 text-primary"></i>About</h5>
                    <p class="text-muted mb-0">{{ $guide->bio ?? 'This guide has not added a bio yet.' }}</p>
                </div>

                <!-- Languages & Skills -->
                <div class="row g-4 mb-4">
                    <div class="col-md-6">
                        <div class="info-card">
                            <h5><i class="fas fa-language me-2 text-success"></i>Languages</h5>
                            <div class="d-flex flex-wrap gap-2">
                                @if(is_array($guide->languages) && count($guide->languages) > 0)
                                    @foreach($guide->languages as $lang)
                                        <span class="badge bg-light text-dark border px-3 py-2 rounded-pill">
                                            <i class="fas fa-globe me-1"></i>{{ $lang }}
                                        </span>
                                    @endforeach
                                @else
                                    <span class="text-muted">Not specified</span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-card">
                            <h5><i class="fas fa-info-circle me-2 text-info"></i>Details</h5>
                            <ul class="list-unstyled mb-0">
                                <li class="py-1"><i class="fas fa-briefcase me-2 text-muted"></i><strong>Experience:</strong> {{ $guide->experience_years ?? 0 }} years</li>
                                <li class="py-1"><i class="fas fa-route me-2 text-muted"></i><strong>Tours:</strong> {{ $guide->total_tours_completed ?? 0 }} completed</li>
                                <li class="py-1"><i class="fas fa-phone me-2 text-muted"></i><strong>Phone:</strong> {{ $guide->phone ?? 'Available after booking' }}</li>
                                <li class="py-1"><i class="fas fa-car me-2 text-muted"></i><strong>Car:</strong> {{ $guide->has_car ? 'Available' : 'Walking tours only' }}</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Reviews -->
                <div class="info-card">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0"><i class="fas fa-star me-2 text-warning"></i>Reviews ({{ $guide->reviews_count ?? 0 }})</h5>
                    </div>
                    @forelse($guide->reviews as $review)
                        <div class="review-card">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <div>
                                    <span class="reviewer">{{ $review->user->name ?? 'Traveler' }}</span>
                                    <span class="review-date ms-2">{{ $review->created_at->format('M d, Y') }}</span>
                                </div>
                                <div class="stars">
                                    @for($i = 1; $i <= 5; $i++)
                                        @if($i <= $review->rating)
                                            <i class="fas fa-star"></i>
                                        @else
                                            <i class="far fa-star"></i>
                                        @endif
                                    @endfor
                                </div>
                            </div>
                            <p class="review-text mb-0">{{ $review->comment }}</p>
                        </div>
                    @empty
                        <div class="text-center py-4">
                            <i class="fas fa-comment-slash fa-2x text-muted mb-2"></i>
                            <p class="text-muted">No reviews yet. Be the first to hire and review this guide!</p>
                        </div>
                    @endforelse
                </div>
            </div>

            <!-- Right Column - Pricing -->
            <div class="col-lg-4">
                <!-- Walking Tour Pricing -->
                <div class="pricing-card mb-4">
                    <div class="plan-icon text-primary"><i class="fas fa-walking"></i></div>
                    <h5 class="fw-bold">Walking Tour</h5>
                    <p class="text-muted small">Explore on foot with your guide</p>
                    <div class="price">${{ number_format($guide->hourly_rate, 0) }}<small>/hour</small></div>
                    <hr>
                    <ul class="feature-list list-unstyled">
                        <li><i class="fas fa-check me-2"></i>Personal walking guide</li>
                        <li><i class="fas fa-check me-2"></i>Flexible itinerary</li>
                        <li><i class="fas fa-check me-2"></i>Local insights & tips</li>
                        <li><i class="fas fa-check me-2"></i>Group up to 20 people</li>
                        <li><i class="fas fa-check me-2"></i>1 to 12 hours</li>
                    </ul>
                    <a href="{{ route('guides.hire', $guide->id) }}?type=walking" class="btn btn-hire-lg mt-2">
                        <i class="fas fa-shoe-prints me-2"></i>Book Walking Tour
                    </a>
                </div>

                <!-- With Car Pricing -->
                @if($guide->has_car)
                    <div class="pricing-card featured">
                        <span class="badge bg-warning text-dark rounded-pill px-3 py-1 mb-2">
                            <i class="fas fa-star me-1"></i>Most Popular
                        </span>
                        <div class="plan-icon text-primary"><i class="fas fa-car-side"></i></div>
                        <h5 class="fw-bold">With Car</h5>
                        <p class="text-muted small">Comfortable transport included</p>
                        <div class="price">${{ number_format($guide->hourly_rate_with_car, 0) }}<small>/hour</small></div>
                        <hr>
                        <ul class="feature-list list-unstyled">
                            <li><i class="fas fa-check me-2"></i>Everything in Walking Tour</li>
                            <li><i class="fas fa-check me-2"></i>Air-conditioned vehicle</li>
                            <li><i class="fas fa-check me-2"></i>Hotel pickup & drop-off</li>
                            <li><i class="fas fa-check me-2"></i>Cover more ground</li>
                            <li><i class="fas fa-check me-2"></i>Luggage-friendly</li>
                        </ul>
                        <a href="{{ route('guides.hire', $guide->id) }}?type=with_car" class="btn btn-hire-lg mt-2">
                            <i class="fas fa-car me-2"></i>Book With Car
                        </a>
                    </div>
                @endif

                <!-- Contact Info -->
                <div class="info-card mt-4">
                    <h5><i class="fas fa-shield-alt me-2 text-success"></i>Booking Guarantee</h5>
                    <ul class="list-unstyled mb-0 small">
                        <li class="py-1"><i class="fas fa-check text-success me-2"></i>Free cancellation up to 24hrs before</li>
                        <li class="py-1"><i class="fas fa-check text-success me-2"></i>Verified & vetted guide</li>
                        <li class="py-1"><i class="fas fa-check text-success me-2"></i>Secure payment processing</li>
                        <li class="py-1"><i class="fas fa-check text-success me-2"></i>24/7 customer support</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
@endsection
