@extends('layouts.app')
@section('title', $destination->name . ' - Wanderly')

@push('styles')
<style>
    .dest-hero {
        padding: 3rem 0;
        color: #fff;
        position: relative;
    }
    .dest-hero .overlay {
        position: absolute; inset: 0;
        background: linear-gradient(135deg, rgba(0,108,53,0.92), rgba(0,77,37,0.88));
    }
    .dest-hero .container { position: relative; z-index: 2; }
    .dest-hero h1 { font-weight: 800; font-size: 2.2rem; }
    .dest-hero .meta-badge {
        display: inline-flex; align-items: center; gap: 0.4rem;
        background: rgba(255,255,255,0.15); padding: 0.4rem 0.9rem;
        border-radius: 20px; font-size: 0.88rem; color: #fff;
    }
    .info-card {
        background: #e5e7eb; border-radius: 16px;
        box-shadow: 0 4px 20px rgba(107,114,128,0.15);
        padding: 1.5rem; margin-top: -2rem;
        position: relative; z-index: 10;
    }
    .info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; }
    .info-item { text-align: center; padding: 1rem; background: #f8fafc; border-radius: 12px; }
    .info-item i { font-size: 1.5rem; color: #16a34a; margin-bottom: 0.4rem; display: block; }
    .info-item .label { font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; font-weight: 700; }
    .info-item .value { font-size: 1rem; font-weight: 700; color: #1e293b; }
    .section-title {
        font-weight: 700; color: #1e293b; margin-bottom: 1rem;
        padding-bottom: 0.5rem; border-bottom: 3px solid #16a34a;
        display: inline-block;
    }
    .tour-row {
        background: #e5e7eb; border-radius: 14px;
        box-shadow: 0 2px 12px rgba(107,114,128,0.12);
        padding: 1.2rem; margin-bottom: 1rem;
        border-left: 4px solid #16a34a;
        transition: all 0.2s;
        display: flex; justify-content: space-between;
        align-items: center; flex-wrap: wrap; gap: 1rem;
        border: 2px solid transparent;
    }
    .tour-row:hover { box-shadow: 0 4px 20px rgba(107,114,128,0.2); transform: translateX(4px); border-color: #16a34a; }
    .tour-row h5 { font-weight: 700; color: #1e293b; margin-bottom: 0.3rem; font-size: 1rem; }
    .tour-row .meta { font-size: 0.83rem; color: #64748b; }
    .tour-row .meta i { color: #16a34a; width: 16px; }
    .tour-price { font-weight: 800; color: #16a34a; font-size: 1.15rem; }
    .btn-book-tour {
        background: #16a34a; color: #fff; border: none;
        border-radius: 10px; padding: 0.5rem 1.2rem;
        font-weight: 600; font-size: 0.85rem; transition: all 0.2s;
        text-decoration: none;
    }
    .btn-book-tour:hover { background: #15803d; color: #fff; }
    .desc-text { color: #475569; line-height: 1.8; font-size: 0.95rem; }
</style>
@endpush

@section('content')
    <section class="dest-hero">
        <div class="overlay"></div>
        <div class="container">
            <nav aria-label="breadcrumb" class="mb-2">
                <ol class="breadcrumb mb-0" style="font-size:0.85rem">
                    <li class="breadcrumb-item"><a href="{{ url('/destinations') }}" class="text-white opacity-75 text-decoration-none">Destinations</a></li>
                    <li class="breadcrumb-item text-white active">{{ $destination->name }}</li>
                </ol>
            </nav>
            <h1>{{ $destination->name }}</h1>
            <div class="d-flex flex-wrap gap-2 mt-2">
                <span class="meta-badge"><i class="fas fa-map-marker-alt"></i>{{ $destination->city }}, {{ $destination->country }}</span>
                @if($destination->best_time_to_visit)
                    <span class="meta-badge"><i class="fas fa-calendar"></i>{{ $destination->best_time_to_visit }}</span>
                @endif
                @if($destination->featured)
                    <span class="meta-badge" style="background:rgba(212,175,55,0.3)"><i class="fas fa-star" style="color:#d4af37"></i>Featured</span>
                @endif
            </div>
        </div>
    </section>

    <div class="container pb-5">
        {{-- Info Grid --}}
        <div class="info-card mb-4">
            <div class="info-grid">
                <div class="info-item">
                    <i class="fas fa-ticket-alt"></i>
                    <div class="label">Entry Fee</div>
                    <div class="value">{{ $destination->entry_fee > 0 ? number_format($destination->entry_fee) . ' SAR' : 'Free' }}</div>
                </div>
                <div class="info-item">
                    <i class="fas fa-city"></i>
                    <div class="label">City</div>
                    <div class="value">{{ $destination->city }}</div>
                </div>
                <div class="info-item">
                    <i class="fas fa-calendar-check"></i>
                    <div class="label">Best Time</div>
                    <div class="value">{{ $destination->best_time_to_visit ?? 'Year-round' }}</div>
                </div>
                <div class="info-item">
                    <i class="fas fa-route"></i>
                    <div class="label">Available Tours</div>
                    <div class="value">{{ $tours->count() }}</div>
                </div>
            </div>
        </div>

        {{-- Description --}}
        <div class="mb-4">
            <h3 class="section-title"><i class="fas fa-info-circle me-2"></i>About</h3>
            <p class="desc-text">{{ $destination->description }}</p>
        </div>

        {{-- Tours --}}
        <div class="mb-4">
            <h3 class="section-title"><i class="fas fa-route me-2"></i>Available Tours</h3>

            @forelse($tours as $tour)
                <div class="tour-row">
                    <div style="flex:1">
                        <h5>{{ $tour->name }}</h5>
                        <p class="text-muted mb-1" style="font-size:0.88rem">{{ Str::limit($tour->description, 120) }}</p>
                        <div class="meta d-flex flex-wrap gap-3">
                            <span><i class="fas fa-clock me-1"></i>{{ $tour->duration_days }} {{ $tour->duration_days == 1 ? 'Day' : 'Days' }}</span>
                            <span><i class="fas fa-calendar me-1"></i>{{ $tour->start_date->format('M d, Y') }}</span>
                            <span><i class="fas fa-users me-1"></i>Max {{ $tour->max_participants }}</span>
                            @if($tour->guide && $tour->guide->user)
                                <span><i class="fas fa-user-tie me-1"></i>{{ $tour->guide->user->name }}</span>
                            @endif
                        </div>
                    </div>
                    <div class="text-end">
                        <div class="tour-price mb-2">{{ number_format($tour->price) }} SAR</div>
                        @auth
                            <a href="{{ route('tours.book', $tour->id) }}" class="btn-book-tour"><i class="fas fa-ticket-alt me-1"></i>Book Now</a>
                        @else
                            <a href="{{ route('login') }}" class="btn-book-tour"><i class="fas fa-lock me-1"></i>Login to Book</a>
                        @endauth
                    </div>
                </div>
            @empty
                <div class="text-center py-4">
                    <i class="fas fa-route fa-2x text-muted mb-2 d-block"></i>
                    <p class="text-muted">No tours available for this destination yet.</p>
                    <a href="{{ url('/tours') }}" class="btn text-white" style="background:#16a34a;border-radius:10px"><i class="fas fa-search me-1"></i>Browse All Tours</a>
                </div>
            @endforelse
        </div>
    </div>
@endsection
