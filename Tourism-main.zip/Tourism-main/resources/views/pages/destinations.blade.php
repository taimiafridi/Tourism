@extends('layouts.app')
@section('title', 'Destinations - Saudi Tourism 2030')

@push('styles')
<style>
    .page-hero {
        background: linear-gradient(135deg, rgba(0,108,53,0.9), rgba(0,77,37,0.85));
        padding: 3rem 0;
        color: #fff;
    }
    .filter-bar {
        background: #e5e7eb;
        border-radius: 12px;
        padding: 1.2rem;
        box-shadow: 0 2px 15px rgba(107,114,128,0.12);
        margin-top: -2rem;
        position: relative;
        z-index: 10;
    }
    .filter-bar .form-control, .filter-bar .form-select {
        border-radius: 8px;
        border: 2px solid #e2e8f0;
        padding: 0.6rem 1rem;
    }
    .dest-card {
        background: #e5e7eb;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(107,114,128,0.15);
        transition: all 0.3s;
        height: 100%;
        text-decoration: none;
        color: inherit;
        display: flex;
        flex-direction: column;
        border: 2px solid transparent;
    }
    .dest-card:hover { transform: translateY(-5px); box-shadow: 0 15px 35px rgba(107,114,128,0.25); color: inherit; border-color: #16a34a; }
    .dest-card .card-img {
        height: 200px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 3rem;
        position: relative;
    }
    .dest-card .card-img .badge-featured {
        position: absolute;
        top: 12px;
        right: 12px;
        background: #d4af37;
        color: #fff;
        padding: 0.3rem 0.8rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 700;
    }
    .dest-card .card-body { padding: 1.2rem; flex: 1; display: flex; flex-direction: column; }
    .dest-card .card-body h5 { font-weight: 700; color: #1e293b; }
    .dest-card .card-body p { color: #64748b; font-size: 0.9rem; flex: 1; }
    .dest-card .card-footer { padding: 0.8rem 1.2rem; background: #f8fafc; border-top: 1px solid #e2e8f0; }
    .dest-meta { display: flex; gap: 1rem; flex-wrap: wrap; }
    .dest-meta span { font-size: 0.85rem; color: #64748b; }
    .dest-meta span i { color: #16a34a; }
</style>
@endpush

@section('content')
    <section class="page-hero">
        <div class="container text-center">
            <h1 class="fw-bold"><i class="fas fa-mosque me-2" style="color:#d4af37"></i>Explore Saudi Arabia</h1>
            <p class="lead opacity-75">Discover the Kingdom's most breathtaking destinations</p>
        </div>
    </section>

    <div class="container pb-5">
        <form class="filter-bar mb-4" method="GET">
            <div class="row g-2 align-items-end">
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Search destinations..." value="{{ request('search') }}">
                </div>
                <div class="col-md-3">
                    <select name="city" class="form-select">
                        <option value="">All Cities</option>
                        @foreach($cities as $c)
                            <option value="{{ $c }}" {{ request('city') == $c ? 'selected' : '' }}>{{ $c }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="sort" class="form-select">
                        <option value="featured" {{ request('sort') == 'featured' ? 'selected' : '' }}>Featured First</option>
                        <option value="name" {{ request('sort') == 'name' ? 'selected' : '' }}>Name A-Z</option>
                        <option value="price_low" {{ request('sort') == 'price_low' ? 'selected' : '' }}>Price: Low to High</option>
                        <option value="price_high" {{ request('sort') == 'price_high' ? 'selected' : '' }}>Price: High to Low</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button class="btn w-100 text-white" style="background:#16a34a"><i class="fas fa-search me-1"></i>Search</button>
                </div>
            </div>
        </form>

        <p class="text-muted mb-3">Showing {{ $destinations->total() }} destinations</p>

        <div class="row g-4">
            @forelse($destinations as $dest)
                @php
                    $gradients = ['linear-gradient(135deg,#16a34a,#15803d)','linear-gradient(135deg,#0f4c81,#1a365d)','linear-gradient(135deg,#8b5cf6,#6d28d9)','linear-gradient(135deg,#d4af37,#b8941f)','linear-gradient(135deg,#0891b2,#0e7490)','linear-gradient(135deg,#dc2626,#991b1b)'];
                    $gradient = $gradients[$dest->id % count($gradients)];
                    $icons = ['fa-mosque','fa-landmark','fa-mountain','fa-water','fa-monument','fa-city','fa-kaaba','fa-umbrella-beach'];
                    $icon = $icons[$dest->id % count($icons)];
                @endphp
                <div class="col-lg-4 col-md-6">
                    <a href="{{ route('destinations.show', $dest->id) }}" class="dest-card">
                        <div class="card-img" style="background:{{ $gradient }}">
                            <i class="fas {{ $icon }}"></i>
                            @if($dest->featured)
                                <span class="badge-featured"><i class="fas fa-star me-1"></i>Featured</span>
                            @endif
                            <button class="fav-heart {{ in_array($dest->id, $favIds) ? 'active' : '' }}" style="left:10px;right:auto" onclick="event.preventDefault();event.stopPropagation();toggleFav(this,'destination',{{ $dest->id }})" title="Add to favorites">
                                <i class="fas fa-heart"></i>
                            </button>
                        </div>
                        <div class="card-body">
                            <h5>{{ $dest->name }}</h5>
                            <p>{{ Str::limit($dest->description, 120) }}</p>
                            <div class="dest-meta">
                                <span><i class="fas fa-map-marker-alt me-1"></i>{{ $dest->city }}</span>
                                @if($dest->best_time_to_visit)
                                    <span><i class="fas fa-calendar me-1"></i>{{ $dest->best_time_to_visit }}</span>
                                @endif
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-between align-items-center">
                            <span class="fw-bold" style="color:#16a34a">
                                @if($dest->entry_fee > 0)
                                    {{ number_format($dest->entry_fee) }} SAR
                                @else
                                    <span class="text-success">Free Entry</span>
                                @endif
                            </span>
                            <span class="badge bg-light text-dark"><i class="fas fa-flag me-1"></i>{{ $dest->country }}</span>
                        </div>
                    </a>
                </div>
            @empty
                <div class="col-12 text-center py-5">
                    <i class="fas fa-search fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">No destinations found</h4>
                    <p class="text-muted">Try adjusting your search filters</p>
                </div>
            @endforelse
        </div>

        <div class="d-flex justify-content-center mt-4">
            {{ $destinations->withQueryString()->links() }}
        </div>
    </div>
@endsection
