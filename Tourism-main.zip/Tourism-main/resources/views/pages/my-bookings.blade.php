@extends('layouts.app')
@section('title', 'My Bookings - Wanderly')

@push('styles')
<style>
    .page-hero {
        background: linear-gradient(135deg, rgba(22,163,74,0.95), rgba(21,128,61,0.9));
        padding: 2.5rem 0;
        color: #fff;
    }
    .tab-pills .nav-link {
        color: #64748b;
        font-weight: 600;
        border-radius: 10px;
        padding: 0.6rem 1.2rem;
    }
    .tab-pills .nav-link.active {
        background: #16a34a;
        color: #fff;
    }
    .booking-item {
        background: #e5e7eb;
        border-radius: 14px;
        box-shadow: 0 2px 12px rgba(107,114,128,0.12);
        padding: 1.2rem;
        margin-bottom: 1rem;
        border-left: 4px solid #16a34a;
        transition: all 0.2s;
        border: 2px solid transparent;
        border-left: 4px solid #16a34a;
    }
    .booking-item:hover { box-shadow: 0 4px 20px rgba(107,114,128,0.2); border-color: #16a34a; }
    .booking-item.cancelled { border-left-color: #dc2626; opacity: 0.7; }
    .booking-item.pending { border-left-color: #f59e0b; }
    .booking-item h5 { font-weight: 700; color: #1e293b; margin-bottom: 0.3rem; }
    .booking-meta { font-size: 0.85rem; color: #64748b; }
    .booking-meta i { width: 16px; color: #16a34a; }
    .badge-status { font-size: 0.75rem; padding: 0.3rem 0.7rem; border-radius: 20px; font-weight: 600; }
    .badge-confirmed { background: #dcfce7; color: #166534; }
    .badge-pending { background: #fef3c7; color: #92400e; }
    .badge-cancelled { background: #fee2e2; color: #991b1b; }
    .badge-completed { background: #dbeafe; color: #1e40af; }
    .empty-state { text-align: center; padding: 3rem; }
    .empty-state i { font-size: 3rem; color: #cbd5e1; margin-bottom: 1rem; }
</style>
@endpush

@section('content')
    <section class="page-hero">
        <div class="container text-center">
            <h1 class="fw-bold"><i class="fas fa-ticket-alt me-2" style="color:#d4af37"></i>My Bookings</h1>
            <p class="opacity-75">View and manage all your reservations</p>
        </div>
    </section>

    <div class="container py-4" style="max-width:900px">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show rounded-3 mb-3" role="alert">
                <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <ul class="nav tab-pills mb-4 gap-2" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="tab" href="#tours">
                    <i class="fas fa-route me-1"></i>Tours
                    @if($tourBookings->count())<span class="badge bg-white text-dark ms-1">{{ $tourBookings->count() }}</span>@endif
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#events">
                    <i class="fas fa-calendar-alt me-1"></i>Events
                    @if($eventBookings->count())<span class="badge bg-white text-dark ms-1">{{ $eventBookings->count() }}</span>@endif
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#guides">
                    <i class="fas fa-user-tie me-1"></i>Guides
                    @if($guideBookings->count())<span class="badge bg-white text-dark ms-1">{{ $guideBookings->count() }}</span>@endif
                </a>
            </li>
        </ul>

        <div class="tab-content">
            {{-- Tour Bookings --}}
            <div class="tab-pane fade show active" id="tours">
                @forelse($tourBookings as $b)
                    <div class="booking-item {{ $b->status }}">
                        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                            <div>
                                <h5>{{ $b->tour->name ?? 'Tour' }}</h5>
                                <div class="booking-meta d-flex flex-column gap-1">
                                    @if($b->tour && $b->tour->destination)
                                        <span><i class="fas fa-map-marker-alt me-1"></i>{{ $b->tour->destination->name }}</span>
                                    @endif
                                    <span><i class="fas fa-calendar me-1"></i>{{ $b->booking_date->format('M d, Y') }}</span>
                                    <span><i class="fas fa-users me-1"></i>{{ $b->number_of_participants }} {{ $b->number_of_participants == 1 ? 'person' : 'people' }}</span>
                                    <span><i class="fas fa-credit-card me-1"></i>{{ ucfirst(str_replace('_', ' ', $b->payment_method ?? 'N/A')) }}</span>
                                </div>
                            </div>
                            <div class="text-end">
                                <span class="badge-status badge-{{ $b->status }}">{{ ucfirst($b->status) }}</span>
                                <div class="mt-2 fw-bold" style="color:#16a34a;font-size:1.1rem">{{ number_format($b->total_price) }} SAR</div>
                                <div class="text-muted" style="font-size:0.75rem">Booking #{{ $b->id }}</div>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="empty-state">
                        <i class="fas fa-route d-block"></i>
                        <h5 class="text-muted">No tour bookings yet</h5>
                        <a href="{{ url('/tours') }}" class="btn text-white mt-2" style="background:#16a34a;border-radius:10px"><i class="fas fa-search me-1"></i>Browse Tours</a>
                    </div>
                @endforelse
            </div>

            {{-- Event Bookings --}}
            <div class="tab-pane fade" id="events">
                @forelse($eventBookings as $b)
                    <div class="booking-item {{ $b->status }}">
                        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                            <div>
                                <h5>{{ $b->event->name ?? 'Event' }}</h5>
                                <div class="booking-meta d-flex flex-column gap-1">
                                    @if($b->event)
                                        <span><i class="fas fa-map-marker-alt me-1"></i>{{ $b->event->city }}</span>
                                    @endif
                                    <span><i class="fas fa-calendar me-1"></i>{{ $b->booking_date->format('M d, Y') }}</span>
                                    <span><i class="fas fa-ticket-alt me-1"></i>{{ $b->number_of_tickets }} {{ $b->number_of_tickets == 1 ? 'ticket' : 'tickets' }}</span>
                                    <span><i class="fas fa-barcode me-1"></i>Ref: {{ $b->booking_reference }}</span>
                                </div>
                            </div>
                            <div class="text-end">
                                <span class="badge-status badge-{{ $b->status }}">{{ ucfirst($b->status) }}</span>
                                <div class="mt-2 fw-bold" style="color:#16a34a;font-size:1.1rem">{{ $b->total_price > 0 ? number_format($b->total_price) . ' SAR' : 'Free' }}</div>
                                <div class="text-muted" style="font-size:0.75rem">Booking #{{ $b->id }}</div>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="empty-state">
                        <i class="fas fa-calendar-alt d-block"></i>
                        <h5 class="text-muted">No event bookings yet</h5>
                        <a href="{{ url('/events') }}" class="btn text-white mt-2" style="background:#16a34a;border-radius:10px"><i class="fas fa-search me-1"></i>Browse Events</a>
                    </div>
                @endforelse
            </div>

            {{-- Guide Bookings --}}
            <div class="tab-pane fade" id="guides">
                @forelse($guideBookings as $b)
                    <div class="booking-item {{ $b->status }}">
                        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                            <div>
                                <h5>{{ $b->guide && $b->guide->user ? $b->guide->user->name : 'Guide' }}</h5>
                                <div class="booking-meta d-flex flex-column gap-1">
                                    <span><i class="fas fa-calendar me-1"></i>{{ \Carbon\Carbon::parse($b->booking_date)->format('M d, Y') }} at {{ \Carbon\Carbon::parse($b->start_time)->format('g:i A') }}</span>
                                    <span><i class="fas fa-clock me-1"></i>{{ $b->duration_hours }} hours</span>
                                    <span><i class="fas fa-car me-1"></i>{{ $b->service_type == 'with_car' ? 'With Car' : 'Walking Tour' }}</span>
                                    <span><i class="fas fa-users me-1"></i>Group of {{ $b->group_size }}</span>
                                </div>
                            </div>
                            <div class="text-end">
                                <span class="badge-status badge-{{ $b->status }}">{{ ucfirst($b->status) }}</span>
                                <div class="mt-2 fw-bold" style="color:#16a34a;font-size:1.1rem">{{ number_format($b->total_price) }} SAR</div>
                                <div class="text-muted" style="font-size:0.75rem">Booking #{{ $b->id }}</div>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="empty-state">
                        <i class="fas fa-user-tie d-block"></i>
                        <h5 class="text-muted">No guide bookings yet</h5>
                        <a href="{{ url('/guides') }}" class="btn text-white mt-2" style="background:#16a34a;border-radius:10px"><i class="fas fa-search me-1"></i>Browse Guides</a>
                    </div>
                @endforelse
            </div>
        </div>
    </div>
@endsection
