@extends('layouts.app')
@section('title', 'Events & Seasons - Wanderly')

@push('styles')
<style>
    .page-hero {
        background: linear-gradient(135deg, rgba(0,108,53,0.9), rgba(0,77,37,0.85));
        padding: 3rem 0;
        color: #fff;
    }
    .filter-bar {
        background: #e5e7eb;
        border-radius: 12px;
        padding: 1.2rem;
        box-shadow: 0 2px 15px rgba(107,114,128,0.12);
        margin-top: -2rem;
        position: relative;
        z-index: 10;
    }
    .filter-bar .form-control, .filter-bar .form-select {
        border-radius: 8px;
        border: 2px solid #e2e8f0;
        padding: 0.6rem 1rem;
    }
    .event-card {
        background: #e5e7eb;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(107,114,128,0.15);
        transition: all 0.3s;
        height: 100%;
        display: flex;
        flex-direction: column;
        border: 2px solid transparent;
    }
    .event-card:hover { transform: translateY(-5px); box-shadow: 0 15px 35px rgba(107,114,128,0.25); border-color: #16a34a; }
    .event-card .card-img {
        height: 180px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 2.5rem;
        position: relative;
    }
    .event-card .card-img .date-badge {
        position: absolute;
        top: 12px;
        left: 12px;
        background: #fff;
        color: #1e293b;
        padding: 0.5rem 0.8rem;
        border-radius: 10px;
        text-align: center;
        line-height: 1.1;
        box-shadow: 0 2px 8px rgba(107,114,128,0.25);
    }
    .date-badge .month { font-size: 0.65rem; font-weight: 700; text-transform: uppercase; color: #16a34a; }
    .date-badge .day { font-size: 1.3rem; font-weight: 800; }
    .event-card .card-img .featured-badge {
        position: absolute;
        top: 12px;
        right: 12px;
        background: #d4af37;
        color: #fff;
        padding: 0.3rem 0.8rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 700;
    }
    .event-card .card-body { padding: 1.2rem; flex: 1; display: flex; flex-direction: column; }
    .event-card .card-body h5 { font-weight: 700; color: #1e293b; font-size: 1rem; }
    .event-card .card-body p { color: #64748b; font-size: 0.88rem; flex: 1; }
    .event-card .card-footer { padding: 0.8rem 1.2rem; background: #f8fafc; border-top: 1px solid #e2e8f0; }
    .event-meta span { font-size: 0.82rem; color: #64748b; }
    .event-meta span i { color: #16a34a; width: 16px; }
</style>
@endpush

@section('content')
    <section class="page-hero">
        <div class="container text-center">
            <h1 class="fw-bold"><i class="fas fa-calendar-alt me-2" style="color:#d4af37"></i>Events & Saudi Seasons</h1>
            <p class="lead opacity-75">World-class entertainment, festivals, and cultural celebrations</p>
        </div>
    </section>

    <div class="container pb-5">
        <form class="filter-bar mb-4" method="GET">
            <div class="row g-2 align-items-end">
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Search events..." value="{{ request('search') }}">
                </div>
                <div class="col-md-3">
                    <select name="city" class="form-select">
                        <option value="">All Cities</option>
                        @foreach($cities as $c)
                            <option value="{{ $c }}" {{ request('city') == $c ? 'selected' : '' }}>{{ $c }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="sort" class="form-select">
                        <option value="date" {{ request('sort') == 'date' ? 'selected' : '' }}>Soonest First</option>
                        <option value="price_low" {{ request('sort') == 'price_low' ? 'selected' : '' }}>Price: Low</option>
                        <option value="price_high" {{ request('sort') == 'price_high' ? 'selected' : '' }}>Price: High</option>
                        <option value="name" {{ request('sort') == 'name' ? 'selected' : '' }}>Name A-Z</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button class="btn w-100 text-white" style="background:#16a34a"><i class="fas fa-search me-1"></i>Search</button>
                </div>
            </div>
        </form>

        @guest
            <div class="alert alert-warning border-0 rounded-3 mb-4">
                <i class="fas fa-lock me-2"></i><a href="{{ route('login') }}" class="fw-bold text-decoration-none">Login</a> to book event tickets.
            </div>
        @endguest

        <p class="text-muted mb-3">Showing {{ $events->total() }} events</p>

        <div class="row g-4">
            @forelse($events as $event)
                @php
                    $gradients = ['linear-gradient(135deg,#d4af37,#b8941f)','linear-gradient(135deg,#16a34a,#15803d)','linear-gradient(135deg,#8b5cf6,#6d28d9)','linear-gradient(135deg,#dc2626,#991b1b)','linear-gradient(135deg,#0891b2,#0e7490)','linear-gradient(135deg,#0f4c81,#1a365d)'];
                    $gradient = $gradients[$event->id % count($gradients)];
                    $icons = ['fa-music','fa-horse','fa-star','fa-theater-masks','fa-guitar','fa-fireworks','fa-mountain-sun'];
                    $icon = $icons[$event->id % count($icons)];
                @endphp
                <div class="col-lg-4 col-md-6">
                    <div class="event-card">
                        <div class="card-img" style="background:{{ $gradient }}">
                            <i class="fas {{ $icon }}"></i>
                            <div class="date-badge">
                                <div class="month">{{ $event->start_date->format('M') }}</div>
                                <div class="day">{{ $event->start_date->format('d') }}</div>
                            </div>
                            @if($event->featured)
                                <span class="featured-badge"><i class="fas fa-fire me-1"></i>Hot</span>
                            @endif
                            <button class="fav-heart {{ in_array($event->id, $favIds) ? 'active' : '' }}" style="{{ $event->featured ? 'top:48px' : '' }}" onclick="toggleFav(this,'event',{{ $event->id }})" title="Add to favorites">
                                <i class="fas fa-heart"></i>
                            </button>
                        </div>
                        <div class="card-body">
                            <h5>{{ $event->name }}</h5>
                            <p>{{ Str::limit($event->description, 110) }}</p>
                            <div class="event-meta d-flex flex-column gap-1 mt-auto">
                                <span><i class="fas fa-map-marker-alt me-1"></i>{{ $event->city }} — {{ $event->location_address }}</span>
                                <span><i class="fas fa-calendar-alt me-1"></i>{{ $event->start_date->format('M d') }} - {{ $event->end_date->format('M d, Y') }}</span>
                                @if($event->capacity)
                                    <span><i class="fas fa-users me-1"></i>Capacity: {{ number_format($event->capacity) }}</span>
                                @endif
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-between align-items-center">
                            <div>
                                @if($event->ticket_price > 0)
                                    <span class="fw-bold" style="color:#16a34a;font-size:1.1rem">{{ number_format($event->ticket_price) }} SAR</span>
                                    <span class="text-muted small">/ ticket</span>
                                @else
                                    <span class="fw-bold text-success">Free Entry</span>
                                @endif
                            </div>
                            @auth
                                <a href="{{ route('events.book', $event->id) }}" class="btn text-white" style="background:#16a34a;border-radius:8px;font-weight:600;font-size:0.85rem"><i class="fas fa-ticket-alt me-1"></i>Get Tickets</a>
                            @else
                                <a href="{{ route('login') }}" class="btn text-white" style="background:#16a34a;border-radius:8px;font-weight:600;font-size:0.85rem"><i class="fas fa-lock me-1"></i>Login</a>
                            @endauth
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-12 text-center py-5">
                    <i class="fas fa-search fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">No events found</h4>
                    <p class="text-muted">Try adjusting your search filters</p>
                </div>
            @endforelse
        </div>

        <div class="d-flex justify-content-center mt-4">
            {{ $events->withQueryString()->links() }}
        </div>
    </div>
@endsection
