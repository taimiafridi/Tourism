@extends('layouts.app')
@section('title', 'Hire ' . ($guide->user->name ?? 'Guide') . ' - Tourist Guide')

@push('styles')
<style>
    .hire-hero {
        background: linear-gradient(135deg, #1e293b, #334155);
        padding: 2rem 0;
        color: #fff;
    }
    .booking-card {
        background: #e5e7eb;
        border-radius: 16px;
        padding: 2rem;
        box-shadow: 0 4px 20px rgba(107,114,128,0.15);
    }
    .booking-card h4 { font-weight: 700; color: #1e293b; }
    .booking-card .form-control, .booking-card .form-select {
        border-radius: 10px;
        padding: 0.75rem 1rem;
        border: 2px solid #e2e8f0;
    }
    .booking-card .form-control:focus, .booking-card .form-select:focus {
        border-color: #2563eb;
        box-shadow: 0 0 0 3px rgba(37,99,235,0.1);
    }
    .booking-card textarea { min-height: 100px; }

    /* Service Type Cards */
    .service-option {
        border: 2px solid #e2e8f0;
        border-radius: 12px;
        padding: 1.5rem;
        cursor: pointer;
        transition: all 0.3s;
        text-align: center;
    }
    .service-option:hover { border-color: #2563eb; }
    .service-option.active { border-color: #2563eb; background: #eff6ff; }
    .service-option .service-icon { font-size: 2rem; margin-bottom: 0.5rem; }
    .service-option .service-price { font-size: 1.5rem; font-weight: 800; color: #1e293b; }
    .service-option .service-price small { font-size: 0.85rem; font-weight: 500; color: #64748b; }

    /* Summary Card */
    .summary-card {
        background: #f8fafc;
        border-radius: 16px;
        padding: 1.5rem;
        border: 2px solid #e2e8f0;
        position: sticky;
        top: 90px;
    }
    .summary-card h5 { font-weight: 700; color: #1e293b; }
    .summary-item {
        display: flex;
        justify-content: space-between;
        padding: 0.5rem 0;
        border-bottom: 1px solid #e2e8f0;
    }
    .summary-item:last-child { border-bottom: none; }
    .summary-item .label { color: #64748b; }
    .summary-item .value { font-weight: 600; color: #1e293b; }
    .summary-total {
        display: flex;
        justify-content: space-between;
        padding: 1rem 0 0;
        border-top: 2px solid #1e293b;
        margin-top: 0.5rem;
    }
    .summary-total .label { font-weight: 700; font-size: 1.1rem; color: #1e293b; }
    .summary-total .value { font-weight: 800; font-size: 1.3rem; color: #2563eb; }

    .btn-confirm {
        background: #f59e0b;
        color: #fff;
        border: none;
        border-radius: 12px;
        padding: 0.85rem;
        font-weight: 700;
        font-size: 1.1rem;
        width: 100%;
        transition: all 0.3s;
    }
    .btn-confirm:hover { background: #d97706; color: #fff; transform: translateY(-2px); }

    .guide-mini-card {
        display: flex;
        align-items: center;
        gap: 1rem;
        background: #e5e7eb;
        border-radius: 12px;
        padding: 1rem;
        border: 2px solid #e2e8f0;
        margin-bottom: 1.5rem;
    }
    .guide-mini-avatar {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        color: #fff;
        flex-shrink: 0;
    }
    .guarantee-item {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.4rem 0;
        font-size: 0.9rem;
        color: #475569;
    }
    .guarantee-item i { color: #16a34a; }
</style>
@endpush

@section('content')
    @php
        $bgColors = ['#6366f1', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316', '#06b6d4', '#84cc16'];
        $bgColor = $bgColors[$guide->id % count($bgColors)];
        $defaultType = request('type', 'walking');
    @endphp

    <!-- Hero -->
    <section class="hire-hero">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2">
                    <li class="breadcrumb-item"><a href="{{ url('/guides') }}" class="text-warning text-decoration-none">Guides</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('guides.show', $guide->id) }}" class="text-warning text-decoration-none">{{ $guide->user->name ?? 'Guide' }}</a></li>
                    <li class="breadcrumb-item active text-white">Hire</li>
                </ol>
            </nav>
            <h2 class="fw-bold mb-0"><i class="fas fa-handshake me-2 text-warning"></i>Hire {{ $guide->user->name ?? 'Guide' }}</h2>
            <p class="opacity-75 mb-0">Fill in the details below to book your guide</p>
        </div>
    </section>

    <div class="container py-5">
        <form action="{{ route('guides.hire.submit', $guide->id) }}" method="POST" id="hireForm">
            @csrf
            <div class="row g-4">
                <!-- Left: Booking Form -->
                <div class="col-lg-8">
                    <!-- Guide Mini Card -->
                    <div class="guide-mini-card">
                        <div class="guide-mini-avatar" style="background: {{ $bgColor }};">
                            <i class="fas fa-user"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-0">{{ $guide->user->name ?? 'Guide' }}</h6>
                            <div class="text-muted small">
                                @if($guide->city)<i class="fas fa-map-marker-alt me-1"></i>{{ $guide->city }} &bull; @endif
                                <span class="text-warning">
                                    @for($i = 1; $i <= 5; $i++)
                                        <i class="fas fa-star{{ $i <= round($guide->rating) ? '' : ' text-muted' }}"></i>
                                    @endfor
                                </span>
                                {{ number_format($guide->rating, 1) }}
                                @if($guide->specialization) &bull; {{ $guide->specialization }} @endif
                            </div>
                        </div>
                    </div>

                    <!-- Step 1: Service Type -->
                    <div class="booking-card mb-4">
                        <h4><span class="badge bg-primary rounded-circle me-2">1</span>Choose Service Type</h4>
                        <p class="text-muted">Select how you'd like to explore</p>

                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="service-option {{ $defaultType == 'walking' ? 'active' : '' }}" onclick="selectService('walking')">
                                    <div class="service-icon text-primary"><i class="fas fa-walking"></i></div>
                                    <h6 class="fw-bold">Walking Tour</h6>
                                    <p class="text-muted small mb-1">Explore on foot with your guide</p>
                                    <div class="service-price">${{ number_format($guide->hourly_rate, 0) }}<small>/hour</small></div>
                                </div>
                            </div>
                            @if($guide->has_car)
                                <div class="col-md-6">
                                    <div class="service-option {{ $defaultType == 'with_car' ? 'active' : '' }}" onclick="selectService('with_car')">
                                        <div class="service-icon text-primary"><i class="fas fa-car-side"></i></div>
                                        <h6 class="fw-bold">With Car</h6>
                                        <p class="text-muted small mb-1">Comfortable vehicle included</p>
                                        <div class="service-price">${{ number_format($guide->hourly_rate_with_car, 0) }}<small>/hour</small></div>
                                        <span class="badge bg-warning text-dark small rounded-pill">Popular</span>
                                    </div>
                                </div>
                            @endif
                        </div>
                        <input type="hidden" name="service_type" id="serviceType" value="{{ $defaultType }}">
                        @error('service_type')
                            <div class="text-danger small mt-1">{{ $message }}</div>
                        @enderror
                    </div>

                    <!-- Step 2: Date & Time -->
                    <div class="booking-card mb-4">
                        <h4><span class="badge bg-primary rounded-circle me-2">2</span>Date & Time</h4>
                        <p class="text-muted">When do you need the guide?</p>

                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label fw-semibold"><i class="fas fa-calendar me-1"></i>Date</label>
                                <input type="date" name="booking_date" class="form-control @error('booking_date') is-invalid @enderror"
                                       value="{{ old('booking_date') }}" min="{{ date('Y-m-d', strtotime('+1 day')) }}" required>
                                @error('booking_date')
                                    <div class="text-danger small mt-1">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold"><i class="fas fa-clock me-1"></i>Start Time</label>
                                <select name="start_time" class="form-select @error('start_time') is-invalid @enderror" required>
                                    <option value="">Select time</option>
                                    @for($h = 6; $h <= 20; $h++)
                                        <option value="{{ sprintf('%02d:00', $h) }}" {{ old('start_time') == sprintf('%02d:00', $h) ? 'selected' : '' }}>
                                            {{ date('g:00 A', mktime($h, 0)) }}
                                        </option>
                                        <option value="{{ sprintf('%02d:30', $h) }}" {{ old('start_time') == sprintf('%02d:30', $h) ? 'selected' : '' }}>
                                            {{ date('g:30 A', mktime($h, 30)) }}
                                        </option>
                                    @endfor
                                </select>
                                @error('start_time')
                                    <div class="text-danger small mt-1">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold"><i class="fas fa-hourglass-half me-1"></i>Duration (Hours)</label>
                                <select name="duration_hours" id="durationHours" class="form-select @error('duration_hours') is-invalid @enderror" onchange="updateSummary()" required>
                                    @for($h = 1; $h <= 12; $h++)
                                        <option value="{{ $h }}" {{ old('duration_hours', 3) == $h ? 'selected' : '' }}>
                                            {{ $h }} {{ $h == 1 ? 'hour' : 'hours' }}
                                        </option>
                                    @endfor
                                </select>
                                @error('duration_hours')
                                    <div class="text-danger small mt-1">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <!-- Step 3: Group Details -->
                    <div class="booking-card mb-4">
                        <h4><span class="badge bg-primary rounded-circle me-2">3</span>Group Details</h4>
                        <p class="text-muted">How many people in your group?</p>

                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold"><i class="fas fa-users me-1"></i>Group Size</label>
                                <select name="group_size" id="groupSize" class="form-select @error('group_size') is-invalid @enderror" onchange="updateSummary()" required>
                                    @for($p = 1; $p <= 20; $p++)
                                        <option value="{{ $p }}" {{ old('group_size', 1) == $p ? 'selected' : '' }}>
                                            {{ $p }} {{ $p == 1 ? 'person' : 'people' }}
                                        </option>
                                    @endfor
                                </select>
                                @error('group_size')
                                    <div class="text-danger small mt-1">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold"><i class="fas fa-map-marker-alt me-1"></i>Meeting Point</label>
                                <input type="text" name="meeting_point" class="form-control @error('meeting_point') is-invalid @enderror"
                                       value="{{ old('meeting_point') }}" placeholder="Hotel name, address, or landmark...">
                                @error('meeting_point')
                                    <div class="text-danger small mt-1">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <!-- Step 4: Special Requests -->
                    <div class="booking-card">
                        <h4><span class="badge bg-primary rounded-circle me-2">4</span>Special Requests <span class="text-muted fw-normal small">(Optional)</span></h4>
                        <p class="text-muted">Tell your guide about any preferences or special needs</p>

                        <textarea name="special_requests" class="form-control @error('special_requests') is-invalid @enderror"
                                  placeholder="e.g., I'm interested in historical sites, food recommendations, photography spots, accessibility needs...">{{ old('special_requests') }}</textarea>
                        @error('special_requests')
                            <div class="text-danger small mt-1">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <!-- Right: Summary -->
                <div class="col-lg-4">
                    <div class="summary-card">
                        <h5><i class="fas fa-receipt me-2 text-primary"></i>Booking Summary</h5>
                        <hr>

                        <div class="summary-item">
                            <span class="label">Guide</span>
                            <span class="value">{{ $guide->user->name ?? 'Guide' }}</span>
                        </div>
                        <div class="summary-item">
                            <span class="label">Service</span>
                            <span class="value" id="summaryService">{{ $defaultType == 'with_car' ? 'With Car' : 'Walking Tour' }}</span>
                        </div>
                        <div class="summary-item">
                            <span class="label">Rate</span>
                            <span class="value" id="summaryRate">${{ number_format($defaultType == 'with_car' ? $guide->hourly_rate_with_car : $guide->hourly_rate, 0) }}/hr</span>
                        </div>
                        <div class="summary-item">
                            <span class="label">Duration</span>
                            <span class="value" id="summaryDuration">3 hours</span>
                        </div>
                        <div class="summary-item">
                            <span class="label">Group Size</span>
                            <span class="value" id="summaryGroup">1 person</span>
                        </div>

                        <div class="summary-total">
                            <span class="label">Total Price</span>
                            <span class="value" id="summaryTotal">${{ number_format(($defaultType == 'with_car' ? $guide->hourly_rate_with_car : $guide->hourly_rate) * 3, 0) }}</span>
                        </div>

                        <button type="submit" class="btn btn-confirm mt-3">
                            <i class="fas fa-check-circle me-2"></i>Confirm Booking
                        </button>

                        <div class="mt-3">
                            <div class="guarantee-item"><i class="fas fa-check-circle"></i>Free cancellation up to 24hrs</div>
                            <div class="guarantee-item"><i class="fas fa-check-circle"></i>Secure payment</div>
                            <div class="guarantee-item"><i class="fas fa-check-circle"></i>Instant confirmation</div>
                            <div class="guarantee-item"><i class="fas fa-check-circle"></i>No hidden fees</div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
@endsection

@push('scripts')
<script>
    const walkingRate = {{ $guide->hourly_rate }};
    const carRate = {{ $guide->hourly_rate_with_car ?? $guide->hourly_rate }};

    function selectService(type) {
        document.getElementById('serviceType').value = type;
        document.querySelectorAll('.service-option').forEach(el => el.classList.remove('active'));
        event.currentTarget.classList.add('active');
        updateSummary();
    }

    function updateSummary() {
        const serviceType = document.getElementById('serviceType').value;
        const duration = parseInt(document.getElementById('durationHours').value) || 3;
        const groupSize = parseInt(document.getElementById('groupSize').value) || 1;

        const rate = serviceType === 'with_car' ? carRate : walkingRate;
        const total = rate * duration;

        document.getElementById('summaryService').textContent = serviceType === 'with_car' ? 'With Car' : 'Walking Tour';
        document.getElementById('summaryRate').textContent = '$' + rate + '/hr';
        document.getElementById('summaryDuration').textContent = duration + (duration === 1 ? ' hour' : ' hours');
        document.getElementById('summaryGroup').textContent = groupSize + (groupSize === 1 ? ' person' : ' people');
        document.getElementById('summaryTotal').textContent = '$' + total.toLocaleString();
    }

    // Init
    updateSummary();
</script>
@endpush
