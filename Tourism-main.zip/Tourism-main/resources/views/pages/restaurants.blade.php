@extends('layouts.app')
@section('title', 'Restaurants - Wanderly')

@push('styles')
<style>
    .page-hero {
        background: linear-gradient(135deg, rgba(0,108,53,0.9), rgba(0,77,37,0.85));
        padding: 3rem 0;
        color: #fff;
    }
    .filter-bar {
        background: #e5e7eb;
        border-radius: 12px;
        padding: 1.2rem;
        box-shadow: 0 2px 15px rgba(107,114,128,0.12);
        margin-top: -2rem;
        position: relative;
        z-index: 10;
    }
    .filter-bar .form-control, .filter-bar .form-select {
        border-radius: 8px;
        border: 2px solid #e2e8f0;
        padding: 0.6rem 1rem;
    }
    .rest-card {
        background: #e5e7eb;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(107,114,128,0.15);
        transition: all 0.3s;
        height: 100%;
        display: flex;
        flex-direction: column;
        border: 2px solid transparent;
    }
    .rest-card:hover { transform: translateY(-5px); box-shadow: 0 15px 35px rgba(107,114,128,0.25); border-color: #16a34a; }
    .rest-card .card-img {
        height: 170px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 2.5rem;
        position: relative;
    }
    .rest-card .card-img .cuisine-badge {
        position: absolute;
        top: 12px;
        left: 12px;
        background: rgba(255,255,255,0.95);
        color: #1e293b;
        padding: 0.3rem 0.8rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 700;
    }
    .rest-card .card-img .rating-badge {
        position: absolute;
        top: 12px;
        right: 12px;
        background: #d4af37;
        color: #fff;
        padding: 0.3rem 0.7rem;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 700;
    }
    .rest-card .card-body { padding: 1.2rem; flex: 1; display: flex; flex-direction: column; }
    .rest-card .card-body h5 { font-weight: 700; color: #1e293b; font-size: 1rem; }
    .rest-card .card-body p { color: #64748b; font-size: 0.88rem; flex: 1; }
    .rest-card .card-footer { padding: 0.8rem 1.2rem; background: #f8fafc; border-top: 1px solid #e2e8f0; }
    .rest-meta span { font-size: 0.82rem; color: #64748b; }
    .rest-meta span i { color: #16a34a; width: 16px; }
    .stars { color: #d4af37; font-size: 0.85rem; }
    .stars .empty { color: #d1d5db; }
</style>
@endpush

@section('content')
    <section class="page-hero">
        <div class="container text-center">
            <h1 class="fw-bold"><i class="fas fa-utensils me-2" style="color:#d4af37"></i>Saudi Dining</h1>
            <p class="lead opacity-75">From traditional Najdi cuisine to world-class fine dining</p>
        </div>
    </section>

    <div class="container pb-5">
        <form class="filter-bar mb-4" method="GET">
            <div class="row g-2 align-items-end">
                <div class="col-md-3">
                    <input type="text" name="search" class="form-control" placeholder="Search restaurants..." value="{{ request('search') }}">
                </div>
                <div class="col-md-2">
                    <select name="city" class="form-select">
                        <option value="">All Cities</option>
                        @foreach($cities as $c)
                            <option value="{{ $c }}" {{ request('city') == $c ? 'selected' : '' }}>{{ $c }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="cuisine" class="form-select">
                        <option value="">All Cuisines</option>
                        @foreach($cuisines as $cuisine)
                            <option value="{{ $cuisine }}" {{ request('cuisine') == $cuisine ? 'selected' : '' }}>{{ $cuisine }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="sort" class="form-select">
                        <option value="rating" {{ request('sort') == 'rating' ? 'selected' : '' }}>Top Rated</option>
                        <option value="price_low" {{ request('sort') == 'price_low' ? 'selected' : '' }}>Price: Low</option>
                        <option value="price_high" {{ request('sort') == 'price_high' ? 'selected' : '' }}>Price: High</option>
                        <option value="name" {{ request('sort') == 'name' ? 'selected' : '' }}>Name A-Z</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button class="btn w-100 text-white" style="background:#16a34a"><i class="fas fa-search me-1"></i>Search</button>
                </div>
            </div>
        </form>

        <p class="text-muted mb-3">Showing {{ $restaurants->total() }} restaurants</p>

        <div class="row g-4">
            @forelse($restaurants as $rest)
                @php
                    $gradients = ['linear-gradient(135deg,#dc2626,#991b1b)','linear-gradient(135deg,#d4af37,#b8941f)','linear-gradient(135deg,#16a34a,#15803d)','linear-gradient(135deg,#0f4c81,#1a365d)','linear-gradient(135deg,#8b5cf6,#6d28d9)','linear-gradient(135deg,#0891b2,#0e7490)'];
                    $gradient = $gradients[$rest->id % count($gradients)];
                    $icons = ['fa-utensils','fa-drumstick-bite','fa-fish','fa-mug-hot','fa-pizza-slice','fa-bowl-food','fa-burger','fa-plate-wheat'];
                    $icon = $icons[$rest->id % count($icons)];
                    $fullStars = floor($rest->rating);
                    $emptyStars = 5 - $fullStars;
                @endphp
                <div class="col-lg-4 col-md-6">
                    <div class="rest-card">
                        <div class="card-img" style="background:{{ $gradient }}">
                            <i class="fas {{ $icon }}"></i>
                            <span class="cuisine-badge">{{ $rest->cuisine_type }}</span>
                            <span class="rating-badge"><i class="fas fa-star me-1"></i>{{ number_format($rest->rating, 1) }}</span>
                            <button class="fav-heart {{ in_array($rest->id, $favIds) ? 'active' : '' }}" style="top:48px" onclick="toggleFav(this,'restaurant',{{ $rest->id }})" title="Add to favorites">
                                <i class="fas fa-heart"></i>
                            </button>
                        </div>
                        <div class="card-body">
                            <h5>{{ $rest->name }}</h5>
                            <div class="stars mb-2">
                                @for($i = 0; $i < $fullStars; $i++)<i class="fas fa-star"></i>@endfor
                                @for($i = 0; $i < $emptyStars; $i++)<i class="fas fa-star empty"></i>@endfor
                            </div>
                            <p>{{ Str::limit($rest->description, 110) }}</p>
                            <div class="rest-meta d-flex flex-column gap-1 mt-auto">
                                <span><i class="fas fa-map-marker-alt me-1"></i>{{ $rest->city }} — {{ $rest->location_address }}</span>
                                <span><i class="fas fa-clock me-1"></i>{{ \Carbon\Carbon::parse($rest->opening_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($rest->closing_time)->format('g:i A') }}</span>
                                @if($rest->phone)
                                    <span><i class="fas fa-phone me-1"></i>{{ $rest->phone }}</span>
                                @endif
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-between align-items-center">
                            <div>
                                <span class="fw-bold" style="color:#16a34a">Avg. {{ number_format($rest->average_cost) }} SAR</span>
                                <span class="text-muted small">/ person</span>
                            </div>
                            @if($rest->featured)
                                <span class="badge text-white" style="background:#d4af37"><i class="fas fa-crown me-1"></i>Featured</span>
                            @endif
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-12 text-center py-5">
                    <i class="fas fa-search fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">No restaurants found</h4>
                    <p class="text-muted">Try adjusting your search filters</p>
                </div>
            @endforelse
        </div>

        <div class="d-flex justify-content-center mt-4">
            {{ $restaurants->withQueryString()->links() }}
        </div>
    </div>
@endsection
