@extends('layouts.app')
@section('title', 'Find & Hire Expert Guides - Tourist Guide')

@push('styles')
<style>
    .guide-hero {
        background: linear-gradient(135deg, rgba(15,23,42,0.9), rgba(30,41,59,0.8)), url('https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=1920') center/cover;
        padding: 4rem 0;
        color: #fff;
    }
    .guide-hero h1 { font-weight: 800; font-size: 2.5rem; }
    .guide-hero .lead { opacity: 0.9; }

    .filter-bar {
        background: #e5e7eb;
        border-radius: 16px;
        padding: 1.5rem;
        box-shadow: 0 4px 20px rgba(107,114,128,0.15);
        margin-top: -2.5rem;
        position: relative;
        z-index: 10;
    }
    .filter-bar .form-control, .filter-bar .form-select {
        border-radius: 10px;
        border: 2px solid #e2e8f0;
        padding: 0.7rem 1rem;
    }
    .filter-bar .form-control:focus, .filter-bar .form-select:focus {
        border-color: #2563eb;
        box-shadow: 0 0 0 3px rgba(37,99,235,0.1);
    }
    .filter-bar .btn-search {
        background: #2563eb;
        color: #fff;
        border-radius: 10px;
        padding: 0.7rem 2rem;
        font-weight: 600;
    }

    .guide-card {
        background: #e5e7eb;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 2px 15px rgba(107,114,128,0.12);
        transition: all 0.3s;
        height: 100%;
        border: 2px solid transparent;
    }
    .guide-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 40px rgba(107,114,128,0.25);
        border-color: #16a34a;
    }
    .guide-card .guide-photo {
        height: 200px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 4rem;
        color: #fff;
        position: relative;
    }
    .guide-card .guide-photo .verified-badge {
        position: absolute;
        top: 12px;
        right: 12px;
        background: #16a34a;
        color: #fff;
        padding: 0.2rem 0.7rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
    }
    .guide-card .guide-photo .car-badge {
        position: absolute;
        top: 12px;
        left: 12px;
        background: #2563eb;
        color: #fff;
        padding: 0.2rem 0.7rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
    }
    .guide-card .guide-info { padding: 1.3rem; }
    .guide-card .guide-name { font-weight: 700; font-size: 1.15rem; color: #1e293b; }
    .guide-card .guide-city { color: #64748b; font-size: 0.9rem; }
    .guide-card .guide-spec { color: #2563eb; font-weight: 600; font-size: 0.85rem; }
    .guide-card .guide-meta { border-top: 1px solid #f1f5f9; padding-top: 0.8rem; margin-top: 0.8rem; }
    .guide-card .stars { color: #f59e0b; }
    .guide-card .price-tag {
        background: #eff6ff;
        color: #2563eb;
        padding: 0.3rem 0.8rem;
        border-radius: 8px;
        font-weight: 700;
        font-size: 0.95rem;
    }
    .guide-card .lang-tag {
        display: inline-block;
        background: #f1f5f9;
        color: #475569;
        padding: 0.15rem 0.5rem;
        border-radius: 6px;
        font-size: 0.75rem;
        margin-right: 0.3rem;
        margin-bottom: 0.3rem;
    }
    .btn-hire {
        background: #f59e0b;
        color: #fff;
        border: none;
        border-radius: 10px;
        padding: 0.6rem 1.5rem;
        font-weight: 600;
        width: 100%;
        transition: all 0.3s;
    }
    .btn-hire:hover { background: #d97706; color: #fff; transform: translateY(-1px); }
    .btn-view {
        border: 2px solid #e2e8f0;
        background: transparent;
        border-radius: 10px;
        padding: 0.6rem 1.5rem;
        font-weight: 600;
        width: 100%;
        color: #475569;
        transition: all 0.3s;
    }
    .btn-view:hover { border-color: #2563eb; color: #2563eb; }
    .results-count { color: #64748b; font-weight: 500; }

    .how-it-works { background: #f8fafc; padding: 3rem 0; }
    .step-card { text-align: center; padding: 1.5rem; }
    .step-card .step-num {
        width: 45px; height: 45px;
        background: #2563eb;
        color: #fff;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 1.2rem;
        margin: 0 auto 1rem;
    }
    .step-card h5 { font-weight: 700; color: #1e293b; }
    .step-card p { color: #64748b; font-size: 0.95rem; }
</style>
@endpush

@section('content')
    <!-- Hero -->
    <section class="guide-hero">
        <div class="container text-center">
            <span class="badge bg-warning text-dark fs-6 mb-3 px-3 py-2 rounded-pill">
                <i class="fas fa-user-tie me-1"></i>Professional Local Guides
            </span>
            <h1>Find & Hire Expert Guides</h1>
            <p class="lead">Explore with a knowledgeable local. Choose with or without a car.<br>Hourly rates, verified profiles, real reviews.</p>
        </div>
    </section>

    <!-- Search & Filter Bar -->
    <div class="container">
        <div class="filter-bar">
            <form action="{{ url('/guides') }}" method="GET">
                <div class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <label class="form-label fw-semibold"><i class="fas fa-search me-1"></i>Search</label>
                        <input type="text" name="search" class="form-control" placeholder="Name, city, or specialty..." value="{{ request('search') }}">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-semibold"><i class="fas fa-language me-1"></i>Language</label>
                        <select name="language" class="form-select">
                            <option value="">All Languages</option>
                            <option value="English" {{ request('language') == 'English' ? 'selected' : '' }}>English</option>
                            <option value="Arabic" {{ request('language') == 'Arabic' ? 'selected' : '' }}>Arabic</option>
                            <option value="French" {{ request('language') == 'French' ? 'selected' : '' }}>French</option>
                            <option value="Spanish" {{ request('language') == 'Spanish' ? 'selected' : '' }}>Spanish</option>
                            <option value="German" {{ request('language') == 'German' ? 'selected' : '' }}>German</option>
                            <option value="Chinese" {{ request('language') == 'Chinese' ? 'selected' : '' }}>Chinese</option>
                            <option value="Urdu" {{ request('language') == 'Urdu' ? 'selected' : '' }}>Urdu</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-semibold"><i class="fas fa-dollar-sign me-1"></i>Max $/hr</label>
                        <input type="number" name="max_price" class="form-control" placeholder="e.g. 100" value="{{ request('max_price') }}">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-semibold"><i class="fas fa-car me-1"></i>Transport</label>
                        <select name="has_car" class="form-select">
                            <option value="">All Guides</option>
                            <option value="1" {{ request('has_car') == '1' ? 'selected' : '' }}>With Car Only</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-semibold"><i class="fas fa-sort me-1"></i>Sort By</label>
                        <select name="sort" class="form-select">
                            <option value="rating" {{ request('sort') == 'rating' ? 'selected' : '' }}>Top Rated</option>
                            <option value="price_low" {{ request('sort') == 'price_low' ? 'selected' : '' }}>Price: Low</option>
                            <option value="price_high" {{ request('sort') == 'price_high' ? 'selected' : '' }}>Price: High</option>
                            <option value="experience" {{ request('sort') == 'experience' ? 'selected' : '' }}>Experience</option>
                            <option value="tours" {{ request('sort') == 'tours' ? 'selected' : '' }}>Most Tours</option>
                        </select>
                    </div>
                    <div class="col-md-1">
                        <button type="submit" class="btn btn-search w-100"><i class="fas fa-search"></i></button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- How It Works -->
    <section class="how-it-works mt-0">
        <div class="container">
            <h3 class="text-center fw-bold mb-4">How It Works</h3>
            <div class="row">
                <div class="col-md-3">
                    <div class="step-card">
                        <div class="step-num">1</div>
                        <h5>Browse Guides</h5>
                        <p>Search by city, language, specialty, or price range</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="step-card">
                        <div class="step-num">2</div>
                        <h5>Choose Service</h5>
                        <p>Walking tour or with car transport. Set your duration</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="step-card">
                        <div class="step-num">3</div>
                        <h5>Book & Pay</h5>
                        <p>Select date, time, and group size. Confirm your booking</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="step-card">
                        <div class="step-num">4</div>
                        <h5>Enjoy!</h5>
                        <p>Meet your guide and explore with a knowledgeable local</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Guide Listing -->
    <section class="py-5">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Available Guides</h3>
                    <p class="results-count mb-0">{{ $guides->total() }} guides found</p>
                </div>
            </div>

            <div class="row g-4">
                @forelse($guides as $guide)
                    @php
                        $bgColors = ['#6366f1', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316', '#06b6d4', '#84cc16'];
                        $bgColor = $bgColors[$guide->id % count($bgColors)];
                        $avgRating = $guide->reviews_avg_rating ?? $guide->rating;
                    @endphp
                    <div class="col-lg-4 col-md-6">
                        <div class="guide-card">
                            <div class="guide-photo" style="background: linear-gradient(135deg, {{ $bgColor }}, {{ $bgColor }}dd);">
                                <i class="fas fa-user"></i>
                                <span class="verified-badge"><i class="fas fa-check me-1"></i>Verified</span>
                                @if($guide->has_car)
                                    <span class="car-badge"><i class="fas fa-car me-1"></i>Has Car</span>
                                @endif
                            </div>
                            <div class="guide-info">
                                <div class="d-flex justify-content-between align-items-start mb-1">
                                    <div>
                                        <div class="guide-name">{{ $guide->user->name ?? 'Guide' }}</div>
                                        <div class="guide-city"><i class="fas fa-map-marker-alt me-1"></i>{{ $guide->city ?? 'Not specified' }}</div>
                                    </div>
                                    <div class="price-tag">${{ number_format($guide->hourly_rate, 0) }}/hr</div>
                                </div>

                                @if($guide->specialization)
                                    <div class="guide-spec mt-1"><i class="fas fa-star me-1"></i>{{ $guide->specialization }}</div>
                                @endif

                                <div class="mt-2">
                                    @if(is_array($guide->languages))
                                        @foreach(array_slice($guide->languages, 0, 3) as $lang)
                                            <span class="lang-tag"><i class="fas fa-globe me-1"></i>{{ $lang }}</span>
                                        @endforeach
                                        @if(count($guide->languages) > 3)
                                            <span class="lang-tag">+{{ count($guide->languages) - 3 }}</span>
                                        @endif
                                    @endif
                                </div>

                                <div class="guide-meta">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <div>
                                            <span class="stars">
                                                @for($i = 1; $i <= 5; $i++)
                                                    @if($i <= round($avgRating))
                                                        <i class="fas fa-star"></i>
                                                    @else
                                                        <i class="far fa-star"></i>
                                                    @endif
                                                @endfor
                                            </span>
                                            <span class="text-muted small">({{ $guide->reviews_count ?? 0 }})</span>
                                        </div>
                                        <div class="text-muted small">
                                            <i class="fas fa-briefcase me-1"></i>{{ $guide->experience_years ?? 0 }} yrs
                                            <span class="mx-1">|</span>
                                            <i class="fas fa-route me-1"></i>{{ $guide->total_tours_completed ?? 0 }} tours
                                        </div>
                                    </div>

                                    @if($guide->has_car)
                                        <div class="text-muted small mb-2">
                                            <i class="fas fa-car text-primary me-1"></i>With car: <strong>${{ number_format($guide->hourly_rate_with_car, 0) }}/hr</strong>
                                        </div>
                                    @endif

                                    <div class="d-flex gap-2">
                                        <a href="{{ route('guides.show', $guide->id) }}" class="btn btn-view flex-fill">
                                            <i class="fas fa-eye me-1"></i>View Profile
                                        </a>
                                        <a href="{{ route('guides.hire', $guide->id) }}" class="btn btn-hire flex-fill">
                                            <i class="fas fa-handshake me-1"></i>Hire
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="col-12 text-center py-5">
                        <i class="fas fa-user-tie fa-4x text-muted mb-3"></i>
                        <h4 class="text-muted">No guides found</h4>
                        <p class="text-muted">Try adjusting your search filters or check back later.</p>
                    </div>
                @endforelse
            </div>

            @if($guides->hasPages())
                <div class="d-flex justify-content-center mt-5">
                    {{ $guides->withQueryString()->links() }}
                </div>
            @endif
        </div>
    </section>
@endsection
