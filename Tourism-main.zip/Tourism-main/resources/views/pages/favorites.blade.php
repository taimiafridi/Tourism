@extends('layouts.app')
@section('title', 'My Favorites - Wanderly')

@push('styles')
<style>
    .fav-hero { background: linear-gradient(135deg, rgba(22,163,74,0.92), rgba(21,128,61,0.88)); padding: 3rem 0; color: #fff; }
    .fav-tabs { display: flex; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 2rem; }
    .fav-tab {
        padding: 0.5rem 1.2rem; border-radius: 25px; border: 2px solid #e2e8f0;
        background: #f8fafc; color: #475569; cursor: pointer; font-weight: 600; font-size: 0.9rem;
        transition: all 0.3s;
    }
    .fav-tab:hover { border-color: #16a34a; color: #16a34a; }
    .fav-tab.active { background: #16a34a; color: #fff; border-color: #16a34a; }
    .fav-tab .count { background: rgba(255,255,255,0.3); padding: 0.1rem 0.5rem; border-radius: 12px; margin-left: 0.4rem; font-size: 0.8rem; }
    .fav-tab.active .count { background: rgba(255,255,255,0.3); }
    .fav-tab:not(.active) .count { background: #e2e8f0; }
    .fav-card {
        background: #fff; border-radius: 14px; overflow: hidden;
        box-shadow: 0 2px 15px rgba(0,0,0,0.08); transition: transform 0.3s, box-shadow 0.3s;
        height: 100%; display: flex; flex-direction: column;
    }
    .fav-card:hover { transform: translateY(-4px); box-shadow: 0 8px 30px rgba(0,0,0,0.12); }
    .fav-card .card-img {
        height: 160px; display: flex; align-items: center; justify-content: center; position: relative;
    }
    .fav-card .card-img i { font-size: 3rem; color: rgba(255,255,255,0.6); }
    .fav-card .card-body { padding: 1.2rem; flex: 1; display: flex; flex-direction: column; }
    .fav-card .card-body h5 { font-weight: 700; color: #1e293b; margin-bottom: 0.5rem; }
    .fav-card .card-body p { color: #64748b; font-size: 0.9rem; flex: 1; }
    .fav-card .card-footer {
        padding: 0.8rem 1.2rem; background: #f8fafc; border-top: 1px solid #f1f5f9;
        display: flex; justify-content: space-between; align-items: center;
    }
    .btn-unfav {
        background: none; border: none; color: #ef4444; cursor: pointer; font-size: 1.2rem;
        transition: transform 0.2s;
    }
    .btn-unfav:hover { transform: scale(1.2); }
    .type-badge {
        display: inline-block; padding: 0.2rem 0.7rem; border-radius: 15px;
        font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;
        position: absolute; top: 10px; left: 10px;
    }
    .type-destination { background: #dcfce7; color: #166534; }
    .type-tour { background: #dbeafe; color: #1e40af; }
    .type-event { background: #fef3c7; color: #92400e; }
    .type-restaurant { background: #fce7f3; color: #9d174d; }
    .empty-state { text-align: center; padding: 4rem 1rem; }
    .empty-state i { font-size: 4rem; color: #cbd5e1; margin-bottom: 1rem; }
</style>
@endpush

@section('content')
<section class="fav-hero">
    <div class="container text-center">
        <h1 class="fw-bold"><i class="fas fa-heart me-2"></i>My Favorites</h1>
        <p class="opacity-75 mb-0">Your saved destinations, tours, events & restaurants</p>
    </div>
</section>

<div class="container py-4">
    @php
        $grouped = [
            'all' => $favorites,
            'destinations' => $favorites->filter(fn($f) => $f->favoritable_type === 'App\Models\Destination'),
            'tours' => $favorites->filter(fn($f) => $f->favoritable_type === 'App\Models\Tour'),
            'events' => $favorites->filter(fn($f) => $f->favoritable_type === 'App\Models\Event'),
            'restaurants' => $favorites->filter(fn($f) => $f->favoritable_type === 'App\Models\Restaurant'),
        ];
    @endphp

    <div class="fav-tabs">
        <div class="fav-tab active" data-filter="all">All<span class="count">{{ $grouped['all']->count() }}</span></div>
        <div class="fav-tab" data-filter="destination"><i class="fas fa-map-pin me-1"></i>Destinations<span class="count">{{ $grouped['destinations']->count() }}</span></div>
        <div class="fav-tab" data-filter="tour"><i class="fas fa-route me-1"></i>Tours<span class="count">{{ $grouped['tours']->count() }}</span></div>
        <div class="fav-tab" data-filter="event"><i class="fas fa-calendar me-1"></i>Events<span class="count">{{ $grouped['events']->count() }}</span></div>
        <div class="fav-tab" data-filter="restaurant"><i class="fas fa-utensils me-1"></i>Restaurants<span class="count">{{ $grouped['restaurants']->count() }}</span></div>
    </div>

    @if($favorites->isEmpty())
        <div class="empty-state">
            <i class="fas fa-heart"></i>
            <h4 class="text-muted">No favorites yet</h4>
            <p class="text-muted">Start exploring and tap the heart icon to save your favorites.</p>
            <a href="{{ url('/destinations') }}" class="btn btn-primary mt-2">
                <i class="fas fa-compass me-2"></i>Explore Destinations
            </a>
        </div>
    @else
        <div class="row g-4" id="favGrid">
            @foreach($favorites as $fav)
                @if($fav->favoritable)
                    @php
                        $item = $fav->favoritable;
                        $typeMap = [
                            'App\Models\Destination' => 'destination',
                            'App\Models\Tour' => 'tour',
                            'App\Models\Event' => 'event',
                            'App\Models\Restaurant' => 'restaurant',
                        ];
                        $type = $typeMap[$fav->favoritable_type] ?? 'unknown';
                        $gradients = [
                            'destination' => 'linear-gradient(135deg,#16a34a,#15803d)',
                            'tour' => 'linear-gradient(135deg,#2563eb,#1d4ed8)',
                            'event' => 'linear-gradient(135deg,#d97706,#b45309)',
                            'restaurant' => 'linear-gradient(135deg,#dc2626,#b91c1c)',
                        ];
                        $icons = [
                            'destination' => 'fa-map-pin',
                            'tour' => 'fa-route',
                            'event' => 'fa-calendar-day',
                            'restaurant' => 'fa-utensils',
                        ];
                        $links = [
                            'destination' => url('/destinations/' . $item->id),
                            'tour' => url('/tours'),
                            'event' => url('/events'),
                            'restaurant' => url('/restaurants'),
                        ];
                    @endphp
                    <div class="col-lg-4 col-md-6 fav-item" data-type="{{ $type }}" id="fav-{{ $type }}-{{ $item->id }}">
                        <div class="fav-card">
                            <div class="card-img" style="background:{{ $gradients[$type] }}">
                                <i class="fas {{ $icons[$type] }}"></i>
                                <span class="type-badge type-{{ $type }}">{{ ucfirst($type) }}</span>
                            </div>
                            <div class="card-body">
                                <h5>{{ $item->name }}</h5>
                                <p>{{ Str::limit($item->description ?? '', 120) }}</p>
                                <div class="text-muted small">
                                    @if(isset($item->city))
                                        <i class="fas fa-map-marker-alt me-1"></i>{{ $item->city }}
                                    @endif
                                    @if($type === 'tour' && isset($item->price))
                                        <span class="ms-2"><i class="fas fa-tag me-1"></i>{{ number_format($item->price) }} SAR</span>
                                    @endif
                                    @if($type === 'event' && isset($item->start_date))
                                        <span class="ms-2"><i class="fas fa-calendar me-1"></i>{{ \Carbon\Carbon::parse($item->start_date)->format('M d, Y') }}</span>
                                    @endif
                                    @if($type === 'restaurant' && isset($item->cuisine_type))
                                        <span class="ms-2"><i class="fas fa-utensils me-1"></i>{{ $item->cuisine_type }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="card-footer">
                                <a href="{{ $links[$type] }}" class="text-decoration-none fw-semibold" style="color:#16a34a">
                                    <i class="fas fa-eye me-1"></i>View
                                </a>
                                <button class="btn-unfav" onclick="removeFav('{{ $type }}', {{ $item->id }})" title="Remove from favorites">
                                    <i class="fas fa-heart-broken"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                @endif
            @endforeach
        </div>
    @endif
</div>
@endsection

@push('scripts')
<script>
// Tab filtering
document.querySelectorAll('.fav-tab').forEach(tab => {
    tab.addEventListener('click', function() {
        document.querySelectorAll('.fav-tab').forEach(t => t.classList.remove('active'));
        this.classList.add('active');
        const filter = this.dataset.filter;
        document.querySelectorAll('.fav-item').forEach(item => {
            item.style.display = (filter === 'all' || item.dataset.type === filter) ? '' : 'none';
        });
    });
});

// Remove favorite
function removeFav(type, itemId) {
    const card = document.getElementById('fav-' + type + '-' + itemId);
    fetch('{{ route("favorites.toggle") }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
        },
        body: JSON.stringify({ type: type, item_id: itemId })
    })
    .then(r => r.json())
    .then(data => {
        if (!data.is_favorited) {
            card.style.transition = 'opacity 0.3s, transform 0.3s';
            card.style.opacity = '0';
            card.style.transform = 'scale(0.8)';
            setTimeout(() => {
                card.remove();
                updateCounts();
                if (!document.querySelector('.fav-item')) {
                    location.reload();
                }
            }, 300);
        }
    });
}

function updateCounts() {
    const all = document.querySelectorAll('.fav-item').length;
    const dest = document.querySelectorAll('.fav-item[data-type="destination"]').length;
    const tour = document.querySelectorAll('.fav-item[data-type="tour"]').length;
    const event = document.querySelectorAll('.fav-item[data-type="event"]').length;
    const rest = document.querySelectorAll('.fav-item[data-type="restaurant"]').length;
    document.querySelectorAll('.fav-tab').forEach(tab => {
        const f = tab.dataset.filter;
        const count = { all, destination: dest, tour, event, restaurant: rest }[f] || 0;
        tab.querySelector('.count').textContent = count;
    });
}
</script>
@endpush
