@extends('layouts.app')
@section('title', 'Tours - Wanderly')

@push('styles')
<style>
    .page-hero {
        background: linear-gradient(135deg, rgba(0,108,53,0.9), rgba(0,77,37,0.85));
        padding: 3rem 0;
        color: #fff;
    }
    .filter-bar {
        background: #e5e7eb;
        border-radius: 12px;
        padding: 1.2rem;
        box-shadow: 0 2px 15px rgba(107,114,128,0.12);
        margin-top: -2rem;
        position: relative;
        z-index: 10;
    }
    .filter-bar .form-control, .filter-bar .form-select {
        border-radius: 8px;
        border: 2px solid #e2e8f0;
        padding: 0.6rem 1rem;
    }
    .tour-card {
        background: #e5e7eb;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(107,114,128,0.15);
        transition: all 0.3s;
        height: 100%;
        display: flex;
        flex-direction: column;
        border: 2px solid transparent;
    }
    .tour-card:hover { transform: translateY(-5px); box-shadow: 0 15px 35px rgba(107,114,128,0.25); border-color: #16a34a; }
    .tour-card .card-img {
        height: 180px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 2.5rem;
        position: relative;
    }
    .tour-card .card-img .duration-badge {
        position: absolute;
        top: 12px;
        left: 12px;
        background: rgba(0,0,0,0.6);
        color: #fff;
        padding: 0.3rem 0.8rem;
        border-radius: 20px;
        font-size: 0.78rem;
        font-weight: 600;
    }
    .tour-card .card-img .price-badge {
        position: absolute;
        bottom: 12px;
        right: 12px;
        background: #d4af37;
        color: #fff;
        padding: 0.4rem 1rem;
        border-radius: 20px;
        font-weight: 800;
        font-size: 0.95rem;
    }
    .tour-card .card-body { padding: 1.2rem; flex: 1; display: flex; flex-direction: column; }
    .tour-card .card-body h5 { font-weight: 700; color: #1e293b; font-size: 1rem; }
    .tour-card .card-body p { color: #64748b; font-size: 0.88rem; flex: 1; }
    .tour-card .card-footer { padding: 0.8rem 1.2rem; background: #f8fafc; border-top: 1px solid #e2e8f0; }
    .tour-meta span { font-size: 0.82rem; color: #64748b; }
    .tour-meta span i { color: #16a34a; width: 16px; }
    .btn-book {
        background: #16a34a;
        color: #fff;
        border: none;
        border-radius: 8px;
        padding: 0.5rem 1.2rem;
        font-weight: 600;
        font-size: 0.85rem;
    }
    .btn-book:hover { background: #15803d; color: #fff; }
</style>
@endpush

@section('content')
    <section class="page-hero">
        <div class="container text-center">
            <h1 class="fw-bold"><i class="fas fa-route me-2" style="color:#d4af37"></i>Saudi Tours</h1>
            <p class="lead opacity-75">Guided adventures across the Kingdom — from desert safaris to coastal escapes</p>
        </div>
    </section>

    <div class="container pb-5">
        <form class="filter-bar mb-4" method="GET">
            <div class="row g-2 align-items-end">
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Search tours..." value="{{ request('search') }}">
                </div>
                <div class="col-md-2">
                    <select name="max_price" class="form-select">
                        <option value="">Max Price</option>
                        <option value="300" {{ request('max_price') == '300' ? 'selected' : '' }}>Under 300 SAR</option>
                        <option value="500" {{ request('max_price') == '500' ? 'selected' : '' }}>Under 500 SAR</option>
                        <option value="1000" {{ request('max_price') == '1000' ? 'selected' : '' }}>Under 1,000 SAR</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="duration" class="form-select">
                        <option value="">Duration</option>
                        <option value="1" {{ request('duration') == '1' ? 'selected' : '' }}>1 Day</option>
                        <option value="2" {{ request('duration') == '2' ? 'selected' : '' }}>Up to 2 Days</option>
                        <option value="5" {{ request('duration') == '5' ? 'selected' : '' }}>Up to 5 Days</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="sort" class="form-select">
                        <option value="date" {{ request('sort') == 'date' ? 'selected' : '' }}>Soonest</option>
                        <option value="price_low" {{ request('sort') == 'price_low' ? 'selected' : '' }}>Price: Low</option>
                        <option value="price_high" {{ request('sort') == 'price_high' ? 'selected' : '' }}>Price: High</option>
                        <option value="name" {{ request('sort') == 'name' ? 'selected' : '' }}>Name A-Z</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button class="btn w-100 text-white" style="background:#16a34a"><i class="fas fa-search me-1"></i>Search</button>
                </div>
            </div>
        </form>

        @guest
            <div class="alert alert-warning border-0 rounded-3 mb-4">
                <i class="fas fa-lock me-2"></i>You need to <a href="{{ route('login') }}" class="fw-bold text-decoration-none">login</a> to book tours.
            </div>
        @endguest

        <p class="text-muted mb-3">Showing {{ $tours->total() }} tours</p>

        <div class="row g-4">
            @forelse($tours as $tour)
                @php
                    $gradients = ['linear-gradient(135deg,#0891b2,#0e7490)','linear-gradient(135deg,#d4af37,#b8941f)','linear-gradient(135deg,#16a34a,#15803d)','linear-gradient(135deg,#8b5cf6,#6d28d9)','linear-gradient(135deg,#dc2626,#991b1b)','linear-gradient(135deg,#0f4c81,#1a365d)'];
                    $gradient = $gradients[$tour->id % count($gradients)];
                    $icons = ['fa-route','fa-mountain','fa-mosque','fa-umbrella-beach','fa-hiking','fa-binoculars','fa-compass','fa-horse'];
                    $icon = $icons[$tour->id % count($icons)];
                @endphp
                <div class="col-lg-4 col-md-6">
                    <div class="tour-card">
                        <div class="card-img" style="background:{{ $gradient }}">
                            <i class="fas {{ $icon }}"></i>
                            <span class="duration-badge"><i class="fas fa-clock me-1"></i>{{ $tour->duration_days }} {{ $tour->duration_days == 1 ? 'Day' : 'Days' }}</span>
                            <span class="price-badge">{{ number_format($tour->price) }} SAR</span>
                            <button class="fav-heart {{ in_array($tour->id, $favIds) ? 'active' : '' }}" onclick="toggleFav(this,'tour',{{ $tour->id }})" title="Add to favorites">
                                <i class="fas fa-heart"></i>
                            </button>
                        </div>
                        <div class="card-body">
                            <h5>{{ $tour->name }}</h5>
                            <p>{{ Str::limit($tour->description, 110) }}</p>
                            <div class="tour-meta d-flex flex-column gap-1 mt-auto">
                                @if($tour->destination)
                                    <span><i class="fas fa-map-marker-alt me-1"></i>{{ $tour->destination->name }}</span>
                                @endif
                                @if($tour->guide && $tour->guide->user)
                                    <span><i class="fas fa-user-tie me-1"></i>Guide: {{ $tour->guide->user->name }}</span>
                                @endif
                                <span><i class="fas fa-calendar me-1"></i>{{ $tour->start_date->format('M d, Y') }}</span>
                                <span><i class="fas fa-users me-1"></i>Max {{ $tour->max_participants }} participants</span>
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-between align-items-center">
                            <div>
                                <span class="fw-bold" style="color:#16a34a;font-size:1.1rem">{{ number_format($tour->price) }} SAR</span>
                                <span class="text-muted small">/ person</span>
                            </div>
                            @auth
                                <a href="{{ route('tours.book', $tour->id) }}" class="btn btn-book"><i class="fas fa-ticket-alt me-1"></i>Book Now</a>
                            @else
                                <a href="{{ route('login') }}" class="btn btn-book"><i class="fas fa-lock me-1"></i>Login to Book</a>
                            @endauth
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-12 text-center py-5">
                    <i class="fas fa-search fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">No tours found</h4>
                    <p class="text-muted">Try adjusting your search filters</p>
                </div>
            @endforelse
        </div>

        <div class="d-flex justify-content-center mt-4">
            {{ $tours->withQueryString()->links() }}
        </div>
    </div>
@endsection
