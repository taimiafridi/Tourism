<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Admin Dashboard') - Tourist Guide</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --sidebar-width: 260px;
            --primary: #2563eb;
            --dark: #0f172a;
            --dark-light: #1e293b;
            --accent: #f59e0b;
        }
        body { font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; background: #f1f5f9; }

        /* Sidebar */
        .sidebar {
            width: var(--sidebar-width);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: linear-gradient(180deg, var(--dark) 0%, var(--dark-light) 100%);
            color: #fff;
            z-index: 1000;
            overflow-y: auto;
            transition: transform 0.3s;
        }
        .sidebar-brand {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            font-size: 1.3rem;
            font-weight: 700;
        }
        .sidebar-brand i { color: var(--accent); }
        .sidebar-nav { padding: 1rem 0; }
        .sidebar-nav .nav-label {
            padding: 0.5rem 1.5rem;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: rgba(255,255,255,0.4);
            font-weight: 600;
        }
        .sidebar-nav .nav-item a {
            display: flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .sidebar-nav .nav-item a:hover,
        .sidebar-nav .nav-item a.active {
            color: #fff;
            background: rgba(255,255,255,0.08);
            border-left-color: var(--accent);
        }
        .sidebar-nav .nav-item a i { width: 20px; margin-right: 12px; font-size: 0.95rem; }

        /* Top bar */
        .topbar {
            margin-left: var(--sidebar-width);
            height: 65px;
            background: #fff;
            box-shadow: 0 1px 3px rgba(107,114,128,0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 2rem;
            position: sticky;
            top: 0;
            z-index: 999;
        }
        .topbar .page-title { font-weight: 700; font-size: 1.2rem; color: var(--dark); }

        /* Main content */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
            min-height: calc(100vh - 65px);
        }

        /* Cards */
        .stat-card {
            background: #e5e7eb;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(107,114,128,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            border: none;
        }
        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(107,114,128,0.2); border-color: #16a34a; }
        .stat-card .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
        }
        .stat-card .stat-value { font-size: 1.8rem; font-weight: 700; color: var(--dark); }
        .stat-card .stat-label { font-size: 0.85rem; color: #64748b; font-weight: 500; }

        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.show { transform: translateX(0); }
            .topbar, .main-content { margin-left: 0; }
        }

        @stack('styles')
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-map-marked-alt me-2"></i>Tourist Guide
            <small class="d-block text-muted" style="font-size: 0.7rem; font-weight: 400;">Admin Panel</small>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-label">Main</div>
            <div class="nav-item">
                <a href="{{ route('admin.dashboard') }}" class="{{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </div>

            <div class="nav-label mt-3">Management</div>
            <div class="nav-item">
                <a href="{{ route('admin.users') }}" class="{{ request()->routeIs('admin.users*') ? 'active' : '' }}">
                    <i class="fas fa-users"></i> Users
                </a>
            </div>
            <div class="nav-item">
                <a href="{{ route('admin.destinations') }}" class="{{ request()->routeIs('admin.destinations*') ? 'active' : '' }}">
                    <i class="fas fa-map-pin"></i> Destinations
                </a>
            </div>
            <div class="nav-item">
                <a href="{{ route('admin.tours') }}" class="{{ request()->routeIs('admin.tours*') ? 'active' : '' }}">
                    <i class="fas fa-route"></i> Tours
                </a>
            </div>
            <div class="nav-item">
                <a href="{{ route('admin.bookings') }}" class="{{ request()->routeIs('admin.bookings*') ? 'active' : '' }}">
                    <i class="fas fa-ticket-alt"></i> Bookings
                </a>
            </div>
            <div class="nav-item">
                <a href="{{ route('admin.guides') }}" class="{{ request()->routeIs('admin.guides*') ? 'active' : '' }}">
                    <i class="fas fa-user-tie"></i> Guides
                </a>
            </div>
            <div class="nav-item">
                <a href="{{ route('admin.events') }}" class="{{ request()->routeIs('admin.events*') ? 'active' : '' }}">
                    <i class="fas fa-calendar-alt"></i> Events
                </a>
            </div>
            <div class="nav-item">
                <a href="{{ route('admin.restaurants') }}" class="{{ request()->routeIs('admin.restaurants*') ? 'active' : '' }}">
                    <i class="fas fa-utensils"></i> Restaurants
                </a>
            </div>
            <div class="nav-item">
                <a href="{{ route('admin.reviews') }}" class="{{ request()->routeIs('admin.reviews*') ? 'active' : '' }}">
                    <i class="fas fa-star"></i> Reviews
                </a>
            </div>

            <div class="nav-label mt-3">Account</div>
            <div class="nav-item">
                <a href="{{ url('/') }}" target="_blank">
                    <i class="fas fa-external-link-alt"></i> View Site
                </a>
            </div>
            <div class="nav-item">
                <form action="{{ route('logout') }}" method="POST" class="m-0">
                    @csrf
                    <a href="#" onclick="this.closest('form').submit(); return false;">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </form>
            </div>
        </nav>
    </aside>

    <!-- Top Bar -->
    <header class="topbar">
        <div class="d-flex align-items-center">
            <button class="btn btn-link d-lg-none me-3" onclick="document.getElementById('sidebar').classList.toggle('show')">
                <i class="fas fa-bars fa-lg"></i>
            </button>
            <span class="page-title">@yield('page-title', 'Dashboard')</span>
        </div>
        <div class="d-flex align-items-center">
            <span class="text-muted me-3">{{ Auth::user()->name }}</span>
            <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" style="width:38px;height:38px;">
                {{ strtoupper(substr(Auth::user()->name, 0, 1)) }}
            </div>
        </div>
    </header>

    <!-- Content -->
    <div class="main-content">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @yield('content')
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    @stack('scripts')
</body>
</html>
