<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Wanderly - Discover Amazing Places')</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #16a34a;
            --primary-dark: #15803d;
            --primary-light: #22c55e;
            --accent: #d4af37;
            --dark: #1a1a2e;
            --light: #f8fafc;
        }
        body { font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; }

        /* Navbar */
        .navbar-custom {
            background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
            padding: 0.75rem 0;
            box-shadow: 0 4px 20px rgba(22, 163, 74, 0.15);
            transition: all 0.3s;
        }
        .navbar-custom.scrolled {
            padding: 0.5rem 0;
            box-shadow: 0 6px 25px rgba(22, 163, 74, 0.2);
        }
        .navbar-custom .navbar-brand {
            font-weight: 800;
            font-size: 1.4rem;
            color: #fff;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
        }
        .navbar-custom .navbar-brand i { 
            color: #d4af37;
            font-size: 1.6rem;
            margin-right: 0.5rem;
        }
        .navbar-custom .navbar-brand span {
            color: #d4af37;
            font-weight: 800;
        }
        .navbar-custom .nav-link {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            padding: 0.6rem 1.2rem;
            transition: all 0.3s;
            position: relative;
        }
        .navbar-custom .nav-link::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            width: 0;
            height: 2px;
            background: #d4af37;
            transition: all 0.3s;
            transform: translateX(-50%);
        }
        .navbar-custom .nav-link:hover::after,
        .navbar-custom .nav-link.active::after {
            width: 70%;
        }
        .navbar-custom .nav-link:hover,
        .navbar-custom .nav-link.active { 
            color: #d4af37;
        }
        .btn-accent {
            background: var(--accent);
            color: #1a1a2e;
            border: none;
            font-weight: 700;
            padding: 0.6rem 1.8rem;
            border-radius: 25px;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(212, 175, 55, 0.2);
        }
        .btn-accent:hover { 
            background: #f5d547;
            color: #1a1a2e;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(212, 175, 55, 0.3);
        }
        .btn-outline-light-custom {
            border: 2px solid rgba(255,255,255,0.6);
            color: #fff;
            border-radius: 25px;
            padding: 0.5rem 1.3rem;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-outline-light-custom:hover { 
            background: rgba(255,255,255,0.15);
            border-color: #fff;
            color: #fff;
        }
        .navbar-toggler {
            border: none;
            outline: none;
        }
        .navbar-toggler:focus {
            box-shadow: none;
        }

        /* Footer */
        .footer {
            background: var(--dark);
            color: rgba(255,255,255,0.7);
            padding: 3rem 0 1.5rem;
        }
        .footer h5 { color: #fff; font-weight: 600; margin-bottom: 1rem; }
        .footer a { color: rgba(255,255,255,0.6); text-decoration: none; transition: color 0.3s; }
        .footer a:hover { color: var(--accent); }
        .footer-bottom { border-top: 1px solid rgba(255,255,255,0.1); padding-top: 1.5rem; margin-top: 2rem; }
        /* Favorite heart button */
        .fav-heart {
            position: absolute; top: 10px; right: 10px; width: 36px; height: 36px;
            border-radius: 50%; border: none; background: rgba(255,255,255,0.9);
            color: #cbd5e1; font-size: 1rem; cursor: pointer; z-index: 5;
            display: flex; align-items: center; justify-content: center;
            transition: all 0.3s; box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }
        .fav-heart:hover { transform: scale(1.15); background: #fff; }
        .fav-heart.active { color: #ef4444; }
        .fav-heart.active i { animation: heartPop 0.3s ease; }
        @keyframes heartPop { 0%{transform:scale(1)} 50%{transform:scale(1.3)} 100%{transform:scale(1)} }
        @yield('styles')
    </style>
    @stack('styles')
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-custom sticky-top">
        <div class="container">
            <a class="navbar-brand" href="{{ url('/') }}">
                <i class="fas fa-compass me-2"></i>Wanderly
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link {{ request()->is('/') ? 'active' : '' }}" href="{{ url('/') }}"><i class="fas fa-home me-1"></i>Home</a></li>
                    <li class="nav-item"><a class="nav-link {{ request()->is('destinations*') ? 'active' : '' }}" href="{{ url('/destinations') }}"><i class="fas fa-map-pin me-1"></i>Destinations</a></li>
                    <li class="nav-item"><a class="nav-link {{ request()->is('tours*') ? 'active' : '' }}" href="{{ url('/tours') }}"><i class="fas fa-route me-1"></i>Tours</a></li>
                    <li class="nav-item"><a class="nav-link {{ request()->is('events*') ? 'active' : '' }}" href="{{ url('/events') }}"><i class="fas fa-calendar-alt me-1"></i>Events</a></li>
                    <li class="nav-item"><a class="nav-link {{ request()->is('restaurants*') ? 'active' : '' }}" href="{{ url('/restaurants') }}"><i class="fas fa-utensils me-1"></i>Restaurants</a></li>
                    <li class="nav-item"><a class="nav-link {{ request()->is('guides*') ? 'active' : '' }}" href="{{ url('/guides') }}"><i class="fas fa-user-tie me-1"></i>Guides</a></li>
                    <li class="nav-item"><a class="nav-link {{ request()->is('ai-assistant*') ? 'active' : '' }}" href="{{ url('/ai-assistant') }}" style="color:#d4af37"><i class="fas fa-robot me-1"></i>AI Guide</a></li>
                </ul>
                <div class="d-flex align-items-center gap-2">
                    @auth
                        <div class="dropdown">
                            <a class="btn btn-outline-light-custom dropdown-toggle" href="#" data-bs-toggle="dropdown">
                                <i class="fas fa-user me-1"></i>{{ Auth::user()->name }}
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="{{ url('/my-bookings') }}"><i class="fas fa-ticket-alt me-2"></i>My Bookings</a></li>
                                <li><a class="dropdown-item" href="{{ url('/favorites') }}"><i class="fas fa-heart me-2"></i>Favorites</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form action="{{ route('logout') }}" method="POST">
                                        @csrf
                                        <button class="dropdown-item text-danger"><i class="fas fa-sign-out-alt me-2"></i>Logout</button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    @else
                        <a href="{{ route('login') }}" class="btn btn-outline-light-custom">Login</a>
                        <a href="{{ route('register') }}" class="btn btn-accent">Sign Up</a>
                    @endauth
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show m-3" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show m-3" role="alert">
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @yield('content')
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-3">
                    <h5><i class="fas fa-compass me-2" style="color:#d4af37"></i>Wanderly</h5>
                    <p>Discover amazing destinations, tours, events, and dining experiences around the world.</p>
                    <div class="d-flex gap-3 mt-2">
                        <a href="#" class="text-white"><i class="fab fa-twitter fa-lg"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-youtube fa-lg"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 mb-3">
                    <h5>Explore</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="{{ url('/destinations') }}">Destinations</a></li>
                        <li class="mb-2"><a href="{{ url('/tours') }}">Tours</a></li>
                        <li class="mb-2"><a href="{{ url('/events') }}">Events</a></li>
                        <li class="mb-2"><a href="{{ url('/restaurants') }}">Restaurants</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-4 mb-3">
                    <h5>Services</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="{{ url('/guides') }}">Hire a Guide</a></li>
                        <li class="mb-2"><a href="{{ url('/tours') }}">Book a Tour</a></li>
                        <li class="mb-2"><a href="{{ url('/events') }}">Events</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-4 mb-3">
                    <h5>Contact</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><i class="fas fa-envelope me-2"></i>info@wanderly.com</li>
                        <li class="mb-2"><i class="fas fa-phone me-2"></i>+966 11 880 8855</li>
                        <li class="mb-2"><i class="fas fa-map-marker-alt me-2"></i>Riyadh, Kingdom of Saudi Arabia</li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom text-center">
                <p class="mb-0">&copy; {{ date('Y') }} Wanderly. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    @stack('scripts')
    <script>
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.navbar-custom');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
    </script>
    <script>
    function toggleFav(btn, type, itemId) {
        @auth
        fetch('{{ route("favorites.toggle") }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            },
            body: JSON.stringify({ type: type, item_id: itemId })
        })
        .then(r => r.json())
        .then(data => {
            btn.classList.toggle('active', data.is_favorited);
        });
        @else
        window.location.href = '{{ route("login") }}';
        @endauth
    }
    </script>
</body>
</html>
