@extends('layouts.app')
@section('title', 'Login - Wanderly')

@push('styles')
<style>
    .auth-page {
        min-height: 100vh;
        background: linear-gradient(135deg, #16a34a 0%, #15803d 50%, #127a3a 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 2rem;
    }
    .auth-card {
        background: #e5e7eb;
        border-radius: 16px;
        box-shadow: 0 25px 50px rgba(107,114,128,0.5);
        max-width: 440px;
        width: 100%;
        padding: 2.5rem;
        border-top: 4px solid #d4af37;
    }
    .auth-card .brand {
        text-align: center;
        margin-bottom: 2rem;
    }
    .auth-card .brand i { font-size: 2.5rem; color: #16a34a; }
    .auth-card .brand h2 { font-weight: 700; color: #1e293b; margin-top: 0.5rem; }
    .auth-card .form-control {
        border-radius: 10px;
        padding: 0.75rem 1rem;
        border: 2px solid #e2e8f0;
        transition: border-color 0.3s;
    }
    .auth-card .form-control:focus { border-color: #16a34a; box-shadow: 0 0 0 3px rgba(22,163,74,0.1); }
    .auth-card .btn-primary {
        border-radius: 10px;
        padding: 0.75rem;
        font-weight: 600;
        font-size: 1rem;
        background: #16a34a;
        border: none;
    }
    .auth-card .btn-primary:hover { background: #15803d; }
    .input-group-text { border-radius: 10px 0 0 10px; border: 2px solid #e2e8f0; border-right: none; background: #f8fafc; }
    .input-group .form-control { border-radius: 0 10px 10px 0; }
    .demo-credentials {
        background: #f0fdf4;
        border: 1px solid #bbf7d0;
        border-radius: 10px;
        padding: 1rem;
        margin-bottom: 1.5rem;
    }
    .demo-credentials h6 { color: #16a34a; font-weight: 700; font-size: 0.85rem; margin-bottom: 0.5rem; }
    .demo-credentials .cred { font-size: 0.82rem; color: #475569; margin: 0; }
    .demo-credentials .cred code { background: #e2e8f0; padding: 0.1rem 0.4rem; border-radius: 4px; font-size: 0.8rem; }
</style>
@endpush

@section('content')
<div class="auth-page">
    <div class="auth-card">
        <div class="brand">
            <i class="fas fa-kaaba"></i>
            <h2>Welcome Back</h2>
            <p class="text-muted">Sign in to explore Saudi Arabia</p>
        </div>

        <!-- Demo Credentials -->
        <div class="demo-credentials">
            <h6><i class="fas fa-info-circle me-1"></i>Demo Accounts</h6>
            <p class="cred"><i class="fas fa-user me-1"></i> User: <code>user@sauditourism.sa</code> / <code>password123</code></p>
            <p class="cred"><i class="fas fa-user-tie me-1"></i> Guide: <code>fahad@sauditourism.sa</code> / <code>password123</code></p>
        </div>

        <form method="POST" action="{{ route('login') }}">
            @csrf
            <div class="mb-3">
                <label class="form-label fw-semibold">Email Address</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-envelope text-muted"></i></span>
                    <input type="email" name="email" class="form-control @error('email') is-invalid @enderror"
                           value="{{ old('email') }}" placeholder="Enter your email" required autofocus>
                </div>
                @error('email')
                    <div class="text-danger small mt-1">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-lock text-muted"></i></span>
                    <input type="password" name="password" class="form-control @error('password') is-invalid @enderror"
                           placeholder="Enter your password" required>
                </div>
                @error('password')
                    <div class="text-danger small mt-1">{{ $message }}</div>
                @enderror
            </div>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div class="form-check">
                    <input type="checkbox" name="remember" class="form-check-input" id="remember" {{ old('remember') ? 'checked' : '' }}>
                    <label class="form-check-label" for="remember">Remember me</label>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 mb-3">
                <i class="fas fa-sign-in-alt me-2"></i>Sign In
            </button>

            <p class="text-center text-muted mb-0">
                Don't have an account? <a href="{{ route('register') }}" class="text-decoration-none fw-semibold">Sign Up</a>
            </p>
        </form>
    </div>
</div>
@endsection
