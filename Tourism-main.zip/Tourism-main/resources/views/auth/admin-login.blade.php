@extends('layouts.app')
@section('title', 'Admin Login - Wanderly')

@push('styles')
<style>
    .admin-auth-page {
        min-height: 100vh;
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 2rem;
    }
    .admin-auth-card {
        background: #e5e7eb;
        border-radius: 16px;
        box-shadow: 0 25px 50px rgba(107,114,128,0.6);
        max-width: 440px;
        width: 100%;
        padding: 2.5rem;
        border-top: 4px solid #d4af37;
    }
    .admin-auth-card .brand { text-align: center; margin-bottom: 2rem; }
    .admin-auth-card .brand .admin-badge {
        display: inline-block;
        background: #fefce8;
        color: #a16207;
        padding: 0.3rem 1rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 0.5rem;
    }
    .admin-auth-card .brand i { font-size: 2.5rem; color: #16a34a; }
    .admin-auth-card .brand h2 { font-weight: 700; color: #1e293b; margin-top: 0.5rem; }
    .admin-auth-card .form-control {
        border-radius: 10px;
        padding: 0.75rem 1rem;
        border: 2px solid #e2e8f0;
    }
    .admin-auth-card .form-control:focus { border-color: #16a34a; box-shadow: 0 0 0 3px rgba(22,163,74,0.1); }
    .admin-auth-card .btn-danger {
        border-radius: 10px;
        padding: 0.75rem;
        font-weight: 600;
        font-size: 1rem;
        background: #16a34a;
        border: none;
    }
    .admin-auth-card .btn-danger:hover { background: #15803d; }
    .input-group-text { border-radius: 10px 0 0 10px; border: 2px solid #e2e8f0; border-right: none; background: #f8fafc; }
    .input-group .form-control { border-radius: 0 10px 10px 0; }
</style>
@endpush

@section('content')
<div class="admin-auth-page">
    <div class="admin-auth-card">
        <div class="brand">
            <span class="admin-badge"><i class="fas fa-shield-alt me-1"></i>Admin Panel</span>
            <div class="mt-2"><i class="fas fa-user-shield"></i></div>
            <h2>Admin Login</h2>
            <p class="text-muted">Wanderly — Authorized personnel only</p>
        </div>

        @if(session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif

        <!-- Admin Credentials Hint -->
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:0.8rem 1rem;margin-bottom:1rem;">
            <p style="font-size:0.82rem;color:#475569;margin:0;"><i class="fas fa-info-circle me-1 text-success"></i>Admin: <code>admin@sauditourism.sa</code> / <code>password123</code></p>
        </div>

        <form method="POST" action="{{ route('admin.login.submit') }}">
            @csrf
            <div class="mb-3">
                <label class="form-label fw-semibold">Email Address</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-envelope text-muted"></i></span>
                    <input type="email" name="email" class="form-control @error('email') is-invalid @enderror"
                           value="{{ old('email') }}" placeholder="Admin email" required autofocus>
                </div>
                @error('email')
                    <div class="text-danger small mt-1">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-4">
                <label class="form-label fw-semibold">Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-lock text-muted"></i></span>
                    <input type="password" name="password" class="form-control @error('password') is-invalid @enderror"
                           placeholder="Admin password" required>
                </div>
                @error('password')
                    <div class="text-danger small mt-1">{{ $message }}</div>
                @enderror
            </div>

            <button type="submit" class="btn btn-danger w-100 mb-3">
                <i class="fas fa-sign-in-alt me-2"></i>Access Dashboard
            </button>

            <p class="text-center text-muted mb-0">
                <a href="{{ url('/') }}" class="text-decoration-none"><i class="fas fa-arrow-left me-1"></i>Back to Home</a>
            </p>
        </form>
    </div>
</div>
@endsection
