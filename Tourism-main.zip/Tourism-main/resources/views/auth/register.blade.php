@extends('layouts.app')
@section('title', 'Register - Wanderly')

@push('styles')
<style>
    .auth-page {
        min-height: 100vh;
        background: linear-gradient(135deg, #16a34a 0%, #15803d 50%, #127a3a 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 2rem;
    }
    .auth-card {
        background: #e5e7eb;
        border-radius: 16px;
        box-shadow: 0 25px 50px rgba(107,114,128,0.5);
        max-width: 560px;
        width: 100%;
        padding: 2.5rem;
        border-top: 4px solid #d4af37;
    }
    .auth-card .brand {
        text-align: center;
        margin-bottom: 2rem;
    }
    .auth-card .brand i { font-size: 2.5rem; color: #16a34a; }
    .auth-card .brand h2 { font-weight: 700; color: #1e293b; margin-top: 0.5rem; }
    .auth-card .form-control, .auth-card .form-select {
        border-radius: 10px;
        padding: 0.75rem 1rem;
        border: 2px solid #e2e8f0;
        transition: border-color 0.3s;
    }
    .auth-card .form-control:focus, .auth-card .form-select:focus { border-color: #16a34a; box-shadow: 0 0 0 3px rgba(22,163,74,0.1); }
    .auth-card .btn-primary {
        border-radius: 10px;
        padding: 0.75rem;
        font-weight: 600;
        font-size: 1rem;
        background: #16a34a;
        border: none;
    }
    .auth-card .btn-primary:hover { background: #15803d; }
    .input-group-text { border-radius: 10px 0 0 10px; border: 2px solid #e2e8f0; border-right: none; background: #f8fafc; }
    .input-group .form-control, .input-group .form-select { border-radius: 0 10px 10px 0; }
    .role-selector { display: flex; gap: 1rem; margin-bottom: 1.5rem; }
    .role-option {
        flex: 1; text-align: center; padding: 1rem; border: 2px solid #e2e8f0;
        border-radius: 12px; cursor: pointer; transition: all 0.3s; background: #f8fafc;
    }
    .role-option:hover { border-color: #16a34a; }
    .role-option.active { border-color: #16a34a; background: #f0fdf4; }
    .role-option i { font-size: 1.5rem; display: block; margin-bottom: 0.5rem; }
    .role-option .role-title { font-weight: 600; color: #1e293b; }
    .role-option .role-desc { font-size: 0.75rem; color: #64748b; }
    .guide-fields { display: none; }
    .guide-fields.show { display: block; }
    .section-divider { border-top: 2px dashed #d4af37; margin: 1.5rem 0; padding-top: 1rem; }
    .section-title { font-weight: 700; color: #16a34a; margin-bottom: 1rem; font-size: 0.95rem; }
</style>
@endpush

@section('content')
<div class="auth-page">
    <div class="auth-card">
        <div class="brand">
            <i class="fas fa-compass"></i>
            <h2>Create Account</h2>
            <p class="text-muted">Join Wanderly and start exploring</p>
        </div>

        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        <form method="POST" action="{{ route('register') }}">
            @csrf

            {{-- Role Selector --}}
            <input type="hidden" name="role" id="roleInput" value="{{ old('role', 'user') }}">
            <div class="role-selector">
                <div class="role-option {{ old('role', 'user') === 'user' ? 'active' : '' }}" onclick="selectRole('user')">
                    <i class="fas fa-user text-primary"></i>
                    <div class="role-title">Tourist</div>
                    <div class="role-desc">Explore & book tours</div>
                </div>
                <div class="role-option {{ old('role') === 'guide' ? 'active' : '' }}" onclick="selectRole('guide')">
                    <i class="fas fa-id-badge text-warning"></i>
                    <div class="role-title">Tour Guide</div>
                    <div class="role-desc">Requires admin approval</div>
                </div>
            </div>

            {{-- Basic Info --}}
            <div class="mb-3">
                <label class="form-label fw-semibold">Full Name</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-user text-muted"></i></span>
                    <input type="text" name="name" class="form-control @error('name') is-invalid @enderror"
                           value="{{ old('name') }}" placeholder="Enter your name" required autofocus>
                </div>
                @error('name') <div class="text-danger small mt-1">{{ $message }}</div> @enderror
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Email Address</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-envelope text-muted"></i></span>
                    <input type="email" name="email" class="form-control @error('email') is-invalid @enderror"
                           value="{{ old('email') }}" placeholder="Enter your email" required>
                </div>
                @error('email') <div class="text-danger small mt-1">{{ $message }}</div> @enderror
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Phone <span class="text-danger">*</span></label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-phone text-muted"></i></span>
                    <input type="text" name="phone" class="form-control @error('phone') is-invalid @enderror"
                           value="{{ old('phone') }}" placeholder="e.g. +966 5XX XXX XXXX" required>
                </div>
                @error('phone') <div class="text-danger small mt-1">{{ $message }}</div> @enderror
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-lock text-muted"></i></span>
                    <input type="password" name="password" class="form-control @error('password') is-invalid @enderror"
                           placeholder="Create a password" required>
                </div>
                @error('password') <div class="text-danger small mt-1">{{ $message }}</div> @enderror
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Confirm Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-lock text-muted"></i></span>
                    <input type="password" name="password_confirmation" class="form-control"
                           placeholder="Confirm your password" required>
                </div>
            </div>

            {{-- Guide-specific fields --}}
            <div class="guide-fields {{ old('role') === 'guide' ? 'show' : '' }}" id="guideFields">
                <div class="section-divider"></div>
                <div class="section-title"><i class="fas fa-id-card me-2"></i>Guide Information</div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Iqama Number <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-id-card text-muted"></i></span>
                        <input type="text" name="iqama_number" class="form-control @error('iqama_number') is-invalid @enderror"
                               value="{{ old('iqama_number') }}" placeholder="Enter your Iqama number">
                    </div>
                    @error('iqama_number') <div class="text-danger small mt-1">{{ $message }}</div> @enderror
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Nationality <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-flag text-muted"></i></span>
                        <input type="text" name="nationality" class="form-control @error('nationality') is-invalid @enderror"
                               value="{{ old('nationality') }}" placeholder="Your nationality">
                    </div>
                    @error('nationality') <div class="text-danger small mt-1">{{ $message }}</div> @enderror
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Driving License Number <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-car text-muted"></i></span>
                        <input type="text" name="driving_license" class="form-control @error('driving_license') is-invalid @enderror"
                               value="{{ old('driving_license') }}" placeholder="Driving license number">
                    </div>
                    @error('driving_license') <div class="text-danger small mt-1">{{ $message }}</div> @enderror
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Car Available? <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-car-side text-muted"></i></span>
                        <select name="has_car" class="form-select @error('has_car') is-invalid @enderror">
                            <option value="0" {{ old('has_car') == '0' ? 'selected' : '' }}>No</option>
                            <option value="1" {{ old('has_car') == '1' ? 'selected' : '' }}>Yes</option>
                        </select>
                    </div>
                    @error('has_car') <div class="text-danger small mt-1">{{ $message }}</div> @enderror
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">City <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-map-marker-alt text-muted"></i></span>
                        <input type="text" name="city" class="form-control @error('city') is-invalid @enderror"
                               value="{{ old('city') }}" placeholder="Your city">
                    </div>
                    @error('city') <div class="text-danger small mt-1">{{ $message }}</div> @enderror
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Languages <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-language text-muted"></i></span>
                        <input type="text" name="languages" class="form-control @error('languages') is-invalid @enderror"
                               value="{{ old('languages') }}" placeholder="e.g. Arabic, English, French">
                    </div>
                    @error('languages') <div class="text-danger small mt-1">{{ $message }}</div> @enderror
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Years of Experience <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-briefcase text-muted"></i></span>
                        <input type="number" name="experience_years" class="form-control @error('experience_years') is-invalid @enderror"
                               value="{{ old('experience_years') }}" placeholder="Years of guiding experience" min="0">
                    </div>
                    @error('experience_years') <div class="text-danger small mt-1">{{ $message }}</div> @enderror
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">About You / Guiding Description <span class="text-danger">*</span></label>
                    <textarea name="description" class="form-control @error('description') is-invalid @enderror"
                              rows="4" placeholder="Describe your guiding experience, specializations, and what makes you unique...">{{ old('description') }}</textarea>
                    @error('description') <div class="text-danger small mt-1">{{ $message }}</div> @enderror
                </div>

                <div class="alert alert-warning small mb-3">
                    <i class="fas fa-info-circle me-1"></i>
                    Guide accounts require admin approval before you can log in. You will be notified once your application is reviewed.
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 mb-3">
                <i class="fas fa-user-plus me-2"></i><span id="submitText">Create Account</span>
            </button>

            <p class="text-center text-muted mb-0">
                Already have an account? <a href="{{ route('login') }}" class="text-decoration-none fw-semibold">Sign In</a>
            </p>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
function selectRole(role) {
    document.getElementById('roleInput').value = role;
    document.querySelectorAll('.role-option').forEach(el => el.classList.remove('active'));
    event.currentTarget.classList.add('active');

    const guideFields = document.getElementById('guideFields');
    const submitText = document.getElementById('submitText');
    if (role === 'guide') {
        guideFields.classList.add('show');
        submitText.textContent = 'Submit Guide Application';
    } else {
        guideFields.classList.remove('show');
        submitText.textContent = 'Create Account';
    }
}
</script>
@endpush
